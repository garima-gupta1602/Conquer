/*
 * Copyright (c) 2020 Thermo Fisher Scientific
 * All rights reserved.
 */


package Runner;

//import io.cucumber.junit.CucumberOptions;

//import io.cucumber.junit.CucumberOptions;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;


/**
 * Configure the cucumber and Starts the execution of the Test Runner
 */
@CucumberOptions(
         //features = { "Features/API/.feature" },    // the path of the feature files
    //features = { "src/test/resources/features/CreateNewEntityTypeViaOdata.feature"},
   // features = { "src/test/resources/features/ValidateTypeAssociationUpdate.feature"},
        features = { "Features\\API\\Conquer\\Entity_Update_Flow\\Entity_Update_Flow.feature"},

        glue = {"ApiStepDefinitions"},
    tags = "@ExtentReport"      // the path of the step definition files
)


public class TestRunnerApi extends AbstractTestNGCucumberTests
{
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}

