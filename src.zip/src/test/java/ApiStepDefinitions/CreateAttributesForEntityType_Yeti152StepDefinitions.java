package ApiStepDefinitions;

import YETI.ApiConstants;
import YETI.DbQueries;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.db.DBHelper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.bcel.verifier.exc.AssertionViolatedException;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.HashMap;

public class CreateAttributesForEntityType_Yeti152StepDefinitions extends DBHelper {
    JSONObject Response;
    String RequestUnescapedName;
    String RequestUnescapedNameCase;
    JSONParser parser = new JSONParser();
    String ResourcePath="/CreateAttribute";


    @Given("Login into ODATA to add attribute")
    public void Login_into_ODATA_to_add_attribute() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ","Login into ODATA to add attribute");
        Readprerequest();
    }
    @When("Post the request for add attribute")
    public void Post_the_request_for_add_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS : ","Post the request for add attribute");
        RequestUnescapedName="Test"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS : ",RequestUnescapedName + "Creating random string to add attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateAttributeforEntityType.json");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS : ",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
    }
    @Then("Verify the attribute name")
    public void Verify_the_attribute_name() throws Exception
    {
        reportInstance.logInfo("STEPS : ","To Verify the attribute name");
        VerifyEntityData(Response,"AttributeName",RequestUnescapedName);
    }
    @And("verify DB for created Attribute")
    public void verify_DB_for_created_Attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","verify DB for created Attribute");

        HashMap results=ExecuteQuery(DbQueries.SelectAttributeName+querySearchFormat(RequestUnescapedName));
        int DbValue=results.size();
        if(DbValue==1)
        {
            reportInstance.logPass("Successfully entry in DB",RequestUnescapedName);
        }else
        {
            reportInstance.logFail("Not entered in DB",RequestUnescapedName);
        }

    }

    @When("Post the request for duplicate name attribute")
    public void Post_the_request_for_duplicate_name_attribute() throws Exception
    {

        reportInstance.logInfo("STEPS","Post the request for add attribute");
        RequestUnescapedName="Test"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to add attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateDuplicateAttributeforEntityType.json");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to add duplicate name attribute");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify error message for duplicate attribute")
    public void Verify_error_message_for_duplicate_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify error message");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ATTRIBUTE, "Error creating Entity Type Attribute");
    }
    @When("Post the request for min length name attribute")
    public void Post_the_request_for_min_length_name_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request for min length name attribute");
        RequestUnescapedName="T"+RandomAlphanumericGenerate(1);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending request for min length name attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateMinLengthAttributeforEntityType.json");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
    }
    @Then("Verify min length attribute")
    public void Verify_min_length_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","To Verify the min length attribute name");
        VerifyEntityData(Response,"AttributeName",RequestUnescapedName);;
    }
    @And("verify DB for min length Attribute")
    public void verify_DB_for_min_length_Attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","verify DB for min length Attribute");

        HashMap results=ExecuteQuery(DbQueries.SelectAttributeName+querySearchFormat(RequestUnescapedName));
        int DbValue=results.size();
        if(DbValue==1)
        {
            reportInstance.logPass("Successfully entry in DB",RequestUnescapedName);
        }else
        {
            reportInstance.logFail("Not entered in DB",RequestUnescapedName);
        }

    }
    @When("Post the request for max length name attribute")
    public void Post_the_request_for_max_length_name_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request for max length name attribute");
        RequestUnescapedName="Test"+RandomAlphanumericGenerate(14);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending request for max length name attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateMaxLengthAttributeforEntityType.json");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
    }
    @Then("Verify max length attribute")
    public void Verify_max_length_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","To Verify the max length attribute name");
        VerifyEntityData(Response,"AttributeName",RequestUnescapedName);;
    }
    @And("verify DB for max length Attribute")
    public void verify_DB_for_max_length_Attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","verify DB for max length Attribute");

        HashMap results=ExecuteQuery(DbQueries.SelectAttributeName+querySearchFormat(RequestUnescapedName));
        int DbValue=results.size();
        if(DbValue==1)
        {
            reportInstance.logPass("Successfully entry in DB",RequestUnescapedName);
        }else
        {
            reportInstance.logFail("Not entered in DB",RequestUnescapedName);
        }

    }
    @When("Post the request for special character name attribute")
    public void Post_the_request_for_special_character_name_attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request for special character name attribute");
        RequestUnescapedName="Test@3$%^&"+RandomAlphanumericGenerate(1);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending request for special character name attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSplCharacterAttributeforEntityType.json");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify error message for special character")
    public void Verify_error_message_for_special_character() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify error message for special character");
        String error = Response.get("error").toString();
        JSONObject ErrorcodeandMessage = (JSONObject)parser.parse(error);
        String Strcode = ErrorcodeandMessage.get("code").toString();
        String Strmessage = ErrorcodeandMessage.get("message").toString();
        this.reportInstance.logInfo("code message ", Strmessage, ExtentColor.WHITE);
        this.reportInstance.logInfo("", error, ExtentColor.WHITE);
        if (Strcode.equalsIgnoreCase(ApiConstants.ERROR_CODE_CREATING_ATTRIBUTE)) {
            this.reportInstance.logPass(Strcode, " is as expected", ExtentColor.GREEN);
            if (Strmessage.contains("Property AttributeName must not contain special characters")) {
                this.reportInstance.logPass(Strmessage, " is as expected", ExtentColor.GREEN);
            } else {
                this.reportInstance.logFail(Strmessage + " is as not as expected - Expected is ", Strmessage, ExtentColor.RED);
                throw new AssertionViolatedException("Not as expected " + Strmessage);
            }
        } else {
            this.reportInstance.logFail(Strcode + " is as not as expected - Expected is ", Strcode, ExtentColor.RED);
            throw new AssertionViolatedException("Not as expected " + Strcode);
        }
    }

    @When("Post the request for add attribute with different case")
    public void Post_the_request_for_add_attribute_with_different_case() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request for add attribute");
        RequestUnescapedName="Test"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to add attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateAttributeforEntityTypeUpperCase.json");
        Request.put("AttributeName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
        reportInstance.logInfo("STEPS","Post the request for add attribute with different case");
        RequestUnescapedNameCase=RequestUnescapedName.toUpperCase();
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request for add attribute with different case");
        Request.put("AttributeName",RequestUnescapedNameCase);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
    }
    @Then("Verify attribute name for different case")
    public void Verify_attribute_name_for_different_case() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify attribute name for different case");
        VerifyEntityData(Response,"AttributeName",RequestUnescapedNameCase);
    }
    @And("verify DB for same name different case Attribute")
    public void verify_DB_for_same_name_different_case_Attribute() throws Exception
    {
        reportInstance.logInfo("STEPS","verify DB for same name different case Attribute");

        HashMap results=ExecuteQuery(DbQueries.SelectAttributeName+querySearchFormat(RequestUnescapedNameCase));
        int DbValue=results.size();
        if(DbValue==1)
        {
            reportInstance.logPass("Successfully entry in DB",RequestUnescapedNameCase);
        }else
        {
            reportInstance.logFail("Not entered in DB",RequestUnescapedNameCase);
        }

    }
}

