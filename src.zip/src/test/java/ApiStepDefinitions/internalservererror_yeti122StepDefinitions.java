/*
 * Copyright (c) 2020 Thermo Fisher Scientific
 * All rights reserved.
 */


package ApiStepDefinitions;

import com.api.APIHelper;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;


/**
 *  This is for the Internal Server Error Fix over the Super Type of SAMPLE
 */
public class internalservererror_yeti122StepDefinitions extends APIHelper
{
    /** To Scenario details  */
    Scenario scenario;

    /** To Process the JSON response  */
    JSONObject Response;
    

    /**
     * To Login into the ODATA
     *
     * @throws Exception
     */
    @Given("Login into ODATA for Internal Server Error")
    public void login_into_odata_for_internal_server_error() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("STEPS","Login into ODATA for Internal Server Error");
        Readprerequest();
    }

    /**
     * To send PUT request for SAMPLE with invalid data
     *
     * @throws Exception
     */
    @When("PUT for SAMPLE with invalid")
    public void put_for_sample_with_invalid() throws Exception
    {
        reportInstance.logInfo("STEPS","put_for_sample_with_invalid");
        Response = putRequest(GenerateJSONBody("src/test/resources/YETI/yeti_122/invalidRequestBody.json"), "odata/SAMPLE('SMSA1')", HttpURLConnection.HTTP_BAD_REQUEST);

        // GetRequest("odata/SAMPLE('SMSA1')");
        // OdataLogin("lims","lims#1","PLATFORM ADMIN");
    }

    /**
     *  To Verify the error message over the invalid data
     *
     * @throws Exception
     */
    @Then("Verify the odata type error message")
    public void verify_the_odata_type_error_message() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify the odata type error message");
        VerifyErrorMessage(Response, "2002", "Missing replacement for place holder in message ''%1$s' can not be mapped as a property or an annotation.' for following arguments '[]'!");
    }

    /**
     *  To send PUT request for SAMPLE with valid data
     *
     * @throws Exception
     */
    @When("PUT for SAMPLE with valid")
    public void put_for_sample_with_valid() throws Exception
    {
        reportInstance.logInfo("STEPS","PUT for SAMPLE with valid");
        Response = putRequest(GenerateJSONBody("src/test/resources/YETI/yeti_122/validRequestBody_Sample.json"), "odata/SAMPLE('SMSA1')", HttpURLConnection.HTTP_OK);
    }

    /**
     * To Verify the odatatype update message over the valid data
     *
     * @throws Exception
     */
    @Then("Verify the odata type update")
    public void verify_the_odata_type_update() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify the odata type update");
        VerifyEntityData(Response, "@odata.type", "#PlatformForScience.SOMETHING_SAMPLE");

        // VerifyErrorMessage(Response,"2002","Missing replacement for place holder in message ''%1$s' can not be mapped as a property or an annotation.' for following arguments '[]'!");
        // OdataLogin("lims","lims#1","PLATFORM ADMIN");
    }

    /**
     *  To Send the PATCH request for INTERMEDIATE_ASSAY_DATA with valid
     *
     * @throws Exception
     */
    @When("PATCH for INTERMEDIATE_ASSAY_DATA with valid")
    public void patch_for_intermediate_assay_data_with_valid() throws Exception
    {
        reportInstance.logInfo("STEPS","PATCH for INTERMEDIATE_ASSAY_DATA with valid");
        Response = patchRequest(GenerateJSONBody("src/test/resources/YETI/yeti_122/validRequestBody_IntermediateAssay.json"), "odata/INTERMEDIATE_ASSAY_DATA('BTES1189')", HttpURLConnection.HTTP_OK);

    }

    /**
     * To verify PATCH request update for INTERMEDIATE_ASSAY_DATA with valid data
     *
     * @throws Exception
     */
    @Then("Verify the patch request update")
    public void verify_the_patch_request_update() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify the patch of barcode update");
        VerifyEntityData(Response, "Id", "17560779");
    }


}

