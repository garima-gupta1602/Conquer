package ApiStepDefinitions;


        import YETI.ApiConstants;
        import YETI.DbQueries;
        import com.db.DBHelper;
        import io.cucumber.java.Scenario;
        import io.cucumber.java.en.Given;
        import io.cucumber.java.en.Then;
        import io.cucumber.java.en.When;
        import org.apache.commons.httpclient.util.HttpURLConnection;
        import org.json.simple.JSONArray;
        import org.json.simple.JSONObject;
        import org.json.simple.parser.JSONParser;

        import java.util.ArrayList;
        import java.util.HashMap;

public class PreferenceReturnStepDefinitions extends DBHelper {
    /**
     * Parser to have JSON Parser
     */
    JSONParser parser = new JSONParser();
    Scenario scenario;
    JSONObject Response;
    ArrayList<String> qbarcode = new ArrayList<>();
    String Barcode;
    String invalidBarcode;

    String ResourcePath = "/RegressionTests/QueueAction/PreferenceReturn";


    @Given("Login into ODATA for PreferenceReturn")
    public void Login_into_ODATA_for_PreferenceReturn() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN", "Login into ODATA for PreferenceReturn");
        Readprerequest();
    }

    @When("Create a PUT request for Update entity with minimal return")
    public void create_a_PUT_request_for_Update_entity_with_minimal_return() throws Exception {
        //prerequisite - create an entity and use the same as body for put request
        reportInstance.logInfo("STEPS", "POST request for creating entity");
        JSONObject preRequest = ReadJsonInput(ResourcePath + "/CreateEntity.json");
        reportInstance.logInfo("STEPS", preRequest.toString());
        Response = postRequest(preRequest.toString(), ApiConstants.Route_Preference, HttpURLConnection.HTTP_CREATED);
        //prerequisite - put request
        reportInstance.logInfo("STEPS", "Create a PUT request for Update entity with minimal return");
        String routeparam = GetattributefromResponse(Response, "Name");
        String dynamicRoute = ApiConstants.Route_Preference.concat("('" + routeparam + "')");
        JSONObject Request = Response;
        reportInstance.logInfo("STEPS", Request.toString());
        Response = putRequest(Request.toString(), dynamicRoute, UpdateRequestHeader("prefer", "return=minimal"), HttpURLConnection.HTTP_NO_CONTENT);

    }
}