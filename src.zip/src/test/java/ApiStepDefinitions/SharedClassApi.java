package ApiStepDefinitions;

import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.common.BaseTest;
import com.common.Constants;
import com.qTest.QTestTestExecution;
import com.qTest.qTestAuth;
import com.thermofisher.utils.*;
import io.cucumber.java.*;
import org.apache.http.HttpStatus;
import org.junit.AssumptionViolatedException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Properties;

public class SharedClassApi extends BaseTest
{

    String className = this.getClass().getSimpleName();

    Scenario scenario;
    String methodName;
    FileReader reader;
    String filePath;
    String startTime;
    String endTime;
    public static final Properties prop = new Properties();

    public SharedClassApi() throws IOException
    {
        super("YETI");
        ClassLoader classLoader = getClass().getClassLoader();
        URL resource = classLoader.getResource("framework.properties");
        // In Windows, a space is converted to %20 so the file path is invalid, the line below to fix it
        Initialize.setEnvironmentVariables(resource.getPath().replaceAll("%20", " "));
    }


    @After("@B_API")
    public void tearDownApi(Scenario scenario) throws Exception
    {
        Status result = scenario.getStatus();
        String qTestStatus = "";
        if(result == Status.FAILED){
            getExtentTest().fail(MarkupHelper.createLabel(scenario.getName() + " Test case is FAILED", ExtentColor.RED));
            qTestStatus = "fail";
        }else if ( result == Status.PASSED ) {
            getExtentTest().pass(MarkupHelper.createLabel(scenario.getName() + " Test case is PASSED", ExtentColor.GREEN));
            qTestStatus = "pass";
        } else {
            getExtentTest().skip(MarkupHelper.createLabel(scenario.getName()+ " Test case is SKIPPED", ExtentColor.YELLOW));
            qTestStatus = "skip";
        }
        releaseFrameworkObjects( methodName);
        getReportInstance().logInfo(scenario.getName()," "+ scenario.getStatus().toString());
        getExtentReports().flush();
        ZonedDateTime endTestTimeInUTC = ZonedDateTime.now(ZoneId.of("UTC"));
        DateTimeFormatter f1 = DateTimeFormatter.ofPattern("MMM-dd-yyyy HH:mm:ss Z");
        endTime = endTestTimeInUTC.format(f1);
//        if(System.getProperty("qTestUpdate", "false").equalsIgnoreCase("True"))
//        {
//            if(!filePath.equalsIgnoreCase("")){
//                QTestTestExecution qTest = new QTestTestExecution();
//                qTest.submitAutomationTestLogWithAttachment(filePath, qTestStatus, scenario.getName(), startTime, endTime);
//            }
//        }
    }

    @Before("@B_API")
    public void beforeScenariosApi(Scenario scenario) throws Exception
    {
        initializeFrameworkSuite();
        initializeFrameworkObjectsApi(scenario.getName() , className);
        this.scenario = scenario;
        filePath = "";
        if(System.getProperty("qTestUpdate", "false").equalsIgnoreCase("true")
                && System.getProperty("qTestOnlyExecuteExistingTestRun", "false").
                equalsIgnoreCase("true")){
            QTestTestExecution qTest = new QTestTestExecution();
            Map testCycle = qTest.searchTestCycleByName(System.getProperty("qTestCycleFolder", "Not Existing Test Cycle"));
            Long testRunId = qTest.searchTestRunIDByNameAndParentTestCycle(scenario.getName(), testCycle);
            if(testRunId == 0){
                throw new AssumptionViolatedException("Skipping as test run does not exist in expected qTest cycle!");
            }
        }
        ZonedDateTime startTestTimeInUTC = ZonedDateTime.now(ZoneId.of("UTC"));
        DateTimeFormatter f1 = DateTimeFormatter.ofPattern("MMM-dd-yyyy HH:mm:ss Z");
        startTime = startTestTimeInUTC.format(f1);
        filePath = Constants.testResultsFolderPath +
                "/" + BaseTest.runtimeFolderInsideResult +
                "/" + scenario.getName() + ".html";
        System.out.println(filePath);
    }
    @Before("@Common")
    public void beforeScenarios(Scenario scenario) throws Exception
    {
        initializeFrameworkSuite();
        initializeFrameworkObjectsApi(scenario.getName() , className);
        this.scenario = scenario;
        /*reader = new FileReader("src/test/resources/Global.properties");
        prop.load(reader);*/
    }
    @BeforeStep("@B_API")
    public void logACSteps(Scenario scenario) throws Exception {
        getStepText(scenario);
    }

    /**
     * Convert entity type name to the valid format used in Metadata
     * @param name
     * @return
     */
    public static String escapeName(String name){
        if(name.matches("^[0-9].*")){
            return "_" + name.replaceAll(" ", "_").toUpperCase();
        }
        else {
            return name.replaceAll(" ", "_").toUpperCase();
        }
    }

    /**
     * Retrieve response body in String format based on status code
     * @param connection
     * @return String response body
     * @throws IOException
     */
    public static String retrieveResponseBody(HttpURLConnection connection) throws IOException {
        BufferedReader in;
        if(connection.getResponseCode() < HttpStatus.SC_BAD_REQUEST){
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        }
        else{
            in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
        }
        StringBuffer content = new StringBuffer();
        String inputLine;

        while ((inputLine = in.readLine()) != null)
        {
            content.append(inputLine);
        }
        return content.toString();
    }
}