package ApiStepDefinitions;

import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PrivacyLevel extends DBHelper {

    /** TODO: Field description */
    JSONObject Response = new JSONObject();
    private SharedAttributes sharedAttributes;

    /** TODO: Field description */
    JSONParser parseJson = new JSONParser();

    public PrivacyLevel(SharedAttributes share) throws Exception {
        this.sharedAttributes = share;
        Readprerequest();
        reportInstance=SharedClassApi.getReportInstance();
    }

    /**
     * TODO: Method description
     *
     * @param attributeName
     * @param entityTypeName
     * @throws IOException
     */
    @Then("Verify attribute {string} with data type {string} associated to entity type {string}, unescaped name is {string}")
    public void verifyAttributeAssociatedToEntityType(String attributeName, String dataType, String entityTypeName, String unescapedName) throws IOException
    {
        try
        {
            reportInstance = SharedClassApi.getReportInstance();
            String patternString = String.format("<EntityType Name=\"%s\"(.*)<Annotation Term=\"pfs\\.UnescapedName\"><String>%s<\\/String><\\/Annotation><\\/EntityType>", entityTypeName, unescapedName);
            Pattern pattern = Pattern.compile(patternString);
            String metadata = sharedAttributes.customAttributes.get("metadata").toString();
            Matcher matcher = pattern.matcher(metadata);
            String content = "";
            if(matcher.find()){
                content = matcher.group(1);
            }
            String property = String.format("<Property Name=\"%s\" Type=\"Edm.%s\"", attributeName, dataType);
            if (content.contains(property))
            {
                reportInstance.logPass("STEP - ", "Verify that attribute " + attributeName + " associated to entity type " + entityTypeName);
            }
            else
            {
                reportInstance.logFail("STEP - ", "Verify that attribute " + attributeName + " associated to entity type " + entityTypeName);
                Assert.fail(String.format("Failed when verifying the Metadata contains: %s", property));
            }
        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - ", "Verify that attribute " + attributeName + " associated to entity type " + entityTypeName);
            Assert.fail();
        }

    }

    @When("GET request to retrieve information of TYPE_ATTRIBUTE with Id {int}")
    public void getRequestToRetrieveInformationOfTYPE_ATTRIBUTEWithId(int id) throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Response = (JSONObject) parseJson.parse(
                GetRequest(ApiConstants.Route_TypeAttribute + String.format("(%s)", id),
                String.format("Get TYPE_ATTRIBUTE with Id %s", id)));
        sharedAttributes.customAttributes.put("response", Response);
    }

    @Then("{string} attribute with value {string} appears in response")
    public void attributeWithValueAppearsInResponse(String attribute, String value) throws IOException {
        JSONObject response = (JSONObject) sharedAttributes.customAttributes.get("response");
        if(response.get(attribute).getClass().getName().contains("String")
                && response.get(attribute).toString().equals(value)){
            reportInstance.logPass("STEP - ", "Verify that attribute " + attribute +
                    " with value " + value);
        }
        else
        {
            reportInstance.logFail("STEP - ", "Verify that attribute " + attribute
                    + " with value " + value);
            Assert.fail("No attribute in the response or its value does not match the expectation");
        }
    }
}
