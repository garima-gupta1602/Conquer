package ApiStepDefinitions;

import YETI.ApiConstants;
import YETI.DbQueries;
import com.common.Utils;
import com.db.DBHelper;
import com.selenium.api.Assertions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.RandomUtils;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.SerializationUtils;
public class ValidateTypeAssociationCreation extends DBHelper {

    /** TODO: Field description */
    JSONObject Response = new JSONObject();
    private SharedAttributes sharedAttributes;

    /** TODO: Field description */
    JSONParser parseJson = new JSONParser();

    public ValidateTypeAssociationCreation(SharedAttributes share) throws Exception {
        this.sharedAttributes = share;
        Readprerequest();
        reportInstance = SharedClassApi.getReportInstance();
    }

    private static final String CREATE_TYPE_ASSOCIATION_REQUEST_BODY = "/validatetypeassociationcreation/CreateNewTypeAssociationRequestBody.json";
    private static final String UPDATE_TYPE_ASSOCIATION_REQUEST_BODY = "/validatetypeassociationupdate/UpdateTypeAssociationRequestBody.json";
    @When("Post a request to create new TYPE_ASSOCIATION with {string}")
    public void postARequestToCreateNewTYPE_ASSOCIATIONWithValidRequest(String scenario) throws IOException {
        try
        {
            JSONObject requestBody = ReadJsonInput(CREATE_TYPE_ASSOCIATION_REQUEST_BODY);
            HashMap<String, String> authorizationHeader  = this.DefaultRequestHeader();
            if(scenario.equals("unauthorized user")){
                authorizationHeader.put("Authorization", Utils.getInstance().getGlobalTestData("BasicAuthForNoPermissionUser"));
            }
            if(!scenario.equals("valid request")){
                requestBody.replace("Context", "Arbitrary Predicate" + RandomUtils.nextLong());
            }
            HttpURLConnection connection;

            switch (scenario){
                case "valid request":
                case "unauthorized user":
                    break;

                case "source entity type name contains more than two words":
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE('BITTERNESS_EXPERIMENT')");
                    break;

                case "missing property":
                    requestBody.remove("Context");
                    break;

                case "duplicated Context":
                    //Entity type ANIMAL_LIMITED already had a navigation property with context: ANIMAL_NURSES
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE('ANIMAL_LIMITED')");
                    requestBody.put("Context", "ANIMAL_NURSES");
                    break;

                case "missing navigation property":
                    requestBody.remove("TARGET_ENTITY_TYPE@odata.bind");
                    break;

                case "unknown property":
                    requestBody.put("Unknown_key", "unknown key arbitrary value");
                    break;

                case "not existing entity type":
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE('NURSE1111')");
                    break;

                case "too short Context":
                    requestBody.replace("Context", "");
                    break;

                case "wrong format of entity type link":
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITYTYPE('NURSE')");
                    break;

                case "Mandatory is not boolean":
                    requestBody.replace("Mandatory", "yes");
                    break;

                case "Editable is not boolean":
                    requestBody.replace("Editable", 1);
                    break;

                case "MultiSelect is not boolean":
                    requestBody.replace("MultiSelect", "true");
                    break;

                case "ShowOnCreate is not boolean":
                    requestBody.replace("ShowOnCreate", 1234);
                    break;

                case "ShowOnQuery is not boolean":
                    requestBody.replace("ShowOnQuery", "yes");
                    break;

                case "ShowOnDetails is not boolean":
                    requestBody.replace("ShowOnDetails", "no");
                    break;

                case "AssociationInterface value not in dictionary":
                    requestBody.replace("AssociationInterface", "not-in-dictionary");
                    break;

                case "AssociationInterface is not string":
                    requestBody.replace("AssociationInterface", 4);
                    break;

                case "Context is not string":
                    requestBody.replace("Context", 1);
                    break;

                case "Display is not string":
                    requestBody.replace("Display", 0);
                    break;

                case "Display is empty":
                    requestBody.replace("Display", "");
                    break;

                case "ReverseDisplay is not string":
                    requestBody.replace("ReverseDisplay", true);
                    break;

                case "ReverseDisplay is empty":
                    requestBody.replace("ReverseDisplay", "");
                    break;

                case "Sequence is not integer":
                    requestBody.replace("Sequence", 4.5);
                    break;

                case "Sequence is less than 1":
                    requestBody.replace("Sequence", 0);
                    break;

                case "ReverseSequence is not integer":
                    requestBody.replace("ReverseSequence", true);
                    break;

                case "ReverseSequence is less than 1":
                    requestBody.replace("ReverseSequence", -1);
                    break;

                case "ShowOnDetailsWhenZero is not integer":
                    requestBody.replace("ShowOnDetailsWhenZero", "1");
                    break;

                case "ShowOnDetailsWhenZero is less than 0":
                    requestBody.replace("ShowOnDetailsWhenZero", -11);
                    break;

                case "navigation property value is not string":
                    requestBody.replace("TARGET_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE(1)");
                    break;

                default:
                    reportInstance
                            .logFail("STEP - ",
                                    String.format("Invalid option to create TYPE_ASSOCIATION"));
                    Assert.fail();
                    break;
            }
            connection = SendRequest(ApiConstants.Route_Type_Association, requestBody.toString(),
                    authorizationHeader, "POST");
            sharedAttributes.connection = connection;
            reportInstance.logPass("STEP - ",
                                    String.format("Post a request to create new TYPE_ASSOCIATION with %s", scenario));
        }
        catch (Exception ex)
        {
            reportInstance
                    .logFail("STEP - ", String.format("Post the request to add an type association with scenario %s failed", scenario));
            Assert.fail();
        }
    }

    @And("Verify the response body contains error with code {string} and message as {string}")
    public void verifyTheResponseBodyContainsErrorWithCodeAndMessageAs(String code, String message) throws Exception {
        JSONObject response = this.ResponseOutput(sharedAttributes.connection, HttpStatus.SC_BAD_REQUEST, false,
                new HashMap());
        VerifyErrorMessage(response, code, message);
    }

    @And("Verify the validation response body contains error with code {string} and message as {string}")
    public void verifyTheValidationResponseBodyContainsErrorWithCodeAndMessageAs(String code, String message) throws Exception {
        JSONObject response = this.ResponseOutput(sharedAttributes.connection, HttpStatus.SC_OK, false,
                new HashMap());
        VerifyErrorMessage(response, code, message);
    }

    @Then("Verify the response body contains error with code {string} and unauthorized message as {string}")
    public void verifyTheResponseBodyContainsErrorWithCodeAndUnauthorizedMessageAs(String code, String message) throws Exception {
        JSONObject response = this.ResponseOutput(sharedAttributes.connection, HttpStatus.SC_UNAUTHORIZED, false,
                new HashMap());
        VerifyErrorMessage(response, code, message);
    }

    @Then("Verify the response body contains key {string} with value {string}")
    public void verifyTheResponseBodyContainsKeyWithValue(String key, String value) throws Exception {
        JSONObject responseOutput;
        if(sharedAttributes.customAttributes.get("responseOutput") == null){
            HttpURLConnection response = sharedAttributes.connection;
            responseOutput = this.ResponseOutput(response, HttpStatus.SC_CREATED, false,
                    new HashMap());
            sharedAttributes.customAttributes.put("responseOutput", responseOutput);
        }
        else {
            responseOutput = (JSONObject) sharedAttributes.customAttributes.get("responseOutput");
        }
        VerifyEntityData(responseOutput, key, value);
    }

    @Then("Verify the response body contains key {string} with value with data type {string}")
    public void verifyTheResponseBodyContainsKeyWithValueWithDataType(String key, String dataType) throws Exception {
        JSONObject responseOutput;
        if(sharedAttributes.customAttributes.get("responseOutput") == null){
            HttpURLConnection response = sharedAttributes.connection;
            responseOutput = this.ResponseOutput(response, HttpStatus.SC_CREATED, false,
                    new HashMap());
            sharedAttributes.customAttributes.put("responseOutput", responseOutput);
        }
        else {
            responseOutput = (JSONObject) sharedAttributes.customAttributes.get("responseOutput");
        }

        switch (dataType){
            case "Long":
                Assertions.assertTrue(responseOutput.get(key) instanceof Long,
                        String.format("Verify key %s has data type is %s", key, dataType), reportInstance);
        }

    }

    @Then("Verify new association with source entity type {string}, target entity type {string} and context {string} added to database")
    public void verifyNewAssociationWithSourceEntityTypeTargetEntityTypeAndContextAddedToDatabase
            (String sourceEntityType, String targetEntityType, String context) throws IOException {
        try
        {
            Map results = ExecuteQuery(DbQueries.RETRIEVE_TYPE_ASSOCIATION.
                    replace("{sourceEntityType}", sourceEntityType)
                    .replace("{targetEntityType}", targetEntityType)
                    .replace("{context}", context));
            if (results.size() == 1)
            {
                reportInstance.logPass(String.format("Only %s type association created as expected", results.size()), "");
            }
            else
            {
                reportInstance.logFail(String.format("Not only one type association created as expected, actual: %s", results.size()), "");
                Assert.fail();
            }
        }
        catch (Exception ex)
        {
            reportInstance.logFail(String.format("Exception thrown while verifying type association. Stack trace: %s",
                    ex.getStackTrace().toString()), "");
            Assert.fail();
        }
    }

    @When("Send a {string} request to update a TYPE_ASSOCIATION with {string}")
    public void sendARequestToUpdateATYPE_ASSOCIATIONWith(String method, String scenario) {
        try
        {
            JSONObject requestBody = ReadJsonInput(UPDATE_TYPE_ASSOCIATION_REQUEST_BODY);
            HashMap<String, String> authorizationHeader  = this.DefaultRequestHeader();
            if(scenario.equals("unauthorized user")){
                authorizationHeader.put("Authorization", Utils.getInstance().getGlobalTestData("BasicAuthForNoPermissionUser"));
            }
            HttpURLConnection connection;

            switch (scenario){
                case "valid request":
                case "unauthorized user":
                    requestBody.replace("Context", "Arbitrary Predicate" + RandomUtils.nextLong());
                    requestBody.replace("Display", "Arbitrary Predicate" + RandomUtils.nextLong());
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Id");
                        requestBody.remove("ReverseDisplay");
                        requestBody.remove("Display");
                        requestBody.remove("Context");
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Sequence");
                        requestBody.remove("ReverseSequence");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("Mandatory");
                        requestBody.remove("Editable");
                        requestBody.remove("ShowOnQuery");
                        requestBody.remove("MultiSelect");
                        requestBody.remove("ShowOnDetailsWhenZero");
                        requestBody.remove("EscapedName");
                    }
                    break;

                case "source entity type name contains more than two words":
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE('BITTERNESS_EXPERIMENT')");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Sequence");
                        requestBody.remove("Display");
                        requestBody.remove("ReverseSequence");
                        requestBody.remove("Id");
                    }
                    break;

                case "missing property":
                    requestBody.remove("Context");
                    break;

                case "duplicated Context":
                    //Entity type ANIMAL_LIMITED already had a navigation property with context: ANIMAL_NURSES
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE('ANIMAL_LIMITED')");
                    requestBody.replace("Context", "ANIMAL_NURSES");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Sequence");
                        requestBody.remove("Display");
                        requestBody.remove("ReverseSequence");
                        requestBody.remove("Id");
                    }
                    break;

                case "missing navigation property":
                    requestBody.remove("TARGET_ENTITY_TYPE@odata.bind");
                    break;

                case "unknown property":
                    requestBody.put("Unknown_key", "unknown key arbitrary value");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Sequence");
                        requestBody.remove("Display");
                        requestBody.remove("ReverseSequence");
                        requestBody.remove("Editable");
                    }
                    break;

                case "not existing entity type":
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE('NURSE1111')");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Sequence");
                        requestBody.remove("Display");
                        requestBody.remove("ReverseSequence");
                        requestBody.remove("Editable");
                    }
                    break;

                case "too short Context":
                    requestBody.replace("Context", "");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Id");
                        requestBody.remove("EscapedName");
                        requestBody.remove("ReverseSequence");
                        requestBody.remove("MultiSelect");
                    }
                    break;

                case "wrong format of entity type link":
                    requestBody.replace("SOURCE_ENTITY_TYPE@odata.bind", "/ENTITYTYPE('NURSE')");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("MultiSelect");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "Mandatory is not boolean":
                    requestBody.replace("Mandatory", "yes");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("MultiSelect");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "Editable is not boolean":
                    requestBody.replace("Editable", 1);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("MultiSelect");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "MultiSelect is not boolean":
                    requestBody.replace("MultiSelect", "true");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("ReverseDisplay");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "ShowOnCreate is not boolean":
                    requestBody.replace("ShowOnCreate", 1234);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("ReverseDisplay");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "ShowOnQuery is not boolean":
                    requestBody.replace("ShowOnQuery", "yes");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "ShowOnDetails is not boolean":
                    requestBody.replace("ShowOnDetails", "no");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("ReverseDisplay");
                        requestBody.remove("ShowOnQuery");
                        requestBody.remove("Id");
                        requestBody.remove("Context");
                    }
                    break;

                case "AssociationInterface value not in dictionary":
                    requestBody.replace("AssociationInterface", "not-in-dictionary");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Display");
                        requestBody.remove("Context");
                        requestBody.remove("Id");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "AssociationInterface is not string":
                    requestBody.replace("AssociationInterface", 4);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Display");
                        requestBody.remove("Context");
                        requestBody.remove("Id");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "Context is not string":
                    requestBody.replace("Context", 1);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Id");
                        requestBody.remove("Display");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("MultiSelect");
                    }
                    break;

                case "Display is not string":
                    requestBody.replace("Display", 0);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Id");
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("MultiSelect");
                    }
                    break;

                case "Display is empty":
                    requestBody.replace("Display", "");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("Context");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "ReverseDisplay is not string":
                    requestBody.replace("ReverseDisplay", true);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("Context");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "ReverseDisplay is empty":
                    requestBody.replace("ReverseDisplay", "");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("Context");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "Sequence is not integer":
                    requestBody.replace("Sequence", 4.5);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("Context");
                        requestBody.remove("MultiSelect");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "Sequence is less than 1":
                    requestBody.replace("Sequence", 0);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("ShowOnDetails");
                        requestBody.remove("Context");
                        requestBody.remove("ShowOnCreate");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "ReverseSequence is not integer":
                    requestBody.replace("ReverseSequence", true);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Display");
                        requestBody.remove("Context");
                        requestBody.remove("Id");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "ReverseSequence is less than 1":
                    requestBody.replace("ReverseSequence", -1);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Display");
                        requestBody.remove("Sequence");
                        requestBody.remove("Id");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "ShowOnDetailsWhenZero is not integer":
                    requestBody.replace("ShowOnDetailsWhenZero", "1");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Display");
                        requestBody.remove("Sequence");
                        requestBody.remove("Id");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "ShowOnDetailsWhenZero is less than 0":
                    requestBody.replace("ShowOnDetailsWhenZero", -11);
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("Sequence");
                        requestBody.remove("Context");
                        requestBody.remove("Id");
                        requestBody.remove("ShowOnQuery");
                    }
                    break;

                case "navigation property value is not string":
                    requestBody.replace("TARGET_ENTITY_TYPE@odata.bind", "/ENTITY_TYPE(1)");
                    if(method.toLowerCase().equals("patch")){
                        requestBody.remove("AssociationInterface");
                        requestBody.remove("ShowOnQuery");
                        requestBody.remove("ShowOnDetailsWhenZero");
                        requestBody.remove("ShowOnCreate");
                    }
                    break;

                default:
                    reportInstance
                            .logFail("STEP - ",
                                    String.format("Invalid option to create TYPE_ASSOCIATION"));
                    Assert.fail();
                    break;
            }
            connection = SendRequest(ApiConstants.Route_Update_Type_Association, requestBody.toString(),
                    authorizationHeader, method);
            sharedAttributes.connection = connection;
            reportInstance.logPass("STEP - ",
                    String.format("Send a request to update a TYPE_ASSOCIATION with %s", scenario));
        }
        catch (Exception ex)
        {
            reportInstance
                    .logFail("STEP - ", String.format("Send a request to update a TYPE_ASSOCIATION with %s failed", scenario));
            Assert.fail();
        }
    }
}
