/*
 * Copyright (c) 2020 Thermo Fisher Scientific
 * All rights reserved.
 */


package ApiStepDefinitions;


import com.api.APIHelper;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;


/**
 * To create super type under DATA TYPE of the feature.
 */
public class SuperTypeDataType_yeti85StepDefinitions extends APIHelper
{
    /** To Scenario details  */
    Scenario scenario;

    /** To Process the JSON response  */
    JSONObject Response;


    /**
     * Login into the ODATA
     *
     * @throws Exception
     */
    @Given("Login into ODATA for supertype data type")
    public void login_into_odata_for_supertype_data_type() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("STEPS","Login into ODATA for supertype data type");
        Readprerequest();
    }

    /**
     * Post the Body requeest of concentration
     *
     * @throws Exception
     */
    @When("Post the Body Request of Concentration")
    public void post_the_body_request_of_concentration() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the Body Request of Concentration");
        Response = postRequest("{ }", "odata/CONCENTRATION", HttpURLConnection.HTTP_CREATED);
    }

    /**
     * Verify the EntityTypeName is Concentration
     *
     * @throws Exception
     */
    @Then("Verify the EntityTypeName is Concentration")
    public void verify_the_entitytypename_is_concentration() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify the EntityTypeName is Concentration");
        VerifyEntityData(Response, "EntityTypeName", "CONCENTRATION");
    }

    /**
     * Post the Body Request of Password
     *
     * @throws Exception
     */
    @When("Post the Body Request of Password")
    public void post_the_body_request_of_password() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the Body Request of Password");
        Response = postRequest("{ }", "odata/PASSWORD", HttpURLConnection.HTTP_CREATED);
    }

    /**
     * Verify the EntityTypeName is Password
     *
     * @throws Exception
     */
    @Then("Verify the EntityTypeName is Password")
    public void verify_the_entitytypename_is_password() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify the EntityTypeName is password");
        VerifyEntityData(Response, "EntityTypeName", "PASSWORD");
    }

    /**
     * Post the new entity under CONCENTRATION
     *
     * @throws Exception
     */
    @When("Post the new entity under CONCENTRATION")
    public void post_the_new_entity_under_concentration() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the new entity under CONCENTRATION");
        String jsonbody=GenerateJSONBody("src/test/resources/YETI/yeti_85/ValidRequestOnEntityTypeConcentration.json", "Name");
        reportInstance.logInfo("STEPS",jsonbody);
        Response = postRequest(jsonbody, "odata/CONCENTRATION", HttpURLConnection.HTTP_CREATED);
    }

    /**
     * Verify the concentration entity created
     *
     * @throws Exception
     */
    @Then("Verify the concentration entity created")
    public void verify_the_concentration_entity_created() throws Exception
    {
        reportInstance.logInfo("STEPS","Verify the concentration entity created");
        VerifyEntityData(Response, "EntityTypeName", "CONCENTRATION");
        //updatedb(scenario.getName(), scenario.getStatus().toString(), "POST","YETI-122");
    }

}

