package ApiStepDefinitions;


import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.HashMap;

public class createsupertype_yeti32StepDefinitions extends DBHelper
{
    /** Parser to have JSON Parser */
    JSONParser parser = new JSONParser();
    Scenario scenario;
    JSONObject Response;
    String RequestUnescapedName;
    String ResourcePath="/CreateSuperType";

    public createsupertype_yeti32StepDefinitions(SharedAttributes share) throws Exception {
        Readprerequest();
        reportInstance = SharedClassApi.getReportInstance();
    }

    @Given("Login into ODATA to Create Super Type")
    public void login_into_odata_to_create_super_type() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN","Login into ODATA to Create Super Type");
        Readprerequest();
    }
    @When("Post the request to Create Super Type")
    public void post_the_request_to_create_super_type() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request to Create Super Type");
        RequestUnescapedName="Test Name "+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeValidName.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response,"UnescapedName",RequestUnescapedName);
    }
    @Then("Verify the DB for the created super type")
    public void verify_the_db_for_the_created_super_type() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the DB");

            HashMap results=ExecuteQuery(DbQueries.SelectSuperTypeName+querySearchFormat(RequestUnescapedName));
            int DbValue=results.size();
            if(DbValue==1)
            {
                reportInstance.logPass("Successfully entry in DB",RequestUnescapedName);
            }else
            {
                reportInstance.logFail("Not entered in DB",RequestUnescapedName);
            }

    }

    @When("Post the request with Empty UnescapedName")
    public void post_the_request_with_empty_unescapedname() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithEmptyName.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for Empty UnescapedName")
    public void verify_the_error_message_for_empty_unescapedname() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message for Empty UnescapedName");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_CONTENT_ENTITY, "Property UnescapedName must contain at least 2 letters ([a-zA-Z]);Property UnescapedName must be equal to or longer than 2 characters");
    }
    @When("Post the request with null UnescapedName")
    public void post_the_request_with_null_unescapedname() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithNullName.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for null UnescapedName")
    public void verify_the_error_message_for_null_unescapedname() throws Exception
    {
        reportInstance.logInfo("STEPS","To Verify the error message for null UnescapedName");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, "The property 'UnescapedName' must not be null.");
    }
    @When("Post the request to duplicate Super Type name")
    public void post_the_request_to_duplicate_super_type_name() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithDuplicateName.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for duplicate Super Type name")
    public void verify_the_error_message_for_duplicate_super_type_name() throws Exception
    {
        reportInstance.logInfo("STEPS","To Verify the error message for null UnescapedName");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_DUPLICATE_KEY_CONSTRAINT_VIOLATED, "Duplicate key constraint violated.");
    }

    @When("Post the request without UnescapedName")
    public void post_the_request_without_unescapedname() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithoutName.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for without UnescapedName")
    public void verify_the_error_message_for_without_UnescapedName() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message for without UnescapedName");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_CONTENT_ENTITY, "Request is missing a required property: UnescapedName");
    }
    @Given("Login into ODATA with no permission user")
    public void login_into_odata_with_no_permission_user() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("STEPS","Login into ODATA to Create Super Type");
        ReadprerequestForNoPermissionUser();
    }
    @When("Post the request with no permission user")
    public void post_the_request_with_no_permission_user() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request with no permission user");
        RequestUnescapedName="Test Name "+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeValidName.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_UNAUTHORIZED);
    }
    @Then("Verify the error message for no permission user")
    public void verify_the_error_message_for_no_permission_user() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message for without UnescapedName");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_NO_PERMISSION, "You are not authorized for this operation");
    }
    @When("Post the request with length greater than 64 characters")
    public void post_the_request_with_length_greater_than_64_characters() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithMorethan64Characters.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for greater than 64 characters")
    public void verify_the_error_message_for_greater_than_64_characters() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message for greater than 64 characters");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, "Invalid value for property 'UnescapedName'.");
    }
    @When("Post the request with special characters")
    public void post_the_request_with_special_characters() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request to Create Super Type");
        RequestUnescapedName="@#$!@#$$%&"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithSpecialCharacters.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response,"UnescapedName",RequestUnescapedName);
    }
    @When("Post the request with contains only digits")
    public void post_the_request_with_contains_only_digits() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeOnlyWithNumbers.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for only digits")
    public void verify_the_error_message_for_only_digits() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message for only digits");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_CONTENT_ENTITY, "Property UnescapedName must contain at least 2 letters ([a-zA-Z])");
    }
    @When("Post the request without input body request")
    public void post_the_request_without_input_body_request() throws Exception
    {
        Response = postRequest("{ }", ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for without input body request")
    public void verify_the_error_message_for_without_input_body_request() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message without input body request");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_CONTENT_ENTITY, "Request body must not be empty.");
    }
    @When("Post the request with invalid data type")
    public void post_the_request_with_invalid_data_type() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithInValidName.json");
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message with invalid data type")
    public void verify_the_error_message_with_invalid_data_type() throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the error message without input body request");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, "Invalid value for property 'UnescapedName'.");
    }
    @When("Post the request with minimum of one character")
    public void post_the_request_with_minimum_of_one_character() throws Exception
    {
        reportInstance.logInfo("STEPS","Post the request to Create Super Type");
        RequestUnescapedName=RandomAlphanumericGenerate(1);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithMinimumCharacter.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the error message with minimum one character")
    public void verifyTheErrorMessageWithMinimumOneCharacter() throws Exception {
        reportInstance.logInfo("STEPS","To verify the error message with one character");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_CONTENT_ENTITY, "Property UnescapedName must contain at least 2 letters ([a-zA-Z]);Property UnescapedName must be equal to or longer than 2 characters");
    }

    @When("Post the request with name contains one character and digits")
    public void postTheRequestWithNameContainsOneCharacterAndDigits() throws Exception {
        reportInstance.logInfo("STEPS","Post the request to Create Super Type");
        RequestUnescapedName = "A12345";
        reportInstance.logInfo("STEPS",RequestUnescapedName +
                " will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeWithMinimumCharacter.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the error message with contains one character and digits")
    public void verifyTheErrorMessageWithContainsOneCharacterAndDigits() throws Exception {
        reportInstance.logInfo("STEPS","To verify the error message with one character and digits");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_CONTENT_ENTITY,
                "Property UnescapedName must contain at least 2 letters ([a-zA-Z])");
    }

    @When("Post the request with name contains two characters")
    public void postTheRequestWithNameContainsTwoCharacters() throws Exception {
        reportInstance.logInfo("STEPS","Post the request to Create Super Type");
//        RequestUnescapedName = RandomAlphanumericGenerate(2);
        RequestUnescapedName = "A1";
        while (RequestUnescapedName.matches(".*\\d.*")){
            RequestUnescapedName = RandomAlphanumericGenerate(2);
        }
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperTypeValidName.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response,"UnescapedName",RequestUnescapedName);
    }
}

