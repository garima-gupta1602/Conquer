package ApiStepDefinitions;

import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class UpdateEntityTypeAttributes_Yeti88StepDefinitions extends DBHelper
{
    JSONObject Response;
    String Path="/UpdateEntityTypeAssociations";
    @Given("Preparation for updating an entity type's attribute is done")
    public void on_access_level() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN ","Preparation for updating an entity type's attribute is done");
        Readprerequest();
    }
    @When("Update using the patch request with valid string attribute on entity type")
    public void UpdatePatchRequestForValidString() throws Exception
    {
        reportInstance.logInfo("STEPS","Update using the patch request with valid string attribute on entity type");
        Response = patchRequest("{\"AttributeName\": \"ci_job_cronString\"}", ApiConstants.Route_Update_Type_Attribute, HttpURLConnection.HTTP_OK);
    }
    @Then("Verify the response code for the entity type attribute as {string} and message as {string}")
    public void verify_the_error_message_for_empty_unescapedname(String Code, String Message) throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the entity type attribute");
        VerifyErrorMessage(Response, Code, Message);
    }
    @When("Update using the patch request with invalid string attribute on entity type")
    public void UpdatePatchRequestForInValidString() throws Exception
    {
        reportInstance.logInfo("STEPS","Update using the patch request with invalid string attribute on entity type");
        
        
        Response = patchRequest("{\"AttributeName\": 0}", ApiConstants.Route_Update_Type_Attribute, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @When("Update using the patch request with null string attribute on entity type")
    public void UpdatePatchRequestForNullString() throws Exception
    {
        reportInstance.logInfo("STEPS","Update using the patch request with null string attribute on entity type");
        
        
        Response = patchRequest("{\"AttributeName\": null }", ApiConstants.Route_Update_Type_Attribute, HttpURLConnection.HTTP_OK);
    }
    @When("Update using the patch request with valid integer attribute on entity type")
    public void UpdatePatchRequestForValidInteger() throws Exception
    {
        reportInstance.logInfo("STEPS","Update using the patch request with valid string attribute on entity type");
        
        
        Response = patchRequest("{\"DisplaySeq\": 10}", ApiConstants.Route_Update_Type_Attribute, HttpURLConnection.HTTP_OK);
    }
    @When("Update using the patch request with invalid integer attribute on entity type")
    public void UpdatePatchRequestForInValidinteger() throws Exception
    {
        reportInstance.logInfo("STEPS","Update using the patch request with valid string attribute on entity type");
        
        
        Response = patchRequest("{\"DisplaySeq\": \"invalid value\"}", ApiConstants.Route_Update_Type_Attribute, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @When("Update using the patch request with null integer attribute on entity type")
    public void UpdatePatchRequestForNullInteger() throws Exception
    {
        reportInstance.logInfo("STEPS","Update using the patch request with valid string attribute on entity type");
        
        
        Response = patchRequest("{\"DisplaySeq\": null}", ApiConstants.Route_Update_Type_Attribute, HttpURLConnection.HTTP_OK);
    }



}
