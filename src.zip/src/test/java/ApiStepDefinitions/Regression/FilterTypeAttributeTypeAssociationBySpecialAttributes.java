package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.NoHttpResponseException;
import org.json.simple.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

public class FilterTypeAttributeTypeAssociationBySpecialAttributes extends DBHelper {

    JSONObject Response;
    String stringResponse;



    public synchronized String GetRequest1(String Route, String filterQuery, int ExpectedResponseCode) throws Exception {
        String GetResponse = null;

        try {
            String url = this.Scheme + "://" + this.Host + "/" + Route;
            String encodedURL = url + URLEncoder.encode(filterQuery, "UTF-8").replace("+", "%20");
            URL obj = new URL(encodedURL);
            this.reportInstance.logInfo("", encodedURL, ExtentColor.WHITE);
            HttpURLConnection con = (HttpURLConnection)obj.openConnection();
            con.setRequestMethod("GET");
            HashMap Header = this.DefaultRequestHeader();
            ArrayList<String> HeaderKeys = this.MapKeyToArrayList(Header);

            int responseCode;
            for(responseCode = 0; responseCode < HeaderKeys.size(); ++responseCode) {
                con.setRequestProperty((String)HeaderKeys.get(responseCode), Header.get(HeaderKeys.get(responseCode)).toString());
            }

            responseCode = con.getResponseCode();
            System.out.println("GET Response Code :: " + responseCode);
            if (responseCode != ExpectedResponseCode) {
                this.reportInstance.logFail("", Integer.toString(responseCode) + " message as " + con.getResponseMessage(), ExtentColor.WHITE);
                throw new NoHttpResponseException("thrown as " + responseCode);
            } else {
                System.out.println("Success Message");
                BufferedReader in;
                if (responseCode == 200) {
                    in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                } else {
                    in = new BufferedReader(new InputStreamReader(con.getErrorStream(), "UTF-8"));
                    this.reportInstance.logPass(String.valueOf(ExpectedResponseCode), " is the expected response");
                    System.out.println(GetResponse); }

                StringBuffer content = new StringBuffer();

                String inputLine;
                while((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }

                System.out.println(content);
                this.reportInstance.logInfo("Info", content.toString(), ExtentColor.WHITE);
                this.reportInstance.logInfo("Response Code", Integer.toString(responseCode), ExtentColor.WHITE);
                GetResponse = content.toString();
                in.close();
                return GetResponse;
            }
        } catch (Exception var15) {
            this.reportInstance.logFail("", var15.toString(), ExtentColor.RED);
            System.out.println(var15.getMessage());
            throw var15;
        }
    }

    @Given("Login into Odata for Filter Type Attribute Type Association By Special Attributes")

    public void login_into_Odata_for_filter_type_attribute_type_association_by_special_attributes() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into Odata for Filter Type Attribute Type Association By Special Attributes");
        Readprerequest();
    }

    @When("Send a GET request to filter type attribute by escaped name")

    public void send_a_GET_request_to_filter_type_attribute_by_escaped_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to filter type attribute by escaped name");
        String stringResponse = ApiConstants.Route_TypeAttribute+"?$filter="
                + URLEncoderForRequests("EscapedName eq 'CI_JOB_DESCRIPTION'")
                ;
        stringResponse=GetRequest1(stringResponse,"",HttpURLConnection.HTTP_INTERNAL_ERROR);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for filter type attribute by escaped name")

    public void verify_the_error_message_for_filter_type_attribute_by_escaped_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for filter type attribute by escaped name");
        VerifyErrorMessage(Response,"5000","The edm property 'EscapedName' cannot be used for the purpose of filtering because it is a side filled special property");
    }

    @When("Send a GET request to filter type attribute by vocabulary attribute")

    public void send_a_GET_request_to_filter_type_attribute_by_vocabulary_attribute() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to filter type attribute by vocabulary attribute");
        String stringResponse = ApiConstants.Route_TypeAttribute+"?$filter="
                + URLEncoderForRequests("Vocabulary ne ''")
                ;
        stringResponse=GetRequest1(stringResponse,"",HttpURLConnection.HTTP_INTERNAL_ERROR);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for filter type attribute by vocabulary attribute")

    public void verify_the_error_message_for_filter_type_attribute_by_vocabulary_attribute() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for filter type attribute by vocabulary attribute");
        VerifyErrorMessage(Response,"5000","The edm property 'Vocabulary' cannot be used for the purpose of filtering because it is a side filled special property");
    }

    @When("Send a GET request to filter type association by escaped name")

    public void send_a_GET_request_to_filter_type_association_by_escaped_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to filter type association by escaped name");
        String stringResponse = ApiConstants.Route_TypeAttribute+"?$filter="
                + URLEncoderForRequests("EscapedName eq 'ANIMAL_SUBJECT'")
                ;
        stringResponse=GetRequest1(stringResponse,"",HttpURLConnection.HTTP_INTERNAL_ERROR);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for filter type association by escaped name")

    public void verify_the_error_message_for_filter_type_association_by_escaped_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for filter type association by escaped name");
        VerifyErrorMessage(Response,"5000","The edm property 'EscapedName' cannot be used for the purpose of filtering because it is a side filled special property");
    }


}
