package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class SoftData_SetpDefination extends DBHelper {

    JSONObject Response;
    String stringResponse;

    @Given("^Login into ODATA to get the entity list$")
    public void loginIntoODATAToGetTheEntityList() {
        reportInstance= SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("^Generate the GET request to get list entities with expansion \"([^\"]*)\"$")
    public void generateTheGETRequestToGetListEntitiesWithExpansion(String path) throws Exception {
        stringResponse=GetRequest(ApiConstants.Route_master+path,"");
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^Validate the response data is having \"([^\"]*)\" attribute as String type$")
    public void validateTheResponseDataIsHavingAttributeAsStringType(String SOFT_FLOAT) throws Throwable {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0;i<resp.size();i++) {
            String firstresp=resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            if(Response.get(SOFT_FLOAT) instanceof String) {
                reportInstance.logPass("STEPS",SOFT_FLOAT +" is verified as string");
            } else {
                reportInstance.logFail("STEPS",SOFT_FLOAT +" is verified is not as expected");
            }
        }
    }

    @When("Generate the GET request to get list entities with expansion {string} and the filter parameter {string}")
    public void generate_the_get_request_to_get_list_entities_with_expansion_and_the_filter_parameter(String path, String filterparam) throws Exception {
        String url=ApiConstants.Route_master+path+URLEncoderForRequests(filterparam);
        stringResponse=GetRequest(url," ");
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^Validate the response data is having \"([^\"]*)\" attribute as String type \"([^\"]*)\"$")
    public void validateTheResponseDataIsHavingAttributeAsStringType(String attributename, String attributevalue) throws Throwable {
       VerifyEntityData(Response,attributename,attributevalue);
    }

    @When("^Generate the GET request to get list entities with expansion \"([^\"]*)\" and the filter parameter \"([^\"]*)\" numeric value$")
    public void generateTheGETRequestToGetListEntitiesWithExpansionAndTheFilterParameterNumericValue(String path, String filterparam) throws Throwable {
        String url=ApiConstants.Route_master+path+URLEncoderForRequests(filterparam);
        stringResponse=GetRequest(url,"", HttpURLConnection.HTTP_BAD_REQUEST);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^Validate bad request error message is returned with the attribute \"([^\"]*)\" and \"([^\"]*)\"$")
    public void validateBadRequestErrorMessageIsReturnedWithTheAttributeAnd(String errorCode, String errorMessage)throws Exception {
        VerifyErrorMessage(Response,errorCode,errorMessage);
    }
}
