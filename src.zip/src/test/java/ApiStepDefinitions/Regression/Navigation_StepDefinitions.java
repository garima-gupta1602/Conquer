package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class Navigation_StepDefinitions extends DBHelper {
    JSONObject Response;
    Boolean prerequisite;
    String strResponse;
    String entity;

    @Given("Login into ODATA for Navigation")
    public void Login_into_ODATA_for_Navigation() throws Exception {
       reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("Given: ", "Login into ODATA for Navigation");
        Readprerequest();
    }


    @When("Create a GET request for associated application_minimal metadata with the value {string}")
    public void create_a_get_request_for_associated_application_minimal_metadata_with_the_value(String path) throws Exception {
          GetRequest(ApiConstants.Route_master+path,"",HttpURLConnection.HTTP_OK);
   }

    @When("Create a GET request for associated application_full metadata with the value {string}")
    public void Create_a_GET_request_for_associated_application_full_metadata_with_the_value(String path) throws Exception {
        GetRequest(ApiConstants.Route_master+path, "",UpdateRequestHeader("Accept", "application/json; odata.metadata=full") );
    }

    @When("Create a GET request for Get associated entity type {string}")
    public void Create_a_GET_request_for_Get_associated_entity_type(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

   @When("Create a GET request for Get associated navigation_entity type {string}")
    public void Create_a_GET_request_for_Get_associated_navigation_entity_type(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("^Create a GET request for Get associated navigation_error handling \"([^\"]*)\" and \"([^\"]*)\"$")
    public void createAGETRequestForGetAssociatedNavigation_errorHandlingAnd(String route, String filterparam) throws Exception {
       String url=ApiConstants.Route_master+route+URLEncoderForRequests(filterparam);
        GetRequest(url,"",HttpURLConnection.HTTP_OK);
    }

   @When("Create a GET request for Get associated navigation_List Functions {string}")
    public void Create_a_GET_request_for_Get_associated_navigation_List_Functions(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Get associated navigation_Functions {string}")
    public void Create_a_GET_request_for_Get_associated_navigation_Functions(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Get associated navigation_Menu items {string}")
    public void Create_a_GET_request_for_Get_associated_navigation_Menu_items(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Single Entity through Resource path {string}")
    public void Create_a_GET_request_for_Single_Entity_through_Resource_path(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Single Entity through Expansion query option {string}")
    public void Create_a_GET_request_for_Single_Entity_through_Expansion_query_option(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Single Entity through Entity collection expansion {string}")
    public void Create_a_GET_request_for_Single_Entity_through_Entity_collection_expansion(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Single Entity through Single Entity resource path {string}")
    public void Create_a_GET_request_for_Single_Entity_through_Single_Entity_resource_path(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Single Entity through Entity Collection resource path {string}")
    public void Create_a_GET_request_for_Single_Entity_through_Entity_Collection_resource_path(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Navigation to Entity Collection through Resource path {string}")
    public void Create_a_GET_request_for_Navigation_to_Entity_Collection_through_Resource_path(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Navigation to Entity Collection through Expansion query option {string}")
    public void Create_a_GET_request_for_Navigation_to_Entity_Collection_through_Expansion_query_option(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Navigation to Entity Collection through Entity collection expansion {string}")
    public void Create_a_GET_request_for_Navigation_to_Entity_Collection_through_Entity_collection_expansion(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Navigation to Entity Collection through Single Entity resource path {string}")
    public void Create_a_GET_request_for_Navigation_to_Entity_Collection_through_Single_Entity_resource_path(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for entity type without functions configured {string}")
    public void Create_a_GET_request_for_entity_type_without_functions_configured(String route) throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for entity type without functions configured");
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for functions of entity type SAMPLE {string}")
    public void Create_a_GET_request_for_functions_of_entity_type_SAMPLE(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for functions of entity type SAMPLE_LOT {string}")
    public void Create_a_GET_request_for_functions_of_entity_type_SAMPLE_LOT(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("^Create a GET request for list functions of entity type STABILITY SAMPLE \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void createAGETRequestForListFunctionsOfEntityTypeSTABILITYSAMPLEAndAnd(String route, String filterparam1, String filterparam2) throws Exception {
        String url=ApiConstants.Route_master+route+URLEncoderForRequests(filterparam1)+filterparam2;
        GetRequest(url,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for list functions of entity type STABILITY SAMPLE LOT {string} and {string} and {string}")
    public void Create_a_GET_request_for_list_functions_of_entity_type_STABILITY_SAMPLE_LOTAndAnd(String route, String filterparam1, String filterparam2) throws Exception {
        String url=ApiConstants.Route_master+route+URLEncoderForRequests(filterparam1)+filterparam2;
        GetRequest(url,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Entity Collection through Entity Collection resource path {string}")
    public void Create_a_GET_request_for_Entity_Collection_through_Entity_Collection_resource_path(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for sample through a published experiment {string}")
    public void Create_a_GET_request_for_sample_through_a_published_experiment(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for sample lot through a published experiment {string}")
    public void Create_a_GET_request_for_sample_lot_through_a_published_experiment(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for sample through a unpublished experiment {string}")
    public void Create_a_GET_request_for_sample_through_a_unpublished_experiment(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for sample lot through a unpublished experiment {string}")
    public void Create_a_GET_request_for_sample_lot_through_a_unpublished_experiment(String route) throws Exception {
        GetRequest(ApiConstants.Route_master+route,"",HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Filter experiment samples from sample {string} and {string}")
    public void Create_a_GET_request_for_Filter_experiment_samples_from_sample(String path, String filterparam) throws Exception {
        String url=ApiConstants.Route_master+path+URLEncoderForRequests(filterparam);
        GetRequest(url,"",HttpURLConnection.HTTP_OK);
   }
}
