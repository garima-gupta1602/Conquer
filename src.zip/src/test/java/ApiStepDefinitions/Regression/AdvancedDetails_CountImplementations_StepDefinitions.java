package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.IOException;
import java.net.HttpURLConnection;

public class AdvancedDetails_CountImplementations_StepDefinitions extends DBHelper{
    JSONObject Response;
    String strResponse;
    Boolean prerequisite;
    String entity;
    HttpURLConnection conn;

    @Given("Login into ODATA for AdvancedDetails_CountImplementations")
    public void Login_into_ODATA_for_AdvancedDetails_CountImplementations() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request for Count total number of entity {string}")
    public void Create_a_GET_request_for_Count_total_number_of_entity(String string) throws Exception {
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
    }

    @Then("verify the count")
    public void verify_the_count() throws IOException {
        int count = Integer.parseInt(strResponse);
        reportInstance.logInfo("verifying if number", String.valueOf(count));
    }

    @When("Create a GET request for Count number of association of an entity {string}")
    public void Create_a_GET_request_for_Count_number_of_association_of_an_entity(String string) throws Exception {
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
    }

    @When("Create a GET request for Count number of entity by attribute filtering {string} and {string}")
    public void Create_a_GET_request_for_Count_number_of_entity_by_attribute_filtering(String string, String string2) throws Exception {
        string = string+URLEncoderForRequests(string2);
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
    }

    @When("Create a GET request for Count number of entity by filtering association {string} and {string}")
    public void Create_a_GET_request_for_Count_number_of_entity_by_filtering_association(String string, String string2) throws Exception {
        string = string+URLEncoderForRequests(string2);
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
    }

    @When("Create a GET request for Count number of entity by lambda expression {string} and {string}")
    public void Create_a_GET_request_for_Count_number_of_entity_by_lambda_expression(String string, String string2) throws Exception {
        string = string+URLEncoderForRequests(string2);
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
    }

    @When("Create a GET request for Count number of association of entity set with expand {string}")
    public void Create_a_GET_request_for_Count_number_of_association_of_entity_set_with_expand(String string) throws Exception {
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
    }

    @Then("verify the count for expand")
    public void verify_the_count_for_expand() throws Exception {
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(strResponse), "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String entity = GetattributefromResponse(Response, "PROJECT@odata.count");
                int count = Integer.parseInt(entity);
                reportInstance.logInfo("verifying if number", String.valueOf(count));
            }
            break;
        }
    }

    @When("Create a GET request for Count number of association of entity with expand {string}")
    public void Create_a_GET_request_for_Count_number_of_association_of_entity_with_expand(String string) throws Exception {
        strResponse=GetRequest(ApiConstants.Route_master+string, "");
        entity=GetattributefromResponse(StringToJSONObject(strResponse), "PROJECT@odata.count");
        strResponse=entity;
    }

    @When("Create a GET request for Count on specific entity {string}")
    public void Create_a_GET_request_for_Count_on_specific_entity(String string) throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for Count on specific entity");
        strResponse=GetRequest(ApiConstants.Route_master+string,"", HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for Count on specific entity {string}")
    public void verify_error_message_for_Count_on_specific_entity(String string) throws Exception {
        reportInstance.logInfo("When: ", "verify error message for Count on specific entity");
        Response=StringToJSONObject(strResponse);
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_ENTITY_NOT_FOUND, string);
    }

    @When("Create a GET request for Count on single type navigation property {string}")
    public void Create_a_GET_request_for_Count_on_single_type_navigation_property(String string) throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for Count on single type navigation property");
        strResponse=GetRequest(ApiConstants.Route_master+string,"", HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for Count on single type navigation property {string}")
    public void verify_error_message_for_Count_on_single_type_navigation_property(String string) throws Exception {
        reportInstance.logInfo("When: ", "verify error message for Count on single type navigation property");
        Response=StringToJSONObject(strResponse);
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_ENTITY_NOT_FOUND, string);
    }

    @When("Create a GET request for Count on single type expansion {string}")
    public void Create_a_GET_request_for_Count_on_single_type_expansion(String string) throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for Count on single type expansion");
        strResponse=GetRequest(ApiConstants.Route_master+string,"", HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for Count on single type expansion {string} and {string}")
    public void verify_error_message_for_Count_on_single_type_expansion(String string, String string2) throws Exception {
        reportInstance.logInfo("When: ", "verify error message for Count on single type navigation property");
        Response=StringToJSONObject(strResponse);
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_READING_ENTITY, string, ApiConstants.ERROR_CODE_MISSING_NON_NULLABLE_PROPERTIES, string2);
    }

    @When("Create a GET request for Count on single type navigation property with filter {string} and {string}")
    public void Create_a_GET_request_for_Count_on_single_type_navigation_property_with_filter(String string, String string2) throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for Count on single type navigation property with filter");
        string = string + URLEncoderForRequests(string2);
        strResponse=GetRequest(ApiConstants.Route_master+string,"", HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for Count on single type navigation property with filter {string}")
    public void verify_error_message_for_Count_on_single_type_navigation_property_with_filter(String string) throws Exception {
        reportInstance.logInfo("When: ", "verify error message for Count on single type navigation property with filter");
        Response=StringToJSONObject(strResponse);
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_ENTITY_NOT_FOUND, string);
    }

    @When("Create a GET request for Count inside single type expansion {string}")
    public void Create_a_GET_request_for_Count_inside_single_type_expansion(String string) throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for Count inside single type expansion");
        strResponse=GetRequest(ApiConstants.Route_master+string,"", HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for Count inside single type expansion {string} and {string}")
    public void verify_error_message_for_Count_inside_single_type_expansion(String string, String string2) throws Exception {
        reportInstance.logInfo("When: ", "verify error message for Count inside single type expansion");
        Response=StringToJSONObject(strResponse);
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_READING_ENTITY, string, ApiConstants.ERROR_CODE_MISSING_NON_NULLABLE_PROPERTIES, string2);
    }
}
