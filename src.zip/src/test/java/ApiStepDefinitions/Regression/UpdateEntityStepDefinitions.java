package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
public class UpdateEntityStepDefinitions extends DBHelper{
    JSONObject Response;
    String ResourcePath = "/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity";
    String name;


    @Given("Login into ODATA for UpdateEntity")
    public void login_into_ODATA_for_UpdateEntity() throws Exception {
        reportInstance=SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a PUT request for Update entity id to null {string}")
    public void create_a_PUT_request_for_Update_entity_id_to_null(String route) throws Exception {
        //prerequiste
        JSONObject prerequest=ReadJsonInput(ResourcePath+ "/UpdateEntityPrereq.json");
        Response=postRequest(prerequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
        name=GetattributefromResponse(Response,"Name");
        //Put Request
        JSONObject request=ReadJsonInput(ResourcePath+"/UpdateEntityIdToNull.json");
        Response=putRequest(request.toString(), ApiConstants.Route_master+route.concat("('"+name+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify error message for Update entity id to null {string}")
    public void Verify_error_message_for_Update_entity_id_to_null(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, errorMessage);
    }

    @When("Create a PUT request for entity with omitted nullable properties having default values {string}")
    public void Create_a_PUT_request_for_entity_with_omitted_nullable_properties_having_default_values(String route) throws Exception {
        //prerequisite
        JSONObject prerequest=ReadJsonInput(ResourcePath+ "/UpdateEntityPrereq.json");
        Response=postRequest(prerequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
        //deleting default attributes
        Response.remove("DEFAULT_MANDATORY_ATTRIBUTE");
        Response.remove("DEFAULT_NON_MANDATORY_ATTRIBUTE");
        Response.remove("@odata.context");
        name=GetattributefromResponse(Response,"Name");
        //Put Request
        Response=putRequest(Response.toJSONString(), ApiConstants.Route_master+route.concat("('"+name+"')"), HttpURLConnection.HTTP_OK);
    }

    @When("Create a PUT request for entity setting nullable properties having default values to null {string}")
    public void Create_a_PUT_request_for_entity_setting_nullable_properties_having_default_values_to_null(String route) throws Exception {
        //prerequisite
        JSONObject prerequest=ReadJsonInput(ResourcePath+ "/UpdateEntityPrereq.json");
        Response=postRequest(prerequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
        //setting default attributes to null
        Response.replace("DEFAULT_MANDATORY_ATTRIBUTE", null);
        Response.replace("DEFAULT_NON_MANDATORY_ATTRIBUTE", null);
        Response.remove("@odata.context");
        name=GetattributefromResponse(Response,"Name");
        //Put Request
        Response=putRequest(Response.toJSONString(), ApiConstants.Route_master+route.concat("('"+name+"')"), HttpURLConnection.HTTP_OK);
    }

    @When("Create a PUT request for entity with omitted non nullable updatable properties not having default values {string}")
    public void Create_a_PUT_request_for_entity_with_omitted_non_nullable_updatable_properties_not_having_default_values(String route) throws Exception {
        //prerequisite
        JSONObject prerequest=ReadJsonInput(ResourcePath+ "/UpdateEntityPrereq.json");
        Response=postRequest(prerequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
        //removing Active Attribute
        Response.remove("Active");
        Response.remove("@odata.context");
        name=GetattributefromResponse(Response,"Name");
        //Put Request
        Response=putRequest(Response.toJSONString(), ApiConstants.Route_master+route.concat("('"+name+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify error message for Update entity {string} and {string}")
    public void Verify_error_message_for_Update_entity(String errorMessage, String detailedErrorMessage) throws Exception {
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_UPDATING_ENTITY, errorMessage, ApiConstants.ERROR_CODE_MISSING_NON_NULLABLE_PROPERTIES, detailedErrorMessage);
    }

    @When("Create a PUT request for entity set non nullable updatable properties not having default values to null {string}")
    public void Create_a_PUT_request_for_entity_set_non_nullable_updatable_properties_not_having_default_values_to_null(String route) throws Exception {
        //prerequisite
        JSONObject prerequest=ReadJsonInput(ResourcePath+ "/UpdateEntityPrereq.json");
        Response=postRequest(prerequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
        //setting Active Attribute to null
        Response.replace("Active", null);
        Response.remove("@odata.context");
        name=GetattributefromResponse(Response,"Name");
        //Put Request
        Response=putRequest(Response.toJSONString(), ApiConstants.Route_master+route.concat("('"+name+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify error message Update entity {string}")
    public void Verify_error_message_Update_entity(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, errorMessage);
    }
}
