package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;


public class FilterbyNullValue_StepDefination extends DBHelper {
    JSONObject Response;
    String stringResponse;

    @Given("^Login into ODATA for get entities$")
    public void loginIntoODATAForGetEntities() {
        reportInstance= SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("^Send GET request to filter the entities by null value with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void sendGETRequestToFilterTheEntitiesByNullValueWithAnd(String route, String filterparam) throws Throwable {
        String url= ApiConstants.Route_master+route+URLEncoderForRequests(filterparam);
        stringResponse=GetRequest(url,"", HttpURLConnection.HTTP_OK);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^Validate \"([^\"]*)\" is having null value$")
    public void validateIsHavingNullValue(String Attribute) throws Throwable {
        JSONArray resp = JSONObjectToJsonArray(Response,"value");
        for(int i=0;i<resp.size();i++){
            String firstresp=resp.get(i).toString();
            Response=StringToJSONObject(firstresp);
                if(Response.get(Attribute)==null)
                    reportInstance.logPass("Attribute Attribute","the value is null");
                else
                    reportInstance.logFail("Attribute validation","attribute is not null");
        }
    }

    @Then("^Validate \"([^\"]*)\" is having either  true or false$")
    public void validateIsHavingEitherTrueOrFalse(String attribute)throws Throwable {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            boolean booleanvalue= (boolean) Response.get(attribute);
            if (booleanvalue==true)
                reportInstance.logPass(" Attribute", "the value is true");
            else if(booleanvalue==false)
                reportInstance.logPass(" Attribute", "the value is false");
            else
                reportInstance.logFail("boolean value","attribute does not caontain the required value");

        }
    }

    @Then("^Validate \"([^\"]*)\" is having attribute type as string$")
    public void validateIsHavingAttributeTypeAsString(String stringAttibute) throws Throwable {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0;i<resp.size();i++){
            String firstresp=resp.get(i).toString();
            Response=StringToJSONObject(firstresp);
            if(Response.get(stringAttibute)instanceof String)
                reportInstance.logPass("String Attribute","Attribute type is string");
            else
                reportInstance.logFail("String Attribute","Attribute type is not string");
        }
    }

    @When("^Send GET request to filter the entities by null value with \"([^\"]*)\" and \"([^\"]*)\"  bad rerquest is returned$")
    public void sendGETRequestToFilterTheEntitiesByNullValueWithAndBadRerquestIsReturned(String route, String filterparam) throws Throwable {
        String url= ApiConstants.Route_master+route+URLEncoderForRequests(filterparam);
        stringResponse=GetRequest(url,"", HttpURLConnection.HTTP_BAD_REQUEST);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^Validate  error message and code having \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void validateErrorMessageAndCodeHavingAndAndAnd(String code, String message, String detailcode, String detailmessage) throws Throwable {
        VerifyErrorMessageWithinDetails(Response,code,message,detailcode,detailmessage);
    }


}
