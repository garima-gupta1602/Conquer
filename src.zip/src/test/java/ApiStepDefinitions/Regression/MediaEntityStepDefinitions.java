package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Base64;
import java.util.HashMap;

public class MediaEntityStepDefinitions extends DBHelper {

    JSONObject Response;
    String StrFileName;
    HttpURLConnection conn;
    String ResourcePath = "YETI/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity";

    @Given("Login into ODATA for MediaEntity")
    public void login_into_ODATA_for_MediaEntity() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a POST request with default Prefer header {string} and {string} and {string}")
    public void create_a_POST_request_with_default_Prefer_header(String route, String headerKey, String headerValue) throws Exception {
        StrFileName = "resources/YETI/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity/tf.png";
        String encodedfile = encodeString(StrFileName);
        conn = SendRequest(ApiConstants.Route_master+route, encodedfile, UpdateRequestHeader(headerKey, headerValue), "POST");
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify entity created with default Prefer header {string}")
    public void Verify_entity_created_with_default_Prefer_header(String entityName) throws Exception {
        String strResponse= GetResponseBody(conn);
        Response=StringToJSONObject(strResponse);
        VerifyEntityData(Response, "EntityTypeName", entityName);
    }

    @When("Create a POST request with minimal return {string}")
    public void create_a_POST_request_with_minimal_return(String route) throws Exception {
        StrFileName = "resources/YETI/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity/tf.png";
        String encodedfile = encodeString(StrFileName);
        HashMap<String, String> newheader = UpdateRequestHeader("Content-Type", "image/png");
        newheader.put("prefer", "return=minimal");
        newheader.put("tfs-platform-tenantalias", "tenant_001");
        conn = SendRequest(ApiConstants.Route_master+route, encodedfile, newheader, "POST");

    }

    @Then("Verify No Content with minimal return")
    public void Verify_No_Content_with_minimal_return() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }

    @When("Create a PUT request for Update image entity {string} and {string} and {string} and {string}")
    public void Create_a_PUT_request_for_Update_image_entity(String route, String filterParam, String headerKey, String headerValue) throws Exception {
        StrFileName = "resources/YETI/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity/tf.png";
        String encodedfile = encodeString(StrFileName);
        conn = SendRequest(ApiConstants.Route_master+route, encodedfile, UpdateRequestHeader(headerKey, headerValue), "POST");
        String strResponse= GetResponseBody(conn);
        Response=StringToJSONObject(strResponse);
        String imgName= GetattributefromResponse(Response, "Name");
        conn = SendRequest(ApiConstants.Route_master+route+"('"+imgName+"')"+filterParam+"", encodedfile, UpdateRequestHeader(headerKey, headerValue), "PUT");
    }

    @Then("Verify No Content for Update image entity")
    public void Verify_No_Content_for_Update_image_entity() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }

    @When("Create a GET request for Get stream property with no data {string} and {string}")
    public void Create_a_GET_request_for_Get_stream_property_with_no_data(String route, String filterParam) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route, "{}", DefaultRequestHeader(), "POST");
        String strResponse= GetResponseBody(conn);
        Response=StringToJSONObject(strResponse);
        String imgName= GetattributefromResponse(Response, "Name");
        conn = SendRequest(ApiConstants.Route_master+route+"('"+imgName+"')"+filterParam+"", "", DefaultRequestHeader(), "GET");
    }

    @Then("Verify No Content for Get stream property with no data")
    public void Verify_No_Content_for_Get_stream_property_with_no_data() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }

    @When("Create a GET request for Get stream property with empty value {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_for_Get_stream_property_with_empty_value(String route, String filterParam, String headerKey, String headerValue) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route, "{}", DefaultRequestHeader(), "POST");
        String strResponse= GetResponseBody(conn);
        Response=StringToJSONObject(strResponse);
        String imgName= GetattributefromResponse(Response, "Name");
        conn = SendRequest(ApiConstants.Route_master+route+"('"+imgName+"')"+filterParam+"", "", UpdateRequestHeader(headerKey, headerValue), "PUT");
        conn = SendRequest(ApiConstants.Route_IMAGE_MANIPULATOR+"('"+imgName+"')/CI_DT_IMAGE_MANIPULATOR", "", DefaultRequestHeader(), "GET");
    }

    @Then("Verify No Content for Get stream property with empty value")
    public void Verify_No_Content_for_Get_stream_property_with_empty_value() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }

    @When("Create a GET request for Get stream entity with no data {string} and {string}")
    public void Create_a_GET_request_for_Get_stream_entity_with_no_data(String route, String filterParam) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route, "{}", DefaultRequestHeader(), "POST");
        String strResponse= GetResponseBody(conn);
        Response=StringToJSONObject(strResponse);
        String imgName= GetattributefromResponse(Response, "Name");
        conn = SendRequest(ApiConstants.Route_IMAGE+"('"+imgName+"')"+filterParam+"", "", UpdateRequestHeader("Content-Type", "text/plain"), "GET");
    }

    @Then("Verify No Content for Get stream entity with no data")
    public void Verify_No_Content_for_Get_stream_entity_with_no_data() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }

    @When("Create a GET request for Get stream entity with empty value {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_for_Get_stream_entity_with_empty_value(String route, String headerKey, String headerValue, String filterParam) throws Exception {
        StrFileName = "resources/YETI/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity/tf.png";
        String encodedfile = encodeString(StrFileName);
        conn = SendRequest(ApiConstants.Route_master+route, encodedfile, UpdateRequestHeader(headerKey, headerValue), "POST");
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_CREATED);
        String strResponse= GetResponseBody(conn);
        Response=StringToJSONObject(strResponse);
        String imgName= GetattributefromResponse(Response, "Name");
        conn = SendRequest(ApiConstants.Route_master+route+"('"+imgName+"')"+filterParam+"", "", UpdateRequestHeader(headerKey, headerValue), "PUT");
        conn = SendRequest(ApiConstants.Route_master+route+"('"+imgName+"')"+filterParam+"", "", UpdateRequestHeader(headerKey, headerValue), "GET");
    }

    @Then("Verify No Content for Get stream entity with empty value")
    public void Verify_No_Content_for_Get_stream_entity_with_empty_value() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }
    }
