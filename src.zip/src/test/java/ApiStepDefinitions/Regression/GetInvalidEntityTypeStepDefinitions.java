package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.NoHttpResponseException;
import org.json.simple.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

public class GetInvalidEntityTypeStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;

    public HashMap UpdateRequestHeader1(String Key, String Value) throws Exception {
        HashMap<String, String> Header = new HashMap();
        Header.put("Authorization", Authorization);
        Header.put("Cache-Control", "no-cache");
        Header.put("Content-Type", "application/json");
        Header.put("Accept", "*/*");
        Header.put("User-Agent", "Mozilla/5.0");
        Header.put("Accept-Encoding", "gzip, deflate, br");
        Header.put("Connection", "keep-alive");
        Header.put("Host", this.Host);
        if (this.TenantFlag) {
            Header.put("Tenant", "tenant_001");
        }

        Header.put(Key, Value);
        this.reportInstance.logInfo("Updating the header ", (String)Header.get(Key));
        return Header;
    }


    public synchronized String GetRequest1(String Route, String filterQuery, int ExpectedResponseCode) throws Exception {
        String GetResponse = null;

        try {
            String url = this.Scheme + "://" + this.Host + "/" + Route;
            String encodedURL = url + URLEncoder.encode(filterQuery, "UTF-8").replace("+", "%20");
            URL obj = new URL(encodedURL);
            this.reportInstance.logInfo("", encodedURL, ExtentColor.WHITE);
            HttpURLConnection con = (HttpURLConnection)obj.openConnection();
            con.setRequestMethod("GET");
            HashMap Header = this.DefaultRequestHeader();
            ArrayList<String> HeaderKeys = this.MapKeyToArrayList(Header);

            int responseCode;
            for(responseCode = 0; responseCode < HeaderKeys.size(); ++responseCode) {
                con.setRequestProperty((String)HeaderKeys.get(responseCode), Header.get(HeaderKeys.get(responseCode)).toString());
            }

            responseCode = con.getResponseCode();
            System.out.println("GET Response Code :: " + responseCode);
            if (responseCode != ExpectedResponseCode) {
                this.reportInstance.logFail("", Integer.toString(responseCode) + " message as " + con.getResponseMessage(), ExtentColor.RED);
                throw new NoHttpResponseException("thrown as " + responseCode);
            } else {
                System.out.println("Success Message");
                BufferedReader in;
                if (responseCode == 200) {
                    in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                } else {
                    in = new BufferedReader(new InputStreamReader(con.getErrorStream(), "UTF-8"));
                    this.reportInstance.logPass(String.valueOf(ExpectedResponseCode), " is the expected response");
                    System.out.println(GetResponse); }

                StringBuffer content = new StringBuffer();

                String inputLine;
                while((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }

                System.out.println(content);
                this.reportInstance.logInfo("Info", content.toString(), ExtentColor.WHITE);
                this.reportInstance.logInfo("Response Code", Integer.toString(responseCode), ExtentColor.WHITE);
                GetResponse = content.toString();
                in.close();
                return GetResponse;
            }
        } catch (Exception var15) {
            this.reportInstance.logFail("", var15.toString(), ExtentColor.RED);
            System.out.println(var15.getMessage());
            throw var15;
        }
    }


    @Given("Login into Odata for Get Invalid Entity Type")

    public void login_into_Odata_for_get_invalid_entity_type() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into Odata for Error Handling");
        Readprerequest();
    }

    @When("Send a GET request to get Enum type information")

    public void send_a_GET_request_to_get_enum_type_information() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to get Enum type information");
       stringResponse=GetRequest1(ApiConstants.cell_quantity,"",HttpURLConnection.HTTP_NOT_FOUND);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for enum type information")

    public void verify_the_error_message_for_enum_type_information() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for enum type information");
        VerifyErrorMessage(Response,"1001","Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name 'CELL_QUANTITY_TYPE'.");
    }
     @When("Send a GET request to get entity type not based on pfs.Entity")

    public void send_a_GET_request_to_get_entity_type_not_based_on_pfs_entity() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to get entity type not based on pfs.Entity");
         stringResponse=GetRequest1(ApiConstants.decimal_agg_fun,"",HttpURLConnection.HTTP_NOT_FOUND);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for entity type not based on pfs.Entity")

    public void verify_the_error_message_for_entity_type_not_based_on_pfs_entity() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for entity type not based on pfs.Entity");
        VerifyErrorMessage(Response,"1001","Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name 'DECIMAL_AGG_FUNCTIONS'.");
    }
    @When("Send a GET request to get child of entity type not based on pfs entity")

    public void send_a_GET_request_to_get_child_of_entity_type_not_based_on_pfs_entity() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to get child of entity type not based on pfs entity");
         stringResponse=GetRequest1(ApiConstants.negative_gustatory_assay,"",HttpURLConnection.HTTP_NOT_FOUND);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for child of entity type not based on pfs.Entity")

    public void verify_the_error_message_for_child_of_entity_type_not_based_on_pfs_entity() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for child of entity type not based on pfs.Entity");
        VerifyErrorMessage(Response,"1001","Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name 'NEGATIVE_GUSTATORY_ASSAY_ATTRIBUTES_AGGREGATION'.");
    }

    @When("Send a GET request to get entity type does not exist in system")

    public void send_a_GET_request_to_get_entity_type_does_not_exist_in_system() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to get entity type does not exist in system");
       stringResponse=GetRequest1(ApiConstants.container_transfer,"",HttpURLConnection.HTTP_NOT_FOUND);
        Response=StringToJSONObject(stringResponse);
    }

    @Then("Verify the error message for entity type does not exist in system")

    public void verify_the_error_message_for_entity_type_does_not_exist_in_system() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for entity type does not exist in system");
        VerifyErrorMessage(Response,"1001","Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name 'CONTAINER_TRANSFER'.");
    }







}
