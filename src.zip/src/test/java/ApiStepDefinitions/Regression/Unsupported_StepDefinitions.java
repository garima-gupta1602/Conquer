package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import java.net.HttpURLConnection;

public class Unsupported_StepDefinitions extends DBHelper {
    String stringResponse;
    HttpURLConnection conn;
    JSONObject Response;

    @Given("Login into ODATA for Unsupported")
    public void login_into_ODATA_for_Unsupported() throws Exception{
        reportInstance=SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request for Filter with unsupported property of canonical function {string} and {string}")
    public void Create_a_GET_request_for_Filter_with_unsupported_property_of_canonical_function(String route, String filterparam) throws Exception{
        stringResponse = GetRequest(ApiConstants.Route_master+route, filterparam, HttpURLConnection.HTTP_NOT_IMPLEMENTED);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify error message {string} for Filter with unsupported property of canonical function")
    public void Verify_error_message_for_Filter_with_unsupported_property_of_canonical_function(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_READING_ENTITY, errorMessage);
    }

   @When("Create a GET request for Prefer header Return Equal Representation {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_for_Prefer_header_Return_Equal_Representation(String route, String headerKey, String headerValue, String requestType) throws Exception{
        conn= SendRequest(ApiConstants.Route_master+route, " ",UpdateRequestHeader(headerKey,headerValue),requestType);
       ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_INTERNAL_ERROR);
       String resBody = GetResponseBody(conn);
       Response=StringToJSONObject(resBody);
    }

    @Then("Verify error message {string} for Prefer header Return Equal Representation")
    public void Verify_error_message_for_Prefer_header_Return_Equal_Representation(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_HEADER_NOT_SUPPORTED, errorMessage);
    }

    @When("Create a GET request for Prefer header Return Equal Minimal {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_for_Prefer_header_Return_Equal_Minimal(String route, String headerKey, String headerValue, String requestType) throws Exception{
        conn =SendRequest(ApiConstants.Route_master+route, " ",UpdateRequestHeader(headerKey,headerValue),requestType);
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_INTERNAL_ERROR);
        String resBody = GetResponseBody(conn);
        Response=StringToJSONObject(resBody);
    }

    @Then("Verify error message {string} for Prefer header Return Equal Minimal")
    public void Verify_error_message_for_Prefer_header_Return_Equal_Minimal(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_HEADER_NOT_SUPPORTED, errorMessage);
    }

    @When("Create a DELETE request for Prefer header Return Equal Representation {string} and {string} and {string} and {string}")
    public void Create_a_DELETE_request_for_Prefer_header_Return_Equal_Representation(String route, String headerKey, String headerValue, String requestType) throws Exception{
        conn =SendRequest(ApiConstants.Route_master+route, " ",UpdateRequestHeader(headerKey,headerValue),requestType);
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_INTERNAL_ERROR);
        String resBody = GetResponseBody(conn);
        Response=StringToJSONObject(resBody);
    }

    @Then("Verify delete error message {string} for Prefer header Return Equal Representation")
    public void Verify_delete_error_message_for_Prefer_header_Return_Equal_Representation(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_HEADER_NOT_SUPPORTED, errorMessage);
    }
    @When("Create a DELETE request for Prefer header Return Equal Minimal {string} and {string} and {string} and {string}")
    public void Create_a_DELETE_request_for_Prefer_header_Return_Equal_Minimal(String route, String headerKey, String headerValue, String requestType) throws Exception{
        conn =SendRequest(ApiConstants.Route_master+route, " ",UpdateRequestHeader(headerKey,headerValue),requestType);
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_INTERNAL_ERROR);
        String resBody = GetResponseBody(conn);
        Response=StringToJSONObject(resBody);
    }

    @Then("Verify delete error message {string} for Prefer header Return Equal Minimal")
    public void Verify_delete_error_message_for_Prefer_header_Return_Equal_Minimal(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_HEADER_NOT_SUPPORTED, errorMessage);
    }
}
