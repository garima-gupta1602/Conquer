package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class EscapeAndUnescapePropertyFiltering_StepDefination extends DBHelper {

    JSONObject Response,Request;
    String stringResponse;
    String RequestUnescapedName;
    String RandomName;

    @Given("^Login into ODATA for Escape and Unescape property in filtering$")
    public void loginIntoODATAForEscapeAndUnescapePropertyInFiltering()  {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("^Send a POST request to create a entity with a value \"([^\"]*)\"$")
    public void sendAPOSTRequestToCreateAEntityWithAValue(String route) throws Throwable {
        Request=ReadJsonInput("/EscapeAndUnescapePropertyFiltering/EscapeUnescapeFiltering.json");
        RandomName=RandomAlphanumericGenerate(6);
        RequestUnescapedName="CRT19 ' "+RandomName;

        Request.put("Name",RequestUnescapedName);
        Response=postRequest(Request.toString(),ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
    }

    @And("^Send the GET request with the value \"([^\"]*)\" and filter parameter \"([^\"]*)\"$")
    public void sendTheGETRequestWithTheValueAndFilterParameter(String route, String filterparam) throws Throwable {
        String url= ApiConstants.Route_master + route+ URLEncoderForRequests(filterparam)+RandomName+"'";
        stringResponse=GetRequest(url,"");
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^validate the response with the EntityTypeName as \"([^\"]*)\"$")
    public void validateTheResponseWithTheEntityTypeNameAs(String EntityTypeName) throws Throwable {
        JSONArray resp =  JSONObjectToJsonArray(Response,"value");
        for(int i=0;i<resp.size();i++){
            String firstresp=resp.get(i).toString();
            Response=StringToJSONObject(firstresp);
            String name= GetattributefromResponse(Response, "Name");
            VerifyEntityData(Response,"Name",String.valueOf(name));
        }
    }
}
