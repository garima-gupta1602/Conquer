package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.common.Utils;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.bcel.verifier.exc.AssertionViolatedException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.tools.ant.taskdefs.Get;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;

public class LISTStepDefinitions extends DBHelper
{
    public JSONObject Response;
    HttpURLConnection conn;
    String ResourcePath="/LIST/";
    String id;
    String Barcode;
    int totalmembersize=0;
    ArrayList<String> NewIdsCreated=new ArrayList<>();

    @Given("Prepare the Auth for the LIST Entities")
    public void prepare_the_Auth_for_the_LIST_Entities() throws Exception{
        reportInstance= SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Perform a GET Request in the LIST Functions with value {string} and filter param {string}")
    public void perform_a_GET_Request_in_the_LIST_Functions_with_filter(String param1,String param2 ) throws Exception {
        String Route= ApiConstants.Route_master+param1+URLEncoderForRequests(param2);
        conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

    @Then("Verify the entities of LIST function response")
    public void verify_the_entities_of_LIST_function_response() throws Exception {
        Response=ResponseOutput(conn, HttpStatus.SC_OK,false,new HashMap());
    }

    @When("Perform a GET Request in the LIST Functions with expand {string} and {string}")
    public void perform_a_GET_Request_in_the_LIST_Functions_with_expand_and(String path,String param) throws Exception {
        String Route= ApiConstants.Route_master+path+URLEncoderForRequests(param);
        conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

    @When("Perform a GET Request in the LIST enities with expansion {string} and {string}")
    public void perform_a_GET_Request_in_the_LIST_enities_with_expansion_and(String path,String param) throws Exception
    {
        String Route= ApiConstants.Route_master+path+URLEncoderForRequests(param);
        conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

    @Then("Verify the entities of LIST with Expansion")
    public void verify_the_entities_of_LIST_with_Expansion() throws Exception
    {
        Response=ResponseOutput(conn, HttpStatus.SC_OK,false,new HashMap());
        JSONArray array=JSONObjectToJsonArray(Response,"value");
        boolean ListMemberFlag=false;
        if(array.size()>0)
        {
            for (int i = 0; i < array.size(); i++)
            {
                JSONObject currentResponse= (JSONObject) array.get(i);
                JSONArray LISTMEMBERS=JSONObjectToJsonArray(currentResponse,"LIST_MEMBERS");
                if(LISTMEMBERS.size()>0)
                {
                    reportInstance.logPass("LISTMEMBERS in the Response of Expansion is as expected where count is ",String.valueOf(LISTMEMBERS.size()));
                    ListMemberFlag=true;
                }else
                {
                    if(ListMemberFlag==false)
                    {
                        reportInstance.logFail("LISTMEMBERS in the Response of Expansion is not as expected", "");
                        throw new AssertionViolatedException("LIST MEMBERS is not as expected in the response");
                    }
                }
            }
        }else{
            reportInstance.logFail("array of value in the Response of Expansion is not as expected","");
            throw new AssertionViolatedException("JSON value is not as expected in the response");
        }
    }

    @Then("Verify the entities of LISTED members with nested Expansion")
    public void verify_the_entities_of_LISTED_members_with_nested_Expansion() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions

        Response=ResponseOutput(conn, HttpStatus.SC_OK,false,new HashMap());
        boolean ListMemberFlag=false;
        JSONArray array=JSONObjectToJsonArray(Response,"value");
        if(array.size()>0)
        {
            for (int i = 0; i < array.size(); i++)
            {
                JSONObject currentResponse= (JSONObject) array.get(i);
                JSONArray LISTMEMBERS=JSONObjectToJsonArray(currentResponse,"LIST_MEMBERS");
                if(LISTMEMBERS.size()>0)
                {
                    ListMemberFlag=true;
                    reportInstance.logPass("LISTMEMBERS in the Response of Expansion is as expected where count is ",String.valueOf(LISTMEMBERS.size()));
                    for (int iterator = 0; iterator < LISTMEMBERS.size(); iterator++)
                    {
                        JSONObject CResponse = (JSONObject) LISTMEMBERS.get(i);
                        String Member = GetattributefromResponse(CResponse, "MEMBER");
                        VerifyEntityData(StringToJSONObject(Member), "Active", "true");
                    }
                }else
                {
                    if(ListMemberFlag==false)
                    {
                        reportInstance.logFail("LISTMEMBERS in the Response of Expansion is not as expected", "");
                        throw new AssertionViolatedException("LIST MEMBERS is not as expected in the response");
                    }
                }
            }
        }else{
            reportInstance.logFail("array of value in the Response of Expansion is not as expected","");
            throw new AssertionViolatedException("JSON value is not as expected in the response");
        }
    }

    @When("Perform a GET Request in the LIST enities with nested filter in expansion {string} and {string}")
    public void perform_a_GET_Request_in_the_LIST_enities_with_nested_filter_in_expansion_and(String path,String param) throws Exception
    {
        String Route= ApiConstants.Route_master+path+URLEncoderForRequests(param);
        conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

    @When("Perform a GET Request in the REPORT_FORMAT entities under super type LIST with the value {string}")
    public void perform_a_GET_Request_in_the_REPORT_FORMAT_entities_under_super_type_LIST_with_the_value(String route) throws Exception
    {
        conn=SendRequest(ApiConstants.Route_master+route,"",DefaultRequestHeader(),"GET");
    }

    @Then("Verify the entities of LIST function response with {string}")
    public void verify_the_entities_of_LIST_function_response_with(String string) throws Exception
    {
        Response=ResponseOutput(conn, HttpStatus.SC_OK,false,new HashMap());
        JSONArray arr= JSONObjectToJsonArray(Response,"value");
        if(arr.size()>0)
        {
            for (int i = 0; i < arr.size(); i++)
            {
                JSONObject currentResponse= (JSONObject) arr.get(i);
                VerifyEntityData(currentResponse,"EntityTypeName",string);
            }
        }else{
            reportInstance.logFail("array of value in the Response of Expansion is not as expected","");
            throw new AssertionViolatedException("JSON array value is not as expected in the response");
        }
    }
    @When("Send a POST Request to create list with valid entity type value {string}")
    public void send_a_POST_Request_to_create_list_with_valid_entity_type_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"ListEntityType.json");
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @Then("Verify the response for list created for the {string}")
    public void verify_the_response_for_list_created_for_the_animal_subject(String string) throws Exception
    {
        Response=ResponseOutput(conn, HttpStatus.SC_CREATED,false,new HashMap());
        VerifyEntityData(Response,"EntityTypeName",string);
        id=GetattributefromResponse(Response,"Id");
    }

    @Then("Verify the DB for the valid entity type created {string}")
    public void verify_the_DB_for_the_valid_entity_type_created(String EntityType) throws Exception
    {
        String query= DbQueries.SelectListCreation.replace("BARCODE",id);
        query=query.replace("ENTITY TYPE",EntityType);
        reportInstance.logInfo("Query to validate the LIST",query);
        HashMap QueryResult=ExecuteQuery(query);

        if(QueryResult.size()==1)
        {
            reportInstance.logPass("DB holds the value as expected for ",id);
        }else {
            reportInstance.logFail("DB doesn't hold the value of ",id);
            throw new AssertionViolatedException("DB doesn't hold the value of "+id);
        }
    }

    @When("Send a POST Request to create list with non existing entity type as {string} with value {string}")
    public void send_a_POST_Request_to_create_list_with_non_existing_entity_type_as_with_value(String EntityNonExisitingParameter, String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"NonExisitingListEntityType.json");
        String RequestParameter=Request.toString();
        RequestParameter=RequestParameter.replace("NON_EXISTING",EntityNonExisitingParameter);
        conn=SendRequest(ApiConstants.Route_master+route,RequestParameter,DefaultRequestHeader(),"POST");
    }

    @Then("Verify the error message on LIST {string} and {string}")
    public void verify_the_error_message_on_LIST_and(String code, String message) throws Exception
    {
        Response=ResponseOutput(conn,HttpStatus.SC_BAD_REQUEST,false,new HashMap());
        VerifyErrorMessage(Response,code,message);
    }

    @When("Send a POST Request to create list with valid entity type for Employee with value {string}")
    public void send_a_POST_Request_to_create_list_with_valid_entity_type_for_Employee_with_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"EmployeeListEntityType.json");
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
    }
    @When("Send a POST Request to create list without surrogate entity type with the value {string}")
    public void send_a_POST_Request_to_create_list_without_surrogate_entity_type_with_the_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"NonExisitingListEntityType.json");
        Request.put("MEMBER_ENTITY_TYPE@odata.bind","ENTITY_TYPE('PEOPLE')");
        reportInstance.logInfo("Request ",Request.toString());
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @Then("Verify the error message {string} and {string} and details message on LIST {string} and {string}")
    public void verify_the_error_message_and_details_message_on_LIST_and(String code,String message, String detailcode, String detailmessage) throws Exception
    {
        Response=ValidateResponse(conn,true,HttpStatus.SC_BAD_REQUEST,false,new HashMap());
        VerifyErrorMessageWithinDetails(Response, code, message,detailcode,detailmessage);
    }

    @When("Send a POST Request to create private list with the value {string}")
    public void send_a_POST_Request_to_create_private_list_with_the_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"PrivateList.json");
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @When("Send a POST Request to create list with missing member entity type with the value {string}")
    public void send_a_POST_Request_to_create_list_with_missing_member_entity_type_with_the_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"Memberentity.json");
        reportInstance.logInfo("Request ",Request.toString());
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
    }
    @When("Send a PUT Request to update list with private false with the value {string}")
    public void send_a_PUT_Request_to_update_list_with_private_false(String route) throws Exception
    {

        JSONObject Request=ReadJsonInput(ResourcePath+"PrivateList.json");
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
        Response=ResponseOutput(conn, HttpStatus.SC_CREATED,false,new HashMap());
        Barcode=GetattributefromResponse(Response,"Barcode");

        String Route= ApiConstants.Route_master+route+"('"+Barcode+"')";
        reportInstance.logInfo("Route ",Route);
        conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
        Response=ValidateResponse(conn,true,HttpStatus.SC_OK,false,new HashMap());
        Response.put("Private",false);
        conn=SendRequest(Route,Response.toString(),DefaultRequestHeader(),"PUT");
    }

    @Then("Verify the response for list updated for the {string} as {string}")
    public void verify_the_response_for_list_updated_for_the(String entityType,String ExpectedValue) throws Exception
    {
        Response=ResponseOutput(conn, HttpStatus.SC_OK,false,new HashMap());
        VerifyEntityData(Response,entityType,ExpectedValue);
        id=GetattributefromResponse(Response,"Id");
    }

    @When("Send a PUT Request to update list for member entity type with the value {string}")
    public void send_a_PUT_Request_to_update_list_for_member_entity_type_with_the_value(String route) throws Exception
    {
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+route,"",DefaultRequestHeader()));
        JSONArray json=JSONObjectToJsonArray(Response,"value");
        JSONObject currentResponse=(JSONObject)json.get(0);
        String Barcode= currentResponse.get("Barcode").toString();
        currentResponse.put("MEMBER_ENTITY_TYPE@odata.bind","/ENTITY_TYPE('WORKER')");
        String Route= ApiConstants.Route_LIST_General+"('"+Barcode+"')";
        conn=SendRequest(Route,currentResponse.toString(),DefaultRequestHeader(),"PUT");
    }

    @Then("Verify the error code is {string} and message {string} and details message on update LIST {string} and {string}")
    public void verify_the_error_code_is_and_message_and_details_message_on_update_LIST_and(String code,String message,String detailcode, String detailmessage) throws Exception
    {

        ValidateExceptedResponseCode(conn.getResponseCode(),HttpStatus.SC_BAD_REQUEST);
        String StrResponse=GetResponseBody(conn);
        VerifyErrorMessageWithinDetails(StringToJSONObject(StrResponse), code, message,detailcode,detailmessage);
    }

    @When("Send a POST Request to add member to non-existing list with the value {string}")
    public void send_a_POST_Request_to_add_member_to_non_existing_list_with_the_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"TenantEntityList.json");
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @Then("Verify the error message on invalid LIST {string} and {string}")
    public void verify_the_error_message_on_invalid_LIST_and(String code, String message) throws Exception
    {
        Response=ValidateResponse(conn,true,HttpStatus.SC_NOT_FOUND,false,new HashMap());
        VerifyErrorMessage(Response,code,message);
    }

    @When("Send a Get request as prerequsite to get the {string} with the value {string}")
    public void send_a_get_request_as_prerequsite_to_get_the_with_the_value(String barcode, String route) throws Exception {

        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+route,"",DefaultRequestHeader()));
        JSONArray json=JSONObjectToJsonArray(Response,"value");
        JSONObject currentResponse=(JSONObject)json.get(0);
        Barcode= currentResponse.get(barcode).toString();
    }

    @Then("Send a POST Request to add member to non-existing entity with the value {string}")
    public void send_a_POST_Request_to_add_member_to_non_existing_entity_with_the_value(String path) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"TenantNonExistingList.json");
        String Route= path.replace("GENLST45",Barcode);
        String url=ApiConstants.Route_master+Route;
        conn=SendRequest(url,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @When("Send a Get request to get barcode with value {string} then send a POST Request to add member no entity to list with the value {string}")
    public void send_a_Get_request_to_get_barcode_with_value_then_send_a_POST_Request_to_add_member_no_entity_to_list(String path1,String path2) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"NoEntityToList.json");
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+path1,"",DefaultRequestHeader()));
        JSONArray json=JSONObjectToJsonArray(Response,"value");
        int jsonsize=json.size();
        JSONObject currentResponse=(JSONObject)json.get(jsonsize-1);
        Barcode= currentResponse.get("Barcode").toString();
        String RouteList= path2.replace("GENLST45",Barcode);
        String url=ApiConstants.Route_master+RouteList;
        conn=SendRequest(url,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @Then("Verify the response for zero list response")
    public void verify_the_response_for_list_response() throws Exception
    {
        Response=ValidateResponse(conn,true, HttpStatus.SC_OK,false,new HashMap());
        JSONArray json= JSONObjectToJsonArray(Response,"value");
        if(json.size()==0)
        {
            reportInstance.logPass("Should be zero ",String.valueOf(json.size()));
        }else {
            reportInstance.logFail("is not zero as expected ",String.valueOf(json.size()));
            throw new AssertionViolatedException("Value array is not zero as expected instead "+String.valueOf(json.size()));
        }

    }


    @Then("Send a Get Request with the value {string} and Verify the zero list members")
    public void send_a_Get_Request_with_the_value_and_Verify_the_zero_list_members(String route) throws Exception
    {
        String Route= route.replace("GENLST5",Barcode);
        String url=ApiConstants.Route_master+Route;
        conn=SendRequest(url,"",DefaultRequestHeader(),"GET");
        Response=ValidateResponse(conn,true, HttpStatus.SC_OK,false,new HashMap());
        VerifyEntityData(Response,"EntityTypeName","GENERAL_LIST");
        JSONArray json=JSONObjectToJsonArray(Response,"LIST_MEMBERS");
        if(json.size()==0)
        {
            reportInstance.logPass("Should be zero ",String.valueOf(json.size()));
        }else {
            reportInstance.logFail("is not zero as expected ",String.valueOf(json.size()));
            throw new AssertionViolatedException("Value array is not zero as expected instead "+String.valueOf(json.size()));
        }

    }

    @When("Send a Get request to get barcode with value {string} then send a POST Request to add member existing ones to list with the value {string}")
    public void send_a_Get_request_to_get_barcode_with_value_then_send_a_POST_Request_to_add_member_existing_ones_to_list(String path1,String path2) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"ExistingTenantEntityList.json");
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+path1,"",DefaultRequestHeader()));
        JSONArray json=JSONObjectToJsonArray(Response,"value");
        int jsonsize=json.size();
        JSONObject currentResponse=(JSONObject)json.get(0);
        Barcode= currentResponse.get("Barcode").toString();
        String AddpfsMemberRoute= path2.replace("GENLST45",Barcode);
        String url=ApiConstants.Route_master+AddpfsMemberRoute;
        conn=SendRequest(url,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @Then("Verify the response for list response of existing ones")
    public void verify_the_response_for_list_response_of_existing_ones() throws Exception
    {
        Response=ValidateResponse(conn,true, HttpStatus.SC_OK,false,new HashMap());
        JSONArray jsonArray=JSONObjectToJsonArray(Response,"value");
        for(int iterator=0;iterator<jsonArray.size();iterator++)
        {
            JSONObject CurrentResponse= (JSONObject) jsonArray.get(iterator);
            NewIdsCreated.add(CurrentResponse.get("Id").toString());
        }
    }

    @Then("Send a Get Request and Verify the existing and new list members with the value {string}")
    public void send_a_Get_Request_and_Verify_the_existing_and_new_list_members_with_the_value(String path) throws Exception
    {
        String GetpfsExpandRoute= path.replace("GENLST5",Barcode);
        String url=ApiConstants.Route_master+GetpfsExpandRoute;
        conn=SendRequest(url,"",DefaultRequestHeader(),"GET");
        Response=ValidateResponse(conn,true, HttpStatus.SC_OK,false,new HashMap());
        GetListMemberExpand(url);
    }

    public void GetListMemberExpand(String Route) throws Exception
    {

        Response=StringToJSONObject(GetRequest(Route,"",DefaultRequestHeader()));
        JSONArray jsonarray=JSONObjectToJsonArray(Response,"LIST_MEMBERS");
        ArrayList<String> ActualIds=new ArrayList<>();
        for(int iterator=0;iterator<jsonarray.size();iterator++)
        {
            boolean ExpectedActualId=false;
            JSONObject CurrentResponse= (JSONObject) jsonarray.get(iterator);
            ActualIds.add(CurrentResponse.get("Id").toString());
            String MemberInformation=GetattributefromResponse(CurrentResponse,"MEMBER");
            JSONObject MemberObject=StringToJSONObject(MemberInformation);
            String StrBarcode=MemberObject.get("Barcode").toString();
            switch (StrBarcode)
            {
                case "CRT12":
                {
                    reportInstance.logInfo("Should be CR12 "," as expected");
                    break;
                }
                case "CRT16":
                {
                    reportInstance.logInfo("Should be CR16 "," as expected");
                    break;
                }
                case "CRT15":
                {
                    reportInstance.logInfo("Should be CR15 "," as expected");
                    break;
                }
            }

        }
        for(int CurrentIteration=0;CurrentIteration<NewIdsCreated.size();CurrentIteration++)
        {
            boolean ExpectedValueFlag=false;
            String ExpectedCurrentId=NewIdsCreated.get(CurrentIteration);
            for(int j=0;j<ActualIds.size();j++)
            {
                String ActualIdCurrent=ActualIds.get(j);
                if(ActualIdCurrent.equalsIgnoreCase(ExpectedCurrentId))
                {
                    ExpectedValueFlag=true;
                    break;
                }
            }
            if(ExpectedValueFlag)
            {
                reportInstance.logPass(ExpectedCurrentId," is present in the LIST member as expected");
            }else
            {
                reportInstance.logPass(ExpectedCurrentId," is not present in the LIST member as expected");
            }
        }
    }

    @Given("Prepare the Auth for the LIST Entities with autoadmin23 user as {string} and perform post request to get {string} and {string} with the value {string}")
    public void prepare_the_Auth_for_the_LIST_Entities_with_autoadmin23_user(String BasicAuth,String barcode,String Id,String route) throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        Scheme= Utils.getInstance().getGlobalTestData("Scheme");
        Host= Utils.getInstance().getGlobalTestData("Host");
        //Explicit for autoadmin23 user
        Authorization=BasicAuth;
        TenantFlag=true;
        JSONObject Request=ReadJsonInput("YETI"+ResourcePath+"PrivateList.json");
        reportInstance.logInfo("Request ",Request.toString());
        // Pre-request of Entity
        conn=SendRequest(ApiConstants.Route_master+route,Request.toString(),UpdateRequestHeader("tfs-platform-tenantalias","tenant_001"),"POST");
        Response=ValidateResponse(conn,true,HttpStatus.SC_CREATED,false,new HashMap());
        Barcode=GetattributefromResponse(Response,barcode);
        id=GetattributefromResponse(Response,Id);
        // Adding back to actual auth - LIMS USER
        Readprerequest();
    }

    @When("Add Members to POST request without permission with the value {string}")
    public void add_Members_to_POST_request_without_permission_with_the_value(String route) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"TenantEntityList.json");
        String AddpfsMemberRoute= route.replace("GENLST45",Barcode);
        String url=ApiConstants.Route_master+AddpfsMemberRoute;
        conn=SendRequest(url,Request.toString(),DefaultRequestHeader(),"POST");
    }

    @When("Remove Members on LIST without permission by send POST request with the value {string}")
    public void remove_Members_on_LIST_without_permission_by_send_POST_request_with_the_value(String path) throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"ListMemberId.json");
        String RemoveRequest=Request.toString().replace("18178447",id);
        String RemovepfsMemberRoute= path.replace("GENLST5",Barcode);
        String url=ApiConstants.Route_master+RemovepfsMemberRoute;
        conn=SendRequest(url,RemoveRequest,DefaultRequestHeader(),"POST");
    }

    @When("Remove a non existing Member on LIST by generating GET request with values {string} and {string} to fetch {string} and then remove it")
    public void remove_a_Member_on_LIST_by_generating_GET_request_with_values_and_to_fetch_and_then_remove_it(String path1,String path2,String barcode) throws Exception
    {
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+path1,"",DefaultRequestHeader()));
        JSONArray json=JSONObjectToJsonArray(Response,"value");
        int jsonsize=json.size();
        JSONObject currentResponse=(JSONObject)json.get(0);
        Barcode = currentResponse.get(barcode).toString();
        String GetMemberRoute= path2.replace("GENLST5",Barcode);
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+GetMemberRoute,"",DefaultRequestHeader()));
        ArrayList<String> TotalListMembers=fnGetAllLISTMembers(Response);
        reportInstance.logInfo("Total Number of list member present is ",String.valueOf(TotalListMembers.size()));
        totalmembersize=TotalListMembers.size();
        GetFirstBarcodeAndRemovetheValuesOfid(Barcode,"99999999");

    }
    @Then("Verify the count of member on the LIST remains the same by generating GET request with the value {string}")
    public void verify_the_removal_of_member_on_the_LIST_the_same_by_generating_GET_request_with_the_value(String route) throws Exception
    {
        String GetMemberRoute= route.replace("GENLST5",Barcode);
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+GetMemberRoute,"",DefaultRequestHeader()));
        ArrayList<String> TotalListMembers=fnGetAllLISTMembers(Response);
        if(totalmembersize==TotalListMembers.size())
        {
            reportInstance.logPass("Total Number of list member present is as expected",String.valueOf(TotalListMembers.size()));
        }else
        {
            reportInstance.logFail("Total Number of list member present is not as expected ",String.valueOf(totalmembersize)+" where actual is "+String.valueOf(TotalListMembers.size()));
            throw new AssertionViolatedException(String.valueOf(totalmembersize)+" where actual is "+String.valueOf(TotalListMembers.size()));
        }
    }

    public synchronized void GetFirstBarcodeAndRemovetheValuesOfid(String BarcodeValue,String IdValue) throws Exception
    {
        String RemovepfsMemberRoute= ApiConstants.Route_LIST_General_RemoveMembers.replace("GENLST5",BarcodeValue);
        JSONObject Request=ReadJsonInput(ResourcePath+"ListMemberId.json");
        String RemoveRequest=Request.toString().replace("18178447",IdValue);
        conn=SendRequest(RemovepfsMemberRoute,RemoveRequest,DefaultRequestHeader(),"POST");
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpStatus.SC_NO_CONTENT);
    }

    public synchronized ArrayList<String> fnGetAllLISTMembers(JSONObject Response) throws Exception
    {
        ArrayList<String> ListMembersIDs=new ArrayList<>();
        JSONArray array=JSONObjectToJsonArray(Response,"LIST_MEMBERS");
        boolean ListMemberFlag=false;
        if(array.size()>0)
        {
            reportInstance.logPass("LISTMEMBERS in the Response of Expansion is as expected where count is ",String.valueOf(array.size()));
            for(int iterator=0;array.size()>iterator;iterator++)
            {
                JSONObject getCurrentListMember= (JSONObject) array.get(iterator);
                String CurrentId=GetattributefromResponse(getCurrentListMember,"Id");
                ListMembersIDs.add(CurrentId);
            }
        }else{
            reportInstance.logFail("array of value in the Response of Expansion is not as expected","");
            throw new AssertionViolatedException("JSON value is not as expected in the response");
        }
        return ListMembersIDs;
    }

    @When("Remove all Member on LIST by generating GET request with values {string} and {string} to fetch {string} and then remove it")
    public void remove_all_Member_on_LIST_by_generating_GET_request_with_values_and_to_fetch_and_then_remove_it(String path1,String path2,String barcode) throws Exception
    {
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+path1,"",DefaultRequestHeader()));
        JSONArray json=JSONObjectToJsonArray(Response,"value");
        int jsonsize=json.size();
        JSONObject currentResponse=(JSONObject)json.get(0);
        Barcode = currentResponse.get(barcode).toString();
        String GetMemberRoute= path2.replace("GENLST5",Barcode);
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+GetMemberRoute,"",DefaultRequestHeader()));
        ArrayList<String> TotalListMembers=fnGetAllLISTMembers(Response);
        reportInstance.logInfo("Total Number of list member present is ",String.valueOf(TotalListMembers.size()));
        totalmembersize=TotalListMembers.size();
        for(int iterator=0;3>iterator;iterator++)
        {
            GetFirstBarcodeAndRemovetheValuesOfid(Barcode,TotalListMembers.get(iterator));
        }
    }
    @Then("Verify the removal of member on the LIST by generating GET request with value {string}")
    public void verify_the_removal_of_member_on_the_LIST_by_generating_GET_request_with_value(String route) throws Exception
    {
        String GetMemberRoute= route.replace("GENLST5",Barcode);
        Response=StringToJSONObject(GetRequest(ApiConstants.Route_master+GetMemberRoute,"",DefaultRequestHeader()));
        ArrayList<String> TotalListMembers=fnGetAllLISTMembers(Response);
        int Actualsizeoflistmember=TotalListMembers.size();
        int expectedsizeoflistmembers=totalmembersize-3;
        if(Actualsizeoflistmember==expectedsizeoflistmembers)
        {
            reportInstance.logPass("Total Number of list member present is as expected",String.valueOf(Actualsizeoflistmember));
        }else
        {
            reportInstance.logFail("Total Number of list member present is not as expected ",String.valueOf(expectedsizeoflistmembers)+" where actual is "+String.valueOf(Actualsizeoflistmember));
            throw new AssertionViolatedException(String.valueOf(expectedsizeoflistmembers)+" where actual is "+String.valueOf(Actualsizeoflistmember));
        }
    }

}
