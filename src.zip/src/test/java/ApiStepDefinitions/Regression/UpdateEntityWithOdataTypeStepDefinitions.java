package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;

public class UpdateEntityWithOdataTypeStepDefinitions extends DBHelper {


    JSONObject Response;
    String stringResponse;
    String ResourcePath="/RegressionTests/QueueAction/UpdateEntityWithOdataType";



    @Given("Login into Odata for update Entity With OData Type")

    public void login_into_odata_for_update_entity_with_odata_type() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "Login into Odata for update Entity With OData Type");
        Readprerequest();
    }

    @When("Send a PUT request to update sample with wrong odata.type by put request")
    public void send_a_PUT_request_to_update_sample_with_wrong_odata_type_by_put_request() throws Exception {

        reportInstance.logInfo("STEPS : ", "Send a PUT request to update sample with wrong odata.type by put request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateSampleEntityWithWrongOdataTypeByPUTRequest.json");
        Response= putRequest(Request.toString(),ApiConstants.sample,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for update sample with wrong odata.type by put request")

    public void verify_the_error_message_for_update_sample_with_wrong_odata_type_by_put_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for update sample with wrong odata.type by put request");
        VerifyErrorMessage(Response,"2002","Missing replacement for place holder in message ''%1$s' can not be mapped as a property or an annotation.' for following arguments '[]'!");
    }

    @When("Send a PATCH request to update sample entity with wrong odata.type by PATCH request")
    public void send_a_patch_request_to_update_sample_entity_with_wrong_odata_type_by_patch_request() throws Exception {

        reportInstance.logInfo("STEPS : ", "Send a PUT request to update sample with wrong odata.type by put request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateSampleEntityWithWrongOdataTypeByPATCHRequest.json");
        Response= patchRequest(Request.toString(),ApiConstants.sample,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for update sample entity with wrong odata.type by PATCH request")

    public void verify_the_error_message_for_update_sample_entity_with_wrong_odata_type_by_patch_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for update sample entity with wrong odata.type by PATCH request");
        VerifyErrorMessage(Response,"2002","Missing replacement for place holder in message ''%1$s' can not be mapped as a property or an annotation.' for following arguments '[]'!");
    }


    @When("Send a PUT request to update intermediate assay data entity with wrong odata.type by PUT request")

    public void send_a_PUT_request_to_update_intermediate_assay_data_entity_with_wrong_odata_type_by_PUT_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a PUT request to update intermediate assay data entity with wrong odata.type by PUT request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateIntermediateAssayDataEntityWithWrongOdatatypeByPutRequest.json");
        Response= putRequest(Request.toString(),ApiConstants.intermediate_assay,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for updated intermediate assay data entity with wrong odata.type by PUT request")

    public void verify_the_error_message_for_updated_intermediate_assay_data_entity_with_wrong_odata_type_by_PUT_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for updated intermediate assay data entity with wrong odata.type by PUT request");
        VerifyErrorMessage(Response,"2002","Missing replacement for place holder in message ''%1$s' can not be mapped as a property or an annotation.' for following arguments '[]'!");

    }

    @When("Send a PATCH request to update intermediate assay data entity with wrong odata.type by PATCH request")

    public void send_a_PATCH_request_to_update_intermediate_assay_data_entity_with_wrong_odata_type_by_PATCH_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a PATCH request to update intermediate assay data entity with wrong odata.type by PATCH request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateIntermediateAssayDataEntityWithWrongOdatatypeByPatchRequest.json");
        Response= patchRequest(Request.toString(),ApiConstants.intermediate_assay,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for updated intermediate assay data entity with wrong odata.type by PATCH request")

    public void verify_the_error_message_for_updated_intermediate_assay_data_entity_with_wrong_odata_type_by_PATCH_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for updated intermediate assay data entity with wrong odata.type by PATCH request");
        VerifyErrorMessage(Response,"2002","Missing replacement for place holder in message ''%1$s' can not be mapped as a property or an annotation.' for following arguments '[]'!");

    }

    @When("Send a PUT request to update sample entity with correct odata.type by PUT request")

    public void send_a_PUT_request_to_update_sample_entity_with_correct_odata_type_by_PUT_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a PUT request to update sample entity with correct odata.type by PUT request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateSAMPLEEntityWithCorrectOdataTypeByPutRequest.json");
        Response= putRequest(Request.toString(),ApiConstants.sample,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_OK);


    }

    @Then("Verify the response for updated sample entity with correct odata.type by PUT request")

    public void verify_the_response_for_updated_sample_entity_with_correct_odata_type_by_PUT_request() throws IOException {
        reportInstance.logInfo("STEPS : ", "Verify the response for updated sample entity with correct odata.type by PUT request");
        VerifyEntityData(Response,"EntityTypeName","URI_SAMPLE");

    }

    @When("Send a PATCH request to update sample entity with correct odata.type by PATCH request")

    public void send_a_PATCH_request_to_update_sample_entity_with_correct_odata_type_by_PATCH_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a PATCH request to update sample entity with correct odata.type by PATCH request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateSampleEntityWithCorrectOdataTypeByPatchRequest.json");
        Response= patchRequest(Request.toString(),ApiConstants.sample,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_OK);

    }

    @Then("Verify the response for updated sample entity with correct odata.type by PATCH request")

    public void verify_the_response_for_updated_sample_entity_with_correct_odata_type_by_Patch_request() throws IOException {
        reportInstance.logInfo("STEPS : ", "Verify the response for updated sample entity with correct odata.type by PATCH request");
        VerifyEntityData(Response,"EntityTypeName","URI_SAMPLE");

    }

    @When("Send a PUT request to update intermediate assay data entity with correct odata.type by PUT request")

    public void send_a_PUT_request_to_update_intermediate_assay_data_entity_with_correct_odata_type_by_PUT_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a PUT request to update intermediate assay data entity with correct odata.type by PUT request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateINTERMEDIATEASSAYDATAEntityWithCorrectOdata.typeByPUTRequest.json");
        Response= putRequest(Request.toString(),ApiConstants.intermediate_assay,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_OK);

    }

    @Then("Verify the response for updated intermediate assay data entity with correct odata.type by PUT request")

    public void verify_the_response_for_updated_intermediate_assay_data_entity_with_correct_odata_type_by_PUT_request() throws IOException {
        reportInstance.logInfo("STEPS : ", "Verify the response for updated intermediate assay data entity with correct odata.type by PUT request");
        VerifyEntityData(Response,"Barcode","BTES1105");

    }

    @When("Send a PATCH request to update intermediate assay data entity with correct odata.type by PATCH request")

    public void send_a_PATCH_request_to_update_intermediate_assay_data_entity_with_correct_odata_type_by_patch_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a PATCH request to update intermediate assay data entity with correct odata.type by PATCH request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateIntermediateAssayDataEntityWithCorrectOdataTypeByPatchRequest.json");
        Response= putRequest(Request.toString(),ApiConstants.bitterness_intermediate_assay,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_OK);

    }

    @Then("Verify the response for updated intermediate assay data entity with correct odata.type by patch request")

    public void verify_the_response_for_updated_intermediate_assay_data_entity_with_correct_odata_type_by_patch_request() throws IOException {
        reportInstance.logInfo("STEPS : ", "Verify the response for updated intermediate assay data entity with correct odata.type by patch request");
        VerifyEntityData(Response,"Barcode","BTES1105");
    }






}