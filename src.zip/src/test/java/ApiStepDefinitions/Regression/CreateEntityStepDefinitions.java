package ApiStepDefinitions.Regression;


import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;


public class CreateEntityStepDefinitions extends DBHelper{

    JSONObject Response;
    String ResourcePath = "/RegressionTests/QueueAction/OData4.0Conformance/Item10/CreateEntity";

    @Given("Login into ODATA for CreateEntity")
    public void login_into_ODATA_for_CreateEntity() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a POST request with non existing property {string}")
    public void create_a_POST_request_with_non_existing_property(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateEntityWithNonExistingProperty.json");
        Response=postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify error message {string}")
    public void Verify_error_message(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, errorMessage);
    }

    @When("Create a POST request for Location exists in response header {string}")
    public void create_a_POST_request_for_Location_exists_in_response_header(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/LocationExistsInResponseHeaderWhenCreatingEntity.json");
        Response=postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_CREATED);
    }

    @Then("Create GET request with url as Location in previous POST response {string}")
    public void Create_GET_request_with_url_as_Location_in_previous_POST_response(String route) throws Exception {
        String entity =GetattributefromResponse(Response, "Barcode");
        GetRequest(ApiConstants.Route_master+route.concat("('"+entity+"')"));
    }

    @When("Create a POST request with prefer header explicitly set to representation return {string} and {string} and {string}")
    public void Create_a_POST_request_with_prefer_header_explicitly_set_to_representation_return(String route, String header_key, String header_value) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/LocationExistsInResponseHeaderWhenCreatingEntity.json");
        Response=postRequest(Request.toString(), ApiConstants.Route_master+route, UpdateRequestHeader(header_key, header_value), HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify entity created with prefer header explicitly set to representation return")
    public void verify_entity_created_with_prefer_header_explicitly_set_to_representation_return() throws Exception {
        String entity =GetattributefromResponse(Response, "Barcode");
        VerifyEntityData(Response,"Name", entity);
    }

}
