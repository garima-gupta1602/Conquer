package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;


public class BatchRequest_StepDefinitions extends DBHelper {
    HttpURLConnection Conn, Conn1;
    Boolean prerequisite;
    String strResponse;
    String entity;

    @Given("Login into ODATA for Batch Request")
    public void Login_into_ODATA_for_Navigation() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("Given: ", "Login into ODATA for Batch Request");
        Readprerequest();
    }

    @When("Create a POST request for Update Sample")
    public void Create_a_POST_request_for_Update_Sample() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request for Update Sample");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/UpdateSample.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_77fddf03-a091-49ab-ac79-2af47af559ea"), "POST");
    }

    @Then("verify success response for Update Sample")
    public void verify_success_response_for_Update_Sample() throws Exception {
        reportInstance.logInfo("When: ", "verify success response for Update Sample");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Update Container")
    public void Create_a_POST_request_for_Update_Container() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request for Update Container");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/UpdateContainer.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_d7ece2d8-83ff-41bc-b47f-af335cfc0061"), "POST");
    }

    @Then("verify success response for Update Container")
    public void verify_success_response_for_Update_Container() throws Exception {
        reportInstance.logInfo("When: ", "verify success response for Update Container");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
    }
    
    @When("Create a POST request for Create and lock Experiment")
    public void Create_a_POST_request_for_Create_and_lock_Experiment() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request for Create and lock Experiment");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/CreateAndLockExperiment.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_4c361a96-77c2-4376-8d7f-8e2067ec8ca0"), "POST");
    }

    @Then("verify success response for Create and lock Experiment")
    public void verify_success_response_for_Create_and_lock_Experiment() throws Exception {
        reportInstance.logInfo("When: ", "verify success response for Create and lock Experiment");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
    }
   
    @When("Create a POST request for Bad request in query set")
    public void Create_a_POST_request_for_Bad_request_in_query_set() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request for Bad request in query set");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/BadRequestInQuerySet.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_e73b1e18-71fb-4945-801c-ec44b1c56216"), "POST");
    }

    @Then("verify success response for Bad request in query set")
    public void verify_success_response_for_Bad_request_in_query_set() throws Exception {
        reportInstance.logInfo("When: ", "verify success response for Bad request in query set");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
    }
    
    @When("Create a POST request for Bad request in change set")
    public void Create_a_POST_request_for_Bad_request_in_change_set() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request for Bad request in change set");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/BadRequestInChangeSet.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_c56ecf93-a68c-4869-9392-fab5f0ed9733"), "POST");
    }

    @Then("verify success response for Bad request in change set")
    public void verify_success_response_for_Bad_request_in_change_set() throws Exception {
        reportInstance.logInfo("When: ", "verify success response for Bad request in change set");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Bad request in invalid header")
    public void Create_a_POST_request_for_Bad_request_in_invalid_header() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request for Bad request in invalid header");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/BadRequestInInvalidHeader.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "application/json; boundary=batch_71dd1037-1714-40c5-875e-9372ecf2b992"), "POST");
    }

    @Then("verify success response for Bad request in invalid header")
    public void verify_success_response_for_Bad_request_in_invalid_header() throws Exception {
        reportInstance.logInfo("When: ", "verify success response for Bad request in invalid header");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_BAD_REQUEST);
    }
   
    @When("Create a POST request1 with Continue on error on header")
    public void Create_a_POST_request1_with_Continue_on_error_on_header() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request1 with Continue_on_error on header");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/BatchRequest1WithContinue_on_errorOnHeader.txt";
        String body = readEntireText(txtpath);
        HashMap<String, String> newheader=UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_4811a267-b400-4661-9356-726df357317d");
        newheader.put("prefer", "odata.continue-on-error");
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, newheader, "POST");
    }

   @And("Create a POST request2 with Continue on error on header")
    public void Create_a_POST_request2_with_Continue_on_error_on_header() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request2 with Continue_on_error on header");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/BatchRequest2WithContinue_on_errorOnHeader.txt";
        String body = readEntireText(txtpath);
        HashMap<String, String> newheader = UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_d2567dd3-214c-435c-b242-ca8f975bd65d");
        newheader.put("Prefer", "odata.continue-on-error");
        Conn1 = SendRequest(ApiConstants.Route_BatchRequest, body, newheader, "POST");
    }

    @Then("verify success response with Continue on error on header")
    public void verify_success_response_with_Continue_on_error_on_header() throws Exception {
        reportInstance.logInfo("When: ", "verify success response with Continue_on_error on header");
        int responsecode = Conn.getResponseCode();
        int responsecode1 = Conn1.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
        ValidateExceptedResponseCode(responsecode1, HttpURLConnection.HTTP_OK);
    }

    
    @When("Create a POST request1 with Limitations of query set")
    public void Create_a_POST_request1_with_Limitations_of_query_set() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request1 with Limitations of query set");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/LimitationsOfQuerySet_Request1.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_845e49f3-4464-49c2-8c74-234aabdb3158"), "POST");
    }

    @And("Create a POST request2 with Limitations of query set")
    public void Create_a_POST_request2_with_Limitations_of_query_set() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request2 with Limitations of query set");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/LimitationsOfQuerySet_Request2.txt";
        String body = readEntireText(txtpath);
        Conn1 = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_c5539469-d1e8-4e14-8963-b60458e8f15f"), "POST");
    }

    @Then("verify success response with Limitations of query set")
    public void verify_success_response_with_Limitations_of_query_set() throws Exception {
        reportInstance.logInfo("When: ", "verify success response with Limitations of query set");
        int responsecode = Conn.getResponseCode();
        int responsecode1 = Conn1.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
        ValidateExceptedResponseCode(responsecode1, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    
    @When("Create a POST request1 with Limitations of change set")
    public void Create_a_POST_request1_with_Limitations_of_change_set() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request1 with Limitations of change set");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/LimitationsOfChangeSet_Request1.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_43be9f41-ef52-44f6-8a3a-779859f2daf7"), "POST");
    }

    @And("Create a POST request2 with Limitations of change set")
    public void Create_a_POST_request2_with_Limitations_of_change_set() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request2 with Limitations of change set");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/LimitationsOfChangeSet_Request2.txt";
        String body = readEntireText(txtpath);
        Conn1 = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_43be9f41-ef52-44f6-8a3a-779859f2daf7"), "POST");
    }

    @Then("verify success response with Limitations of change set")
    public void verify_success_response_with_Limitations_of_change_set() throws Exception {
        reportInstance.logInfo("When: ", "verify success response with Limitations of change set");
        int responsecode = Conn.getResponseCode();
        int responsecode1 = Conn1.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
        ValidateExceptedResponseCode(responsecode1, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    
    @When("Create a POST request Change set with multiple Domain")
    public void Create_a_POST_request_Change_set_with_multiple_Domain() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request Change set with multiple Domain");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/ChangeSetWithMultipleDomain.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_4fb7044f-a0b2-4b8d-bb22-dfa0f1160505"), "POST");
    }

    @Then("verify response Change set with multiple Domain")
    public void verify_response_Change_set_with_multiple_Domain() throws Exception {
        reportInstance.logInfo("When: ", "verify response Change set with multiple Domain");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_BAD_REQUEST);
    }
   
    @When("Create a POST request Change set with more than one action")
    public void Create_a_POST_request_Change_set_with_more_than_one_action() throws Exception {
        reportInstance.logInfo("When: ", "Create a POST request Change set with more than one action");
        String txtpath = "src/test/resources/YETI/RegressionTests/QueueAction/BatchRequest/ChangeSetWithMoreThanOneAction.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed; boundary=batch_36b81318-9e7a-42d9-95c4-37e70dc82732"), "POST");
    }

    @Then("verify response Change set with more than one action")
    public void verify_response_Change_set_with_more_than_one_action() throws Exception {
        reportInstance.logInfo("When: ", "verify response Change set with more than one action");
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    public static String readEntireText(String path) {
        File content = new File(path);
        String fileContent="";
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(content);
            byte[] Value = new byte[(int) content.length()];
            fileInputStream.read(Value);
            fileInputStream.close();
            fileContent = new String(Value, "UTF-8");

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return fileContent;
    }


}
