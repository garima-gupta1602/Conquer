package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.tr.Ve;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;

public class ExpansionQueryOptionStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    Boolean prerequisite;
    String strResponse;
    String entity;



    @Given("Login into OData for Expansion Query Option")

    public void login_into_OData_for_expansion_query_option() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into OData for Expansion Query Option");
        Readprerequest();
    }

    @When("Perform a Get request to expand Animal nurses with filter=Barcode eq 'NUR_ONAV-013")

    public void perform_a_get_request_to_expand_animal_nurses_with_filter_Barcode_eq_NUR_ONAV_013() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand Animal nurses with filter=Barcode eq 'NUR_ONAV-013");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($filter="
                + URLEncoderForRequests("Barcode eq 'NUR_ONAV-013'")+")";
        //stringResponse = GetRequest(stringResponse, "",UpdateRequestHeader1("Tenant","tenant_001"));
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for expand collection with filter entity")

    public void verify_the_response_for_expand_collection_with_filter_entity() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            if(i!=2) {
                VerifyEntityData(Response, "ANIMAL_NURSES", "[]");
                continue;
            }

              else {


                  JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

            String firstresp1 = resp1.get(0).toString();
           Response = StringToJSONObject(firstresp1);

                  VerifyEntityData(Response, "Barcode", "NUR_ONAV-013");
              }

        }
    }

    @When("Perform a Get request to expand ANIMAL_ANIMALSUPPLIER with filter=Barcode eq 'SUP2'")

    public void perform_a_Get_request_to_expand_ANIMAL_ANIMALSUPPLIER_with_filter_Barcode_eq_SUP2() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ANIMAL_ANIMALSUPPLIER with filter=Barcode eq 'SUP2'");

        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($filter="
                + URLEncoderForRequests("Barcode eq 'SUP2'")+")" ;

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for expand single with filter entity")

    public void verify_the_response_for_expand_single_with_filter_entity() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(1).toString();
            Response = StringToJSONObject(firstresp);
           String animal_animalsupplier= GetattributefromResponse(Response,"ANIMAL_ANIMALSUPPLIER");
           Response=StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "Barcode", "SUP2");

        }
    }

  @When("Perform a Get request to expand EC with filter and ES navigation property")

    public void perform_a_get_request_to_expand_EC_with_filter_and_es_navigation_property() throws Exception {
      reportInstance.logInfo("When : ", "Perform a Get request to expand EC with filter and ES navigation property");

      String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($expand=CREATED_BY;$filter="
              + URLEncoderForRequests("Barcode eq 'NUR_ONAV-013'")+")" ;

      stringResponse = GetRequest(stringResponse,"");
      Response = StringToJSONObject(stringResponse);
  }

  @Then("Verify the response for EC with filter and ES navigation property")

    public void verify_the_response_for_EC_with_filter_and_ES_navigation_property() throws Exception {
      JSONArray resp=JSONObjectToJsonArray(Response,"value");
      for(int i=0; i< 1; i++) {
          String firstresp = resp.get(2).toString();
          Response = StringToJSONObject(firstresp);

          JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

                String firstresp1 = resp1.get(0).toString();
                Response = StringToJSONObject(firstresp1);

                VerifyEntityData(Response, "Barcode", "NUR_ONAV-013");

          String created_by= GetattributefromResponse(Response,"CREATED_BY");
          Response=StringToJSONObject(created_by);
          VerifyEntityData(Response, "Active", "true");


      }
  }

    @When("Perform a Get request to expand ES with filter and ES navigation property")

    public void perform_a_get_request_to_expand_ES_with_filter_and_ES_navigation_property() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES with filter and ES navigation property");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($expand=CREATED_BY;$filter="
                + URLEncoderForRequests("Barcode eq 'SUP2'")+")";

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES with filter and ES navigation property")

    public void verify_the_response_for_ES_with_filter_and_ES_navigation_property() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(1).toString();
            Response = StringToJSONObject(firstresp);
            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "Barcode", "SUP2");

            String created_by= GetattributefromResponse(Response,"CREATED_BY");
            Response=StringToJSONObject(created_by);
            VerifyEntityData(Response, "Active", "true");
        }
    }

    @When("Perform a Get request to expand ES with filter and select attribute")

    public void perform_a_Get_request_to_expand_ES_with_filter_and_select_attribute() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES with filter and select attribute");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($filter="
                + URLEncoderForRequests("Barcode eq 'SUP2'")+";$select=Name)";

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES with filter and select attribute")

    public void verify_the_response_for_ES_with_filter_and_select_attribute() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(1).toString();
            Response = StringToJSONObject(firstresp);
            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "Name", "Supplier Animal Study Test");
            VerifyEntityData(Response, "Barcode", "SUP2");
        }
    }

    @When("Perform a Get request to expand EC with filter navigation")

    public void perform_a_get_request_to_expand_EC_with_filter_navigation() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand EC with filter navigation");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1'")+")";

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for EC with filter navigation")

    public void verify_the_response_for_EC_with_filter_navigation() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(2).toString();
            Response = StringToJSONObject(firstresp);

            JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

            String firstresp1 = resp1.get(0).toString();
            Response = StringToJSONObject(firstresp1);

            VerifyEntityData(Response, "EntityTypeName", "NURSE");
        }
    }

    @When("Perform a Get request to expand ES with filter navigation")

    public void perform_a_get_request_to_expand_ES_with_filter_navigation() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand EC with filter navigation");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1'")+")" ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES with filter navigation")

    public void verify_the_response_for_ES_with_filter_navigation() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(1).toString();
            Response = StringToJSONObject(firstresp);

            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "EntityTypeName", "SUPPLIER_LIMITED");
        }
    }


    @When("Perform a Get request to expand ES with filter and expand nav entity attribute")

    public void perform_a_Get_request_to_expand_ES_with_filter_and_expand_nav_entity_attribute() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES with filter and expand nav entity attribute");

        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1';$expand=CREATED_BY")+")";

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES with filter and expand nav entity attribute")

    public void verify_the_response_for_ES_with_filter_and_expand_nav_entity_attribute() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(1).toString();
            Response = StringToJSONObject(firstresp);

            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);

            String created_by = GetattributefromResponse(Response, "CREATED_BY");
            Response = StringToJSONObject(created_by);
            VerifyEntityData(Response, "Barcode", "EM1");
        }
    }

    @When("Perform a Get request to expand ES with filter nav and select attribute")

    public void perform_a_Get_request_to_expand_ES_with_filter_nav_and_select_attribute() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES with filter nav and select attribute");
        //stringResponse = GetRequest(ApiConstants.Route_QueuePrioritization+"QUEUE_MEMBERS/any(x:x/REASON eq 'unknown')","");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1';$select=Barcode")+")"
                ;
        //Response = StringToJSONObject(stringResponse);
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES with filter nav and select attribute")

    public void verify_the_response_for_ES_with_filter_nav_and_select_attribute() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(1).toString();
            Response = StringToJSONObject(firstresp);

            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "Barcode", "SUP2");
        }
    }

    @When("Perform a Get request to expand EC with filter nav and select attribute")

    public void perform_a_Get_request_to_expand_EC_with_filter_nav_and_select_attribute() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES with filter nav and select attribute");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1';$select=Barcode")+")"
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for EC with filter nav and select attribute")

    public void verify_the_response_for_EC_with_filter_nav_and_select_attribute() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(2).toString();
            Response = StringToJSONObject(firstresp);

            JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

            String firstresp1 = resp1.get(0).toString();
            Response = StringToJSONObject(firstresp1);

            VerifyEntityData(Response, "Barcode", "NUR_ONAV-013");
        }
    }

    @When("Perform a Get request to expand ES and filter entity with select attribute")

    public void perform_a_Get_request_to_expand_ES_and_filter_entity_with_select_attribute() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES and filter entity with select attribute");
       String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($select=Barcode)&$filter="
                + URLEncoderForRequests("Barcode eq 'ASA1'")
                ;

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES and filter entity with select attribute")

    public void verify_the_response_for_ES_and_filter_entity_with_select_attribute() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            VerifyEntityData(Response, "EntityTypeName", "ANIMAL_SUBJECT_ACCESS_TEST");
            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "Barcode", "SUP2");
        }
    }

    @When("Perform a Get request to expand ES and filter nav entity with select attribute")

    public void perform_a_Get_request_to_expand_ES_and_filter_nav_entity_with_select_attribute() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand ES and filter nav entity with select attribute");
       String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_ANIMALSUPPLIER($select=Barcode)&$filter="
                + URLEncoderForRequests("ANIMAL_ANIMALSUPPLIER/Barcode eq 'SUP2'")
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for ES and filter nav entity with select attribute")

    public void verify_the_response_for_ES_and_filter_nav_entity_with_select_attribute() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            String animal_animalsupplier = GetattributefromResponse(Response, "ANIMAL_ANIMALSUPPLIER");
            Response = StringToJSONObject(animal_animalsupplier);
            VerifyEntityData(Response, "Barcode", "SUP2");
        }
    }

    @When("Perform a Get request to expand EC with filter nav and filter entity")

    public void perform_a_Get_request_to_expand_EC_with_filter_nav_and_filter_entity() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand EC with filter nav and filter entity");
         String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1' and Barcode eq 'NUR_ONAV-013'")+")"
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for EC with filter nav and filter entity")

    public void verify_the_response_for_EC_with_filter_nav_and_filter_entity() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(2).toString();
            Response = StringToJSONObject(firstresp);
            //VerifyEntityData(Response, "EntityTypeName", "ANIMAL_SUBJECT_ACCESS_TEST");
            JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

            String firstresp1 = resp1.get(0).toString();
            Response = StringToJSONObject(firstresp1);

            VerifyEntityData(Response, "Barcode", "NUR_ONAV-013");
        }
    }

    @When("Perform a Get request to expand EC with filter nav and filter entity and expand nav")

    public void perform_a_Get_request_to_expand_EC_with_filter_nav_and_filter_entity_and_expand_nav() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand EC with filter nav and filter entity and expand nav");
         String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($filter="
                + URLEncoderForRequests("CREATED_BY/Barcode eq 'EM1' and Barcode eq 'NUR_ONAV-013';$expand=CREATED_BY")+")"
                ;

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for EC with filter nav and filter entity and expand nav")

    public void verify_the_response_for_EC_with_filter_nav_and_filter_entity_and_expand_nav() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(2).toString();
            Response = StringToJSONObject(firstresp);

            JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

            String firstresp1 = resp1.get(0).toString();
            Response = StringToJSONObject(firstresp1);

            VerifyEntityData(Response, "Barcode", "NUR_ONAV-013");

            String created_by= GetattributefromResponse(Response,"CREATED_BY");
            Response=StringToJSONObject(created_by);
            VerifyEntityData(Response, "Barcode", "EM1");
        }
    }

    @When("Perform a Get request to expand EC with filter nav and filter entity and expand nav and nested expand")

    public void perform_a_Get_request_to_expand_EC_with_filter_nav_and_filter_entity_and_expand_nav_and_nested_expand() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand EC with filter nav and filter entity and expand nav and nested expand");
         String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=ANIMAL_NURSES($filter="
                + URLEncoderForRequests("CREATED_BY/LOCATION/Barcode eq 'LC1';$expand=CREATED_BY($expand=LOCATION)")+")"
                ;

        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for EC with filter nav and filter entity and expand nav and nested expand")

    public void verify_the_response_for_EC_with_filter_nav_and_filter_entity_and_expand_nav_and_nested_expand() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i< 1; i++) {
            String firstresp = resp.get(2).toString();
            Response = StringToJSONObject(firstresp);

            JSONArray resp1 = JSONObjectToJsonArray(Response, "ANIMAL_NURSES");

            String firstresp1 = resp1.get(0).toString();
            Response = StringToJSONObject(firstresp1);

            //VerifyEntityData(Response, "Barcode", "NUR_ONAV-013");

            String created_by= GetattributefromResponse(Response,"CREATED_BY");
            Response=StringToJSONObject(created_by);

            String location= GetattributefromResponse(Response,"LOCATION");
            Response=StringToJSONObject(location);
            VerifyEntityData(Response, "Barcode", "LC1");
        }


    }

    @When("Perform a Get request to expand Project with filter")

    public void perform_a_Get_request_to_expand_Project_with_filter() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand Project with filter");
        String stringResponse = ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST+"?$expand=PROJECT($filter="
                + URLEncoderForRequests("Active eq true")+")"
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for Expand Project with filter")

    public void verify_the_response_for_expand_project_with_filter() throws Exception {

        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i<resp.size(); i++)
    {
        String firstresp = resp.get(i).toString();
        Response = StringToJSONObject(firstresp);

        JSONArray resp1 = JSONObjectToJsonArray(Response, "PROJECT");

        String firstresp1 = resp1.get(0).toString();
        Response = StringToJSONObject(firstresp1);

        VerifyEntityData(Response, "Active", "true");
    }
    }

    @Given("Login into ODATA for Filter Project navigation")
    public void Login_into_ODATA_for_Filter_Project_navigation() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("Given: ", "Login into ODATA for Filter Project navigation");
        Readprerequest();
    }

    @When("Create a GET request for Filter Project navigation")
    public void Create_a_GET_request_for_Filter_Project_navigation() throws Exception {
        //Prerequisite
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        //GET method
        reportInstance.logInfo("When: ", "Create a GET request for Filter Project navigation");
        GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST + "('" + entity + "')/PROJECT??$filter=", "Active eq true", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for ENTITY_TYPE with filter")
    public void Create_a_GET_request_for_ENTITY_TYPE_with_filter() throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for ENTITY_TYPE with filter");
        GetRequest(ApiConstants.Route_ENTITY_TYPE + "?$expand=", "SUPER_TYPE($filter=Name eq 'EMPLOYEE')", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for CELL with filter")
    public void Create_a_GET_request_for_CELL_with_filter() throws Exception {
        //Prerequisite
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_CELL + "?$expand=", "CELL_CONTENTS", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            String firstresp = resp.get(0).toString();
            Response=StringToJSONObject(firstresp);
            JSONArray CELL_CONTENTS = JSONObjectToJsonArray(Response, "CELL_CONTENTS");
            if (CELL_CONTENTS.size() > 0) {
                prerequisite = false;
                String innerresp = CELL_CONTENTS.get(0).toString();
                Response = StringToJSONObject(innerresp);
                entity = GetattributefromResponse(Response, "Id");
            }

        } else if(prerequisite =true) {
            Response = postRequest("", ApiConstants.Route_CELL + "?$expand=" + URLEncoderForRequests("CELL_CONTENTS"), HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Id");
            reportInstance.logInfo("When: ", "Create a GET request for CELL with filter");
            GetRequest(ApiConstants.Route_CELL + "?$expand=", "CELL_CONTENTS($filter=Id eq " + entity + ")", HttpURLConnection.HTTP_OK);
        }
    }

    @When("Create a GET request for EXPERIMENT with filter")
    public void Create_a_GET_request_for_EXPERIMENT_with_filter() throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for EXPERIMENT with filter");
        GetRequest(ApiConstants.Route_US_BODY_WEIGHT_EXPERIMENT + "?$expand=", "EXPERIMENT_PROTOCOL($filter=Active eq true)", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Sample Lot with filter")
    public void Create_a_GET_request_for_Sample_Lot_with_filter() throws Exception {
        //Prerequisite
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_SMALL_MOLECULE_LOT, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_SMALL_MOLECULE_LOT, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        reportInstance.logInfo("When: ", "Create a GET request for Sample Lot with filter");
        GetRequest(ApiConstants.Route_SMALL_MOLECULE_LOT + "('"+entity+"')?$expand=", "SD_FILE($filter=Active eq true)", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for QUEUE_MEMBER with filter")
    public void Create_a_GET_request_for_QUEUE_MEMBER_with_filter() throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for QUEUE_MEMBER with filter");
        GetRequest(ApiConstants.Route_PRIORITIZATION_QUEUE_MEMBER + "?$expand=", "MEMBER($filter=Active eq true)", HttpURLConnection.HTTP_OK);
    }


    @When("Create a GET request for single well container")
    public void Create_a_GET_request_for_single_well_container() throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for single well container");
        String encodedurl = ApiConstants.Route_96_WELL_MICRO_TITER + "?$count=true" + "&$expand="+URLEncoderForRequests("PROJECT,LOCATION,CREATED_BY,CELLS($expand=CONTAINER,CELL_CONTENTS($expand=SAMPLE_LOT))");
        GetRequest(encodedurl);
    }

    @When("Create a GET request for top expand and nested expand")
    public void Create_a_GET_request_for_top_expand_and_nested_expand() throws Exception {
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_ANIMAL_LIMITED, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_ANIMAL_LIMITED, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        reportInstance.logInfo("When: ", "Create a GET request for top expand and nested expand");
        GetRequest(ApiConstants.Route_ANIMAL_LIMITED + "('"+entity+"')?$expand=", "ANIMAL_NURSES($orderby=Barcode desc;$expand=PROJECT($orderby=Name))\n" +
                "\n", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for first expand then expand")
    public void Create_a_GET_request_for_first_expand_then_expand() throws Exception {
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_ANIMAL_LIMITED, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_ANIMAL_LIMITED, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        reportInstance.logInfo("When: ", "Create a GET request for first expand then expand");
        GetRequest(ApiConstants.Route_ANIMAL_LIMITED + "('"+entity+"')?$expand=", "ANIMAL_NURSES($orderby=Barcode;$top=2;$expand=PROJECT)", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for nested expand")
    public void Create_a_GET_request_for_nested_expand() throws Exception {
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_ANIMAL_LIMITED, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_ANIMAL_LIMITED, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        reportInstance.logInfo("When: ", "Create a GET request for nested expand");
        GetRequest(ApiConstants.Route_ANIMAL_LIMITED + "('"+entity+"')?$expand=", "ANIMAL_NURSES($expand=PROJECT($orderby=Barcode;$top=2))", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Count on nested expand")
    public void Create_a_GET_request_for_Count_on_nested_expand() throws Exception {
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        reportInstance.logInfo("When: ", "Create a GET request for Count on nested expand");
        GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST + "('"+entity+"')?$expand=", "ANIMAL_NURSES($expand=PROJECT($count=true))", HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for EMPLOYEE with filter")
    public void Create_a_GET_request_for_EMPLOYEE_with_filter() throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for EMPLOYEE with filter");
        String encodedurl = ApiConstants.Route_EMPLOYEE_LIMITED + "?&$expand="+URLEncoderForRequests("EMPLOYEE_APPLICATIONS($filter=Name eq 'ci_app_lims_admin')");
        GetRequest(encodedurl);
    }

    @When("Create a GET request for Multi expand SMALL_MOLECULE_LOT")
    public void Create_a_GET_request_for_Multi_expand_SMALL_MOLECULE_LOT() throws Exception {
        reportInstance.logInfo("When: ", "Create a GET request for Multi expand SMALL_MOLECULE_LOT");
        String encodedurl= ApiConstants.Route_SMALL_MOLECULE_LOT + "?$count=true" + "&$expand=" + URLEncoderForRequests("PROJECT($filter=Active eq true),LOCATION($filter=Active eq true),CREATED_BY($filter=Active eq true),QUEUE_MEMBER_REFS,CELL_CONTENTS,SAMPLE($filter=Active eq true),SD_FILE($filter=Active eq true)") +"&$top=25" + "&$filter=" +URLEncoderForRequests("Active eq true");
        GetRequest(encodedurl);
    }

    @When("Create a GET request for full metadata")
    public void Create_a_GET_request_for_for_full_metadata() throws Exception {
        prerequisite = true;
        reportInstance.logInfo("prerequite: ", "checking for any available entities and creating one if not available");
        strResponse = GetRequest(ApiConstants.Route_ANIMAL_LIMITED, "");
        Response = StringToJSONObject(strResponse);
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        if (resp.size() > 0) {
            prerequisite = false;
            String firstresp = resp.get(0).toString();
            Response = StringToJSONObject(firstresp);
            entity = GetattributefromResponse(Response, "Barcode");
        } else if (prerequisite = true) {
            Response = postRequest("", ApiConstants.Route_ANIMAL_LIMITED, HttpURLConnection.HTTP_CREATED);
            entity = GetattributefromResponse(Response, "Barcode");
        }
        reportInstance.logInfo("When: ", "Create a GET request for nested expand");
        String encodedurl =ApiConstants.Route_ANIMAL_LIMITED + "('"+entity+"')?$expand=" +URLEncoderForRequests("ANIMAL_NURSES($expand=PROJECT)");
        GetRequest(encodedurl, "", UpdateRequestHeader("Accept", "application/json; odata.metadata=full"));
    }

}



