package ApiStepDefinitions.Regression;


import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.ArrayList;
import java.util.HashMap;

public class QueueAction_StepDefinitions extends DBHelper {
    /**
     * Parser to have JSON Parser
     */
    JSONObject Response;
    ArrayList<String> qbarcode = new ArrayList<>();
    String Barcode;
    String invalidBarcode;
    String ResourcePath = "/RegressionTests/QueueAction";


    @Given("Login into ODATA for QueueAction")
    public void Login_into_ODATA_for_QueueAction() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a POST request for Add member without customization {string}")
    public void Create_a_POST_request_for_Add_member_without_customization(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/Addmemberwithoutcustomization.json");
        reportInstance.logInfo("json Request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Add member with specific values {string}")
    public void Create_a_POST_request_for_Add_member_with_specific_values(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithSpecificValues.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Add member with requestor and requested date overrides {string}")
    public void Create_a_POST_request_for_Add_member_with_requestor_and_requested_date_overrides(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithRequestorAndRequestedDateOverrides.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Add member with invalid barcodes {string}")
    public void Create_a_POST_request_for_Add_member_with_invalid_barcodes(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithInvalidBarcodes.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_NOT_FOUND);
    }

    @Then("verify the error message {string} for Add member with invalid barcodes")
    public void verify_the_error_message_for_Add_member_with_invalid_barcodes(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ENTITY_NOT_FOUND_ERROR_CODE, errorMessage);
    }

    @When("Create a POST request for Add member with blank barcodes {string}")
    public void Create_a_POST_request_for_Add_member_with_blank_barcodes(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithBlankBarcodes.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_NOT_FOUND);
    }

    @Then("verify the error message {string} for Add member with blank barcodes")
    public void verify_the_error_message_for_Add_member_with_blank_barcodes(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ENTITY_NOT_FOUND_ERROR_CODE, errorMessage);
    }

    @When("Create a POST request for Add member with invalid Prioritization Queue {string}")
    public void Create_a_POST_request_for_Add_member_with_invalid_Prioritization_Queue(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithInvalidPrioritizationQueue.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_NOT_FOUND);
    }

    @Then("verify the error message {string} for Add member with invalid Prioritization Queue")
    public void verify_the_error_message_for_Add_member_with_invalid_Prioritization_Queue(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ENTITY_NOT_FOUND_ERROR_CODE, errorMessage);
    }

    @When("Create a POST request for Add member with Invalid Requestor Override {string}")
    public void Create_a_POST_request_for_Add_member_with_Invalid_Requestor_Override(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithInvalidRequestorOverride.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify the error message {string} for Add member with Invalid Requestor Override")
    public void verify_the_error_message_for_Add_member_with_Invalid_Requestor_Override(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL, errorMessage);
    }

    @When("Create a POST request for Add member with invalid RequestedDateTimeOverride Format {string}")
    public void Create_a_POST_request_for_Add_member_with_invalid_RequestedDateTimeOverride_Format(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithInvalidRequestedDateTimeOverrideFormat.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify the error message {string} for Add member with invalid RequestedDateTimeOverride Format")
    public void verify_the_error_message_for_Add_member_with_invalid_RequestedDateTimeOverride_Format(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, errorMessage);
    }

    @When("Create a POST request for Fulfill member with single Queue Member Barcode {string} and {string}")
    public void Create_a_POST_request_for_Fulfill_member_with_single_Queue_Member_Barcode(String route, String route2) throws Exception {
        JSONObject preRequest = ReadJsonInput(ResourcePath + "/Addmemberwithoutcustomization.json");
        reportInstance.logInfo("json request body", preRequest.toString());
        Response = postRequest(preRequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_OK);
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    qbarcode.add(GetattributefromResponse(Response, "Barcode"));
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("Barcode is empty", "");
            throw e;
        }
        reportInstance.logInfo("STEPS", "POST request for Add member with single Queue Member Barcode");
        JSONObject Request = ReadJsonInput(ResourcePath + "/FulfillMemberWithSingleQueueMemberBarcode.json");
        JSONArray singlemem=new JSONArray();
        singlemem.add(qbarcode.get(0));
        Request.put("QueueMemberBarcodes",singlemem);
        reportInstance.logInfo("request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route2, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Fulfill member with multiple Queue Member Barcode {string} and {string}")
    public void Create_a_POST_request_for_Fulfill_member_with_multiple_Queue_Member_Barcode(String route, String route2) throws Exception {
        JSONObject preRequest = ReadJsonInput(ResourcePath + "/Addmemberwithoutcustomization.json");
        reportInstance.logInfo("json request body", preRequest.toString());
        Response = postRequest(preRequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_OK);
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    qbarcode.add(GetattributefromResponse(Response, "Barcode"));
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("Barcode is empty", "");
            throw e;
        }
        reportInstance.logInfo("STEPS", "POST request for Add member with multiple Queue Member Barcode");
        JSONObject Request = ReadJsonInput(ResourcePath + "/FulfillMemberWithMultipleQueueMemberBarcode.json");
        JSONArray multiplemem=new JSONArray();
        multiplemem.add(qbarcode.get(0));
        multiplemem.add(qbarcode.get(1));
        Request.put("QueueMemberBarcodes",multiplemem);
        reportInstance.logInfo("STEPS", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route2, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Add member Barcode which is already been fulfilled {string} and {string}")
    public void Create_a_POST_request_for_Add_member_Barcode_which_is_already_been_fulfilled(String route, String route2) throws Exception {
        JSONObject preRequest = ReadJsonInput(ResourcePath + "/Addmemberwithoutcustomization.json");
        reportInstance.logInfo("STEPS", preRequest.toString());
        Response = postRequest(preRequest.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_OK);
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    qbarcode.add(GetattributefromResponse(Response, "Barcode"));
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("Barcode is empty", "");
            throw e;
        }
        reportInstance.logInfo("STEPS", "POST request for Add member with single Queue Member Barcode");
        JSONObject Request = ReadJsonInput(ResourcePath + "/FulfillMemberWithSingleQueueMemberBarcode.json");
        JSONArray singlemem = new JSONArray();
        singlemem.add(qbarcode.get(0));
        Request.put("QueueMemberBarcodes", singlemem);
        reportInstance.logInfo("STEPS", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route2, HttpURLConnection.HTTP_OK);
        reportInstance.logInfo("STEPS", "Adding member Barcode which is already been fulfilled");
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route2, HttpURLConnection.HTTP_BAD_REQUEST);
        Barcode=singlemem.get(0).toString();
    }

    @Then("verify the error message for Add member Barcode which is already been fulfilled")
    public void verify_the_error_message_for_Add_member_Barcode_which_is_already_been_fulfilled() throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL, "Queue Member with barcode '"+Barcode+"' has been fulfilled before");
    }

    @When("Create a POST request for Fulfill with invalid Queue Member Barcode {string}")
    public void Create_a_POST_request_for_Fulfill_with_invalid_Queue_Member_Barcode(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/FulfillWithInvalidQueueMemberBarcode.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_BAD_REQUEST);
        JSONArray readjson = JSONObjectToJsonArray(ReadJsonInput(ResourcePath + "/FulfillWithInvalidQueueMemberBarcode.json"), "QueueMemberBarcodes");
        invalidBarcode = readjson.get(0).toString();

    }

    @Then("verify the error message for Fulfill with invalid Queue Member Barcode")
    public void verify_the_error_message_for_Fulfill_with_invalid_Queue_Member_Barcode() throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL, "Queue Member with barcode '"+invalidBarcode+"' does not exist");
    }

    @When("Create a POST request for Add member with invalid priority {string}")
    public void Create_a_POST_request_for_Add_member_with_invalid_priority(String route) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/AddMemberWithInvalidPriority.json");
        reportInstance.logInfo("json request body", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify the error message {string} for Add member with invalid priority")
    public void verify_the_error_message_for_Add_member_with_invalid_priority(String errorMessage) throws Exception {
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE, errorMessage);
    }
}
