package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;


public class AdvancedDetails_Filtering_StepDefinitions extends DBHelper {
    JSONObject Response;
    String strResponse;

    @Given("Login into ODATA for AdvancedDetails_Filtering")
    public void Login_into_ODATA_for_AdvancedDetails_Filtering() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request for Get entity following Created_By navigation {string}")
    public void Create_a_GET_request_for_Get_entity_following_Created_By_navigation(String string) throws Exception {
        strResponse = GetRequest(ApiConstants.Route_master + string, "");
    }

    @Then("verify Barcode {string}")
    public void verify_Barcode(String expectedBarcode) throws Exception {
        String barcode = GetattributefromResponse(StringToJSONObject(strResponse), "Barcode");
        Assert.assertEquals(expectedBarcode, barcode);
    }

    @When("Create a GET request for Filter entities by a creator attribute {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_for_Filter_entities_by_a_creator_attribute(String string, String string2, String string3, String string4) throws Exception {
        string = string + URLEncoderForRequests(string2) + string3 + URLEncoderForRequests(string4);
        strResponse = GetRequest(ApiConstants.Route_master + string, "");
    }

    @Then("verify EntityTypeName by creator attribute {string}")
    public void verify_EntityTypeNameby_creator_attribute(String expectedEntityTypeName) throws Exception {
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(strResponse), "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String entityTypeName = GetattributefromResponse(Response, "EntityTypeName");
                Assert.assertEquals(expectedEntityTypeName, entityTypeName);
            }
            break;
        }
    }

    @When("Create a GET request for Filter entities by creator attributes and entity attributes {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_for_Filter_entities_by_creator_attributes_and_entity_attributes(String string, String string2, String string3, String string4) throws Exception {
        string = string + URLEncoderForRequests(string2) + string3 + URLEncoderForRequests(string4);
        strResponse = GetRequest(ApiConstants.Route_master + string, "");
    }

    @Then("verify EntityTypeName by entity attributes {string}")
    public void verify_EntityTypeName_by_entity_attributes(String expectedEntityTypeName) throws Exception {
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(strResponse), "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String entityTypeName = GetattributefromResponse(Response, "EntityTypeName");
                Assert.assertEquals(expectedEntityTypeName, entityTypeName);
            }
            break;
        }
    }

    @When("Create a GET request for Filter entities by creator attribute and status {string} and {string}")
    public void Create_a_GET_request_for_Filter_entities_by_creator_attribute_and_status(String string, String string2) throws Exception {
        string = string + URLEncoderForRequests(string2);
        strResponse = GetRequest(ApiConstants.Route_master + string, "");
    }

    @Then("verify EntityTypeName by creator status {string}")
    public void verify_EntityTypeName_by_creator_status(String expectedEntityTypeName) throws Exception {
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(strResponse), "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String entityTypeName = GetattributefromResponse(Response, "EntityTypeName");
                boolean entitycontains= entityTypeName.contains(expectedEntityTypeName);
                reportInstance.logInfo("entity contains", String.valueOf(entitycontains));
            }
            break;
        }
    }

}

