package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;

public class OdataVersionResponeHeaderStepDefinitions extends DBHelper {

    HttpURLConnection con;

    @Given("Login into ODATA for OdataVersionResponseHeader")
    public void Login_into_ODATA_for_OdataVersionResponseHeader() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request for response header of no authentication error {string}")
    public void Create_a_GET_request_for_response_header_of_no_authentication_error(String route) throws Exception {
        con = SendRequest(ApiConstants.Route_master+route, "", new HashMap(), "GET");
    }

    @Then("Verify error message for response header of no authentication error")
    public void Verify_error_message_for_response_header_of_no_authentication_error() throws Exception {
        int responsecode = con.getResponseCode();
        ValidateExceptedResponseCode(responsecode, Integer.parseInt(ApiConstants.ERROR_CODE_UNAUTHORIZED));
    }

    @When("Create a GET request for response header of invalid authentication error {string} and {string} and {string}")
    public void Create_a_GET_request_for_response_header_of_invalid_authentication_error(String route, String headerKey, String headerValue) throws Exception {
        con = SendRequest(ApiConstants.Route_master+route, "", UpdateRequestHeader(headerKey, headerValue), "GET");
    }

    @Then("Verify error message for response header of invalid authentication error")
    public void Verify_error_message_for_response_header_of_invalid_authentication_error() throws Exception {
        int responsecode = con.getResponseCode();
        ValidateExceptedResponseCode(responsecode, Integer.parseInt(ApiConstants.ERROR_CODE_UNAUTHORIZED));
    }

}
