package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import java.net.HttpURLConnection;
import java.util.HashMap;

public class HeadMethod_StepDefinitions extends DBHelper{

    HttpURLConnection conn;
    String response;

    @Given("Login into ODATA for Head Method")
    public void login_into_ODATA_for_Head_Method() throws Exception {
        reportInstance=SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a HEAD request for Get meta data document {string}")
    public void Create_a_HEAD_request_for_Get_meta_data_document(String route) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route, "", DefaultRequestHeader(), "HEAD");
    }

    @Then("verify no response body but response header present {string} and {string}")
    public void verify_no_response_body_but_response_header_present(String headerKey, String headerValue) throws Exception {
        response=GetResponseBody(conn);
        if(response.equals("")){
            reportInstance.logPass("validating response body", "null as expected");
        }
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
        HashMap<String, String> expectedHeader = new HashMap();
        expectedHeader.put(headerKey,headerValue);
        ValidateExceptedResponseHeader(conn, expectedHeader);
    }

    @When("Create a HEAD request for Filter entity {string} and {string}")
    public void Create_a_HEAD_request_for_Filter_entity(String route, String filterParam) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route+URLEncoderForRequests(filterParam), "", DefaultRequestHeader(), "HEAD");
    }

    @When("Create a HEAD request for Filter not existing entity {string}")
    public void Create_a_HEAD_request_for_Filter_not_existing_entity(String route) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route, "", DefaultRequestHeader(), "HEAD");
    }

    @Then("verify error response for Filter not existing entity")
    public void verify_error_response_for_Filter_not_existing_entity() throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NOT_FOUND);

    }

    @When("Create a HEAD request for entity with media {string}")
    public void Create_a_HEAD_request_for_entity_with_media(String route) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+route, "", DefaultRequestHeader(), "HEAD");
    }

    @Then("verify response header present {string} and {string}")
    public void verify_response_header_present(String headerKey, String headerValue) throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
        HashMap<String, String> expectedHeader = new HashMap();
        expectedHeader.put(headerKey,headerValue);
        ValidateExceptedResponseHeader(conn, expectedHeader);
    }
}
