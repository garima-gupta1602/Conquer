package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class FullSubTypeReturnWithinParentTypeRequestStepDefinitions extends DBHelper{

    String ResourcePath ="/RegressionTests/QueueAction/OData4.0Conformance/FullSubTypeReturnWithinParentTypeRequest";

    @Given("Login into ODATA for FullSubTypeReturnWithinParentTypeRequest")
    public void login_into_ODATA_for_FullSubTypeReturnWithinParentTypeRequest() throws Exception{
        reportInstance=SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request for Access sub type via parent type ENTITY {string} and {string}")
    public void Create_a_GET_request_for_Access_sub_type_via_parent_type_ENTITY(String route, String filterParam) throws Exception{
        String Request=GetRequest(ApiConstants.Route_master+route, filterParam, HttpURLConnection.HTTP_OK);
    }

    @When("Create a GET request for Access sub types via super type {string}")
    public void Create_a_GET_request_for_Access_sub_types_via_super_type(String route) throws Exception{
        GetRequest(ApiConstants.Route_master+route);
    }
}
