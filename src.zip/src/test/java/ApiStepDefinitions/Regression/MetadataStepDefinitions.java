package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.rmi.NoSuchObjectException;

public class MetadataStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse, stringResponse1;
    String ResourcePath="/RegressionTests/QueueAction/Metadata";

    @Given("Login into Odata for Metadata")
    public void login_into_odata_for_metadata() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into Odata for Metadata");
        Readprerequest();
    }

    @When("^Send a GET request to get metadata with the value \"([^\"]*)\"$")
    public void sendAGETRequestToGetMetadataWithTheValue(String route)throws Exception {
        String url=ApiConstants.Route_master+route;
        stringResponse = GetRequest(url,"",UpdateRequestHeader("OData-MaxVersion","4.0"));
    }

    @Then("Verify in the response that entity type contains annotation of unescaped name")
    public void verify_in_the_response_that_entity_type_contains_annotation_of_unescaped_name() throws Exception {
        if(stringResponse.contains("<Annotation Term=\"pfs.UnescapedName\">")) {
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in xml format");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @Then("Verify in the response that entity type exclude abstract equal true")
    public void verify_in_the_response_that_entity_type_exclude_abstract_equal_true() throws IOException {
        if(stringResponse.contains("Abstract=\"true\"")) {
            reportInstance.logPass("Then ", "Verify in the response that entity type exclude abstract equal true");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @When("Send request to get Metadata with version 4.0 in request header and the value {string}")
    public void send_request_to_get_metadata_with_version_4_0_in_request_header_and_the_value(String route) throws Exception {
       String url=ApiConstants.Route_master+route;
       stringResponse = GetRequest(url,"",UpdateRequestHeader("OData-MaxVersion","4.0"));
    }

    @Then("Verify the version in response and metadata is in xml format")
    public void verify_the_version_in_response_and_metadata_is_in_xml_format() throws IOException {
        if(stringResponse.contains("xml")) {
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in xml format");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @When("Send request to get Metadata with version in request header with the value {string}")
    public void send_request_to_get_metadata_with_version_in_request_header_with_the_value(String route) throws Exception {
        JSONObject Request= ReadJsonInput(ResourcePath+"/Metadata.json");
        String url=ApiConstants.Route_master+route;
        Response =postRequest(Request.toString(),url,UpdateRequestHeader("OData-MaxVersion","3.0"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the error message and check for version not supported")
    public void verify_the_error_message_and_check_for_version_not_supported() throws Exception {
        VerifyErrorMessage(Response,"2000","OData version '3.0' is not supported.");
    }

    @Then("Verify in the response that entity key property refernce is non-nullable")
    public void verify_in_the_response_that_entity_key_property_refernce_is_non_nullable() throws IOException {
        if(stringResponse.contains("<EntityType Name=\"TYPE_ASSOCIATION\"><Key><PropertyRef Name=\"Id\"/></Key><Property Name=\"Id\" Type=\"Edm.Int32\" Nullable=\"false\"/><")&&
                stringResponse.contains(("<EntityType Name=\"TYPE_ATTRIBUTE\"><Key><PropertyRef Name=\"Id\"/></Key><Property Name=\"Id\" Type=\"Edm.Int32\" Nullable=\"false\"/>"))) {
            reportInstance.logPass("Then ", "Verify in the response that entity key property refernce is non-nullable");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @Then("Verify in the response naming convention of unescaped term")
    public void verify_in_the_response_naming_convention_of_unescaped_term() throws IOException {
        if(stringResponse.contains("><Term Name=\"UnescapedName\" Type=\"Edm.String\"><Annotation Term=\"pfs.Description\"><String>The unescaped name of the entity type name in PFS.</String></Annotation></Term>")) {
            reportInstance.logPass("Then ", "Verify in the response naming convention of unescaped term");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @Then("Verify in the response that scale property is not applicable for Integer type")
    public void verify_in_the_response_that_scale_property_is_not_applicable_for_integer_type() throws IOException {
        if(stringResponse.contains("<<Property Name=\"CI_RANK\" Type=\"Edm.Int32\"></Property>")) {
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in xml format");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @When("Send a GET request with the value {string} and max version greater than current support in header")
    public void send_a_get_request_with_the_value_and_max_version_greater_than_current_support_in_header(String route) throws Exception {
        String url=ApiConstants.Route_master+route;
        stringResponse = GetRequest(url,"",UpdateRequestHeader("OData-MaxVersion","5.0"));
        stringResponse1=GetRequest(url,"",UpdateRequestHeader("OData-MaxVersion","4.0.2"));
    }

    @Then("Verify the version in response and metadata is in XML format")
    public void verify_the_version_in_response_and_metadata_is_in_XML_format() throws IOException {
        if((stringResponse.contains("Version=\"4.0\""))&&(stringResponse1.contains("Version=\"4.0\"")) ){
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in XML format");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @When("Send a GET request with the value {string} and invalid OData Max version in header")
    public void send_a_GET_request_with_the_value_and_invalid_OData_max_version_in_header(String route) throws Exception {
        String url=ApiConstants.Route_master+route;
        JSONObject Request= ReadJsonInput(ResourcePath+"/Metadata.json");
        Response =postRequest(Request.toString(), url,UpdateRequestHeader("OData-MaxVersion","5,7"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the error message in response stating invalid Max version")
    public void verify_the_error_message_in_response_stating_invalid_max_version() throws Exception {
        VerifyErrorMessage(Response,"2000","OData version '5,7' is not supported.");
    }

    @Then("Verify in the response that property and navigation property names are differed from entity type name")
    public void verify_in_the_response_that_property_and_navigation_property_names_are_differed_from_entity_type_name() throws IOException {
        if(stringResponse.contains("<EntityType Name=\"ENTITY_TYPE_ATTRIBUTE\" BaseType=\"pfs.PEOPLE\"> <Property Name=\"ENTITY_TYPE_ATTRIBUTE_1\"")) {
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in xml format");
        }
        else
            reportInstance.logFail("","Failed");
    }
    @Then("Verify in the response that non abstract entity contain a key")
    public void verify_in_the_response_that_non_abstract_entity_contain_a_key() throws IOException {
        if(stringResponse.contains("><EntityType Name=\"REPORT_FORMAT_SPECIAL\"><Key><PropertyRef Name=\"Id\"/></Key>")) {
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in xml format");
        }
        else
            reportInstance.logFail("","Failed");
    }

    @Then("Verify in the response that report format special is base type of individual report type")
    public void verify_in_the_response_that_report_format_special_is_base_type_of_individual_report_type() throws IOException {
        if(stringResponse.contains("EntityType Name=\"AL1_REPORT_FORMAT\" BaseType=\"pfs.REPORT_FORMAT_SPECIAL\">")) {
            reportInstance.logPass("Then ", "Verify the version in response and metadata is in xml format");
        }
        else
            reportInstance.logFail("","Failed");
    }
}
