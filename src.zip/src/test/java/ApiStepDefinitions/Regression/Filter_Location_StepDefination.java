package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class Filter_Location_StepDefination extends DBHelper {
    JSONObject Response;
    String stringResponse;


    @Given("^Login into ODATA to get Location$")
    public void loginIntoODATAToGetLocation()  {
        reportInstance=SharedClassApi.getReportInstance();
        Readprerequest();
    }
    @When("^Create a Get request to get the Location with more than two navigation with the value \"([^\"]*)\"$")
    public void createAGetRequestToGetTheLocationWithMoreThanTwoNavigationWithTheValue(String route)  throws Throwable {
        String endurl= ApiConstants.Route_master+route;
        stringResponse=GetRequest(endurl,"");
        Response=StringToJSONObject(stringResponse);
    }

    @Then("^Validate response with  Location enitity Name value \"([^\"]*)\"$")
    public void validateResponseWithLocationEnitityNameValue(String EntityTypeName){
        VerifyEntityData(Response,"EntityTypeName",EntityTypeName);
    }

    @When("^Create a Get request to filter location with more than two navigation and with the value \"([^\"]*)\" and \"([^\"]*)\"$")
    public void createAGetRequestToFilterLocationWithMoreThanTwoNavigationAndWithTheValueAnd(String param1, String param2)throws Throwable {
        String endpointurl=ApiConstants.Route_master+param1+URLEncoderForRequests(param2);
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }
    @Then("^Validate the \"([^\"]*)\" is null$")
    public void validateTheIsNull(String ciconc) throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            if (Response.get(ciconc) == null) {
                System.out.println("success");
            }
        }
    }
}
