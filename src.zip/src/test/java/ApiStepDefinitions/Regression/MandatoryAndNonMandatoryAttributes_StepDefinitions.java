package ApiStepDefinitions.Regression;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
public class MandatoryAndNonMandatoryAttributes_StepDefinitions extends DBHelper{
    JSONObject Response;
    String ResourcePath = "/RegressionTests/QueueAction/MandatoryAndNonMandatoryAttributes";
    String updateValue;
    int updateVal;
    double updateval;


    @Given("Login into ODATA for MATT")
    public void login_into_ODATA_for_MATT() throws Exception {
        reportInstance=SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a POST request for entity with mandatory attributes {string}")
    public void Create_a_POST_request_for_entity_with_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/EntityWithMandatoryAttributes.json");
        Response = postRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify valid response for entity with mandatory attributes {string} and {string}")
    public void verify_valid_response_for_entity_with_mandatory_attributes(String EntityTypeName, String entityName) throws Exception {
        VerifyEntityData(Response,EntityTypeName, entityName);
    }

    @When("Create a POST request for missing mandatory attributes {string}")
    public void Create_a_POST_request_for_missing_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/EntitymissingMandatoryAttributes.json");
        Response = postRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for missing mandatory attributes {string} and {string}")
    public void verify_error_message_for_missing_mandatory_attributes(String errorCode, String errorMessage) throws Exception {
        VerifyErrorMessage(Response, errorCode, errorMessage);
    }

    @When("Create a PUT request for valid mandatory attributes {string}")
    public void Create_a_PUT_request_for_valid_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        updateValue = "Test"+RandomAlphanumericGenerate(4);
        prerequest.put("STRING_MAN", updateValue);
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_OK);
    }

    @Then("verify valid response for entity with valid mandatory attributes {string}")
    public void verify_valid_response_for_entity_with_valid_mandatory_attributes(String entityKey) throws Exception {
        VerifyEntityData(Response, entityKey, updateValue);
    }

    @When("Create a PUT request for missing mandatory attributes {string}")
    public void Create_a_PUT_request_for_missing_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        prerequest.remove("DATETIME_MAN");
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify put error message for missing mandatory attributes {string} and {string}")
    public void verify_put_error_message_for_missing_mandatory_attributes(String errorCode, String errorMessage) throws Exception {
        VerifyErrorMessage(Response, errorCode, errorMessage);
    }

    @When("Create a PUT request for invalid mandatory attribute {string}")
    public void Create_a_PUT_request_for_invalid_mandatory_attribute(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        prerequest.replace("DATETIME_MAN", "test");
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify put error message for invalid mandatory attribute {string} and {string}")
    public void verify_put_error_message_for_invalid_mandatory_attribute(String errorCode, String errorMessage) throws Exception {
        VerifyErrorMessage(Response, errorCode, errorMessage);
    }

    @When("Create a POST request for entity with non mandatory attributes {string}")
    public void Create_a_POST_request_for_entity_with_non_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/EntityWithNonMandatoryAttributes.json");
        Response = postRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify valid response for entity with non mandatory attributes {string} and {string}")
    public void verify_valid_response_for_entity_with_non_mandatory_attributes(String EntityTypeName, String entityName) throws Exception {
        VerifyEntityData(Response,EntityTypeName, entityName);
    }

    @When("Create a POST request for missing non mandatory attributes {string}")
    public void Create_a_POST_request_for_missing_non_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/EntityWithNonMandatoryAttributes.json");
        prerequest.remove("STRING_NON_MAN");
        Response = postRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_CREATED);
    }

    @When("Create a PUT request for valid non mandatory attributes {string}")
    public void Create_a_PUT_request_for_valid_non_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        updateValue = "Test"+RandomAlphanumericGenerate(4);
        prerequest.put("STRING_NON_MAN", updateValue);
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_OK);
    }

    @Then("verify valid response for entity with non mandatory attributes {string}")
    public void verify_valid_response_for_entity_with_non_mandatory_attributes(String entityKey) throws Exception {
       VerifyEntityData(Response, entityKey, updateValue);
    }

    @When("Create a PUT request for invalid non mandatory attribute {string}")
    public void Create_a_PUT_request_for_invalid_non_mandatory_attribute(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        prerequest.replace("STRING_NON_MAN", false);
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify put error message for invalid non mandatory attribute {string} and {string}")
    public void verify_put_error_message_for_invalid_non_mandatory_attribute(String errorCode, String errorMessage) throws Exception {
        VerifyErrorMessage(Response, errorCode, errorMessage);
    }

    @When("Create a PUT request missing non mandatory attributes {string}")
    public void Create_a_PUT_request_missing_non_mandatory_attributes(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        prerequest.remove("STRING_NON_MAN");
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_OK);
    }

    @Then("verify valid response missing non mandatory attributes {string} and {string}")
    public void verify_valid_response_missing_non_mandatory_attributes(String EntityName, String entityValue) throws Exception {
        VerifyEntityData(Response, EntityName, entityValue);
    }

    @When("Create a POST request for entity with default values of mandatory and non mandatory attributes {string}")
    public void Create_a_POST_request_for_entity_with_default_values_of_mandatory_and_non_mandatory_attributes(String route) throws Exception {
        Response = postRequest("{}", ApiConstants.Route_master + route, HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify valid response for entity with default values of mandatory and non mandatory attributes {string} and {string}")
    public void verify_valid_response_for_entity_with_default_values_of_mandatory_and_non_mandatory_attributes(String EntityTypeName, String entityName) throws Exception {
        VerifyEntityData(Response,EntityTypeName, entityName);
    }

    @When("Create a PUT request for attributes with default value of entity {string}")
    public void Create_a_PUT_request_for_attributes_with_default_value_of_entity(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/DefaultValueEntity.json");
        updateVal=20;
        prerequest.replace("DEFAULT_MANDATORY_ATTRIBUTE", updateVal);
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_OK);
    }

    @Then("verify valid response for attributes with default value of entity {string}")
    public void verify_valid_response_for_attributes_with_default_value_of_entity(String EntityName) throws Exception {
        VerifyEntityData(Response, EntityName, String.valueOf(updateVal));
    }

    @When("Create a PUT request for integer mandatory attribute with valid value {string}")
    public void Create_a_PUT_request_for_integer_mandatory_attribute_with_valid_value(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        updateVal=20;
        prerequest.replace("INTEGER_MAN", updateVal);
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_OK);
    }

    @Then("verify valid response for integer mandatory attribute with valid value {string}")
    public void verify_valid_response_for_integer_mandatory_attribute_with_valid_value(String EntityName) throws Exception {
        VerifyEntityData(Response, EntityName, String.valueOf(updateVal));
    }

    @When("Create a PUT request for integer mandatory attribute with invalid value {string}")
    public void Create_a_PUT_request_for_integer_mandatory_attribute_with_invalid_value(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/UpdateEntityWithMandatoryAttributes.json");
        updateval=20.45;
        prerequest.replace("INTEGER_MAN", updateval);
        Response = putRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("verify error message for integer mandatory attribute {string} and {string}")
    public void verify_error_message_for_integer_mandatory_attribute(String errorCode, String errorMessage) throws Exception {
        VerifyErrorMessage(Response, errorCode, errorMessage);
    }

    @When("Create a POST request for entity type id value populated under value table {string}")
    public void Create_a_POST_request_for_entity_type_id_value_populated_under_value_table(String route) throws Exception {
        JSONObject prerequest = ReadJsonInput(ResourcePath + "/CreateEntityWithEntityTypeId.json");
        Response = postRequest(prerequest.toString(), ApiConstants.Route_master + route, HttpURLConnection.HTTP_CREATED);
    }
}

