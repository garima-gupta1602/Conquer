package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;

public class CommentStepDefinitions extends DBHelper {

    JSONObject Response,Response1;
    String stringResponse;

    String ResourcePath="/RegressionTests/QueueAction/Comment";



        @Given("Login into OData for Comment")

    public void login_into_odata_for_comment() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into OData for Comment");
        Readprerequest();
    }

    @When("Perform a GET request to get all comments and navigation")

    public void perform_a_GET_request_to_get_all_comments_and_navigation() throws Exception {
        reportInstance.logInfo("When : ", "Perform a Get request to expand Project with filter");
        String stringResponse = ApiConstants.Route_COMMENT+"?$filter="
                + URLEncoderForRequests("ENTITY/Barcode eq 'BEER1'")+
                "&$expand=ENTITY"
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify in the response all the comment and navigation")

    public void verify_in_the_response_all_the_comment_and_navigation() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i<resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String entity = GetattributefromResponse(Response, "ENTITY");
            Response = StringToJSONObject(entity);
            VerifyEntityData(Response, "Barcode", "BEER1");
        }


    }

    @When("Perform a GET request to get all comments made by employee and navigation")

    public void perform_a_GET_request_to_get_all_comments_made_by_employee_and_navigation() throws Exception {
        reportInstance.logInfo("When : ", "Perform a GET request to get all comments made by employee and navigation");
        String stringResponse = ApiConstants.Route_COMMENT+"?$filter="
                + URLEncoderForRequests("ENTITY/Barcode eq 'BEER1'")+
                "&"+URLEncoderForRequests("EMPLOYEE/Barcode eq 'EM2'")+"&$expand=ENTITY,EMPLOYEE"
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify in the response all the comments made by employee and navigation")

    public void verify_in_the_response_all_the_comments_made_by_employee_and_navigation() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i<resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String employee = GetattributefromResponse(Response, "EMPLOYEE");
            Response1 = StringToJSONObject(employee);
            VerifyEntityData(Response1, "Barcode", "EM1");


            String entity = GetattributefromResponse(Response, "ENTITY");
            Response = StringToJSONObject(entity);
            VerifyEntityData(Response, "Barcode", "BEER1");
        }


    }

    @When("Perform a GET request to get all comments and order by comment time and navigation")

    public void perform_a_GET_request_to_get_all_comments_and_order_by_comment_time_and_navigation() throws Exception {
        reportInstance.logInfo("When : ", "Perform a GET request to get all comments and order by comment time and navigation");
        String stringResponse = ApiConstants.Route_COMMENT+"?$filter="
                + URLEncoderForRequests("ENTITY/Barcode eq 'BEER1'")+
                "&$orderby="+ URLEncoderForRequests("COMMENT_TIME asc")+
               "&$expand="+URLEncoderForRequests("EMPLOYEE")
                ;
        stringResponse = GetRequest(stringResponse,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify in the response all the comments and order by comment time and navigation")

    public void verify_in_the_response_all_the_comments_and_order_by_comment_time_and_navigation() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i<resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String employee = GetattributefromResponse(Response, "EMPLOYEE");
            Response = StringToJSONObject(employee);
            VerifyEntityData(Response, "Barcode", "EM1");


        }
    }

    @When("Perform a POST request to insert new comment")

    public void perform_a_POST_request_to_insert_new_comment() throws Exception {
        reportInstance.logInfo("","Perform a POST request to insert new comment");
        JSONObject Request= ReadJsonInput(ResourcePath+"/Comment.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_COMMENT,UpdateRequestHeader("Content-Type","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify in the response the new comment created")

    public void verify_in_the_response_the_new_comment_created() throws IOException {
        reportInstance.logInfo("","Verify in the response the new commet created");
        VerifyEntityData(Response, "COMMENT_TEXT", "This experiment was originally published by Cooper.");

    }

}

