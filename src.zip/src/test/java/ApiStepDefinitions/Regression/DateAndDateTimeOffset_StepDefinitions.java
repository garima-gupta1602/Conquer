package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;


public class DateAndDateTimeOffset_StepDefinitions extends DBHelper {
    JSONObject Response;
    String strResponse;
    Boolean prerequisite;
    String offsetdate;
    String ResourcePath="/RegressionTests/QueueAction/DateAndDateTimeOffset";

    SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
    Date date;

    @Given("Login into ODATA for DateAndDateTimeOffset")
    public void Login_into_ODATA_for_DateAndDateTimeOffset() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request for DateAndDateTimeOffset greater {string} and {string} and {string}")
    public void Create_a_GET_request_for_DateAndDateTimeOffset_greater(String pathparam, String filterparam, String queryparam_date) throws Exception {
        filterparam = filterparam + queryparam_date;
        strResponse = GetRequest(ApiConstants.Route_master + pathparam, filterparam, HttpURLConnection.HTTP_OK);
    }

    @Then("verify date greater than {string}")
    public void verify_date_greater_than(String expecteddate) throws Exception {
        date = sdformat.parse(expecteddate);
        Response = StringToJSONObject(strResponse);
        JSONArray array = JSONObjectToJsonArray(Response, "value");
        if (array.size() > 0) {
            for (int i = 0; i < array.size(); i++) {
                JSONObject currentResponse = (JSONObject) array.get(i);
                String strdate = GetattributefromResponse(currentResponse, "DATE_ORDERED");
                Date date_ordered = sdformat.parse(strdate);
                if (date_ordered.after(date)) {
                    reportInstance.logPass("greater as expected", String.valueOf(date_ordered));
                }
            }
        }
    }

    @When("Create a GET request for DateAndDateTimeOffset equals {string} and {string} and {string}")
    public void Create_a_GET_request_for_DateAndDateTimeOffset_equals(String pathparam, String filterparam, String queryparam_date) throws Exception {
        filterparam = filterparam + queryparam_date;
        strResponse = GetRequest(ApiConstants.Route_master + pathparam, filterparam, HttpURLConnection.HTTP_OK);
    }

    @Then("verify date equals to {string}")
    public void verify_date_equals_to(String expecteddate) throws Exception {
        date = sdformat.parse(expecteddate);
        Response = StringToJSONObject(strResponse);
        JSONArray array = JSONObjectToJsonArray(Response, "value");
        if (array.size() > 0) {
            for (int i = 0; i < array.size(); i++) {
                JSONObject currentResponse = (JSONObject) array.get(i);
                String strdate = GetattributefromResponse(currentResponse, "DATE_ORDERED");
                Date date_ordered = sdformat.parse(strdate);
                if (date_ordered.equals(date)) {
                    reportInstance.logPass("greater as expected", String.valueOf(date_ordered));
                }
            }
        }
    }

    @When("Create a GET request for DateAndDateTimeOffset lesser {string} and {string} and {string}")
    public void Create_a_GET_request_for_DateAndDateTimeOffset_lesser(String pathparam, String filterparam, String queryparam_date) throws Exception {
        filterparam = filterparam + queryparam_date;
        strResponse = GetRequest(ApiConstants.Route_master + pathparam, filterparam, HttpURLConnection.HTTP_OK);
    }

    @Then("verify date lesser than {string}")
    public void verify_date_lesser_than(String expecteddate) throws Exception{
        date = sdformat.parse(expecteddate);
        Response = StringToJSONObject(strResponse);
        JSONArray array = JSONObjectToJsonArray(Response, "value");
        if (array.size() > 0) {
            for (int i = 0; i < array.size(); i++) {
                JSONObject currentResponse = (JSONObject) array.get(i);
                String strdate = GetattributefromResponse(currentResponse, "DATE_ORDERED");
                Date date_ordered = sdformat.parse(strdate);
                if (date_ordered.before(date)) {
                    reportInstance.logPass("greater as expected", String.valueOf(date_ordered));
                }
            }
        }
    }

    @When("Create a POST request for Create entity with DateTimeOffset {string}")
    public void Create_a_POST_request_for_Create_entity_with_DateTimeOffset(String pathparam) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateEntityWithDateTimeOffset.json");
        reportInstance.logInfo("STEPS : ",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify entity name {string}")
    public void verify_entity_name(String expectedEntityTypeName) throws IOException {
        String entityTypeName= GetattributefromResponse(Response, "EntityTypeName");
        Assert.assertEquals(expectedEntityTypeName, entityTypeName);
    }

    @When("Create a PUT request for Update entity with DateTimeOffset {string}")
    public void Create_a_PUT_request_for_Update_entity_with_DateTimeOffset(String pathparam) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/UpdateEntityWithDateTimeOffset.json");
        reportInstance.logInfo("STEPS : ",Request.toString());
        Response = putRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request for Create an entity with Date type attribute {string}")
    public void Create_a_POST_request_for_Create_entity_with_Date_type_attribute(String pathparam) throws Exception
    {
        String RequestUnescapedName="Test"+RandomAlphanumericGenerate(14);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending request for name attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateAnEntityWithDateTypeAttribute.json");
        Request.put("Name",RequestUnescapedName);
        offsetdate= (String) Request.get("DATETIMEOFFSET_HANDLING");
        Response = postRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify date type attribute for Create an entity with Date type attribute")
    public void verify_date_type_attribute_for_Create_an_entity_with_Date_type_attribute() throws IOException {
        VerifyEntityData(Response, "DATETIMEOFFSET_HANDLING", offsetdate);
    }

    @When("Create a PUT request for Update an entity with Date type attribute {string}")
    public void Create_a_PUT_request_for_Update_entity_with_Date_type_attribute(String pathparam) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/UpdateAnEntityWithDateTypeAttribute.json");
        offsetdate= (String) Request.get("DATETIMEOFFSET_HANDLING");
        Response = putRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_OK);
    }

    @Then("verify date type attribute for Update an entity with Date type attribute")
    public void verify_date_type_attribute_for_Update_entity_with_Date_type_attribute() throws IOException {
        VerifyEntityData(Response, "DATETIMEOFFSET_HANDLING", offsetdate);
    }

    @When("Create a POST request for Create an entity with Date type attribute as Null {string}")
    public void Create_a_POST_request_for_Create_an_entity_with_Date_type_attribute_as_Null(String pathparam) throws Exception
    {
        String RequestUnescapedName="Sample for test creating entity with Date type attribute as Null"+RandomAlphanumericGenerate(14);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending request for name attribute");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateAnEntityWithDateTypeAttributeAsNull.json");
        Request.put("Name",RequestUnescapedName);
        Response = postRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_CREATED);
    }

    @Then("verify date type attribute for Create an entity with Date type attribute as Null")
    public void verify_date_type_attribute_for_Create_an_entity_with_Date_type_attribute_as_Null() throws IOException {
        GetattributefromResponse(Response, "DATETIMEOFFSET_HANDLING");
    }

    @When("Create a PUT request to Update an entity with Date type attribute as Null {string}")
    public void Create_a_PUT_request_to_Update_entity_with_Date_type_attribute_as_Null(String pathparam) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/UpdateAnEntityWithDateTypeAttributeAsNull.json");
        Response = putRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_OK);
    }

    @Then("verify date type attribute for Update an entity with Date type attribute as Null")
    public void verify_date_type_attribute_for_Update_entity_with_Date_type_attribute_as_Null() throws IOException {
        GetattributefromResponse(Response, "DATETIMEOFFSET_HANDLING");
    }

    @When("Create a PUT request to make modified event updated {string}")
    public void Create_a_PUT_request_to_make_modified_event_updated(String pathparam) throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/UpdateAnEntityWithDateTypeAttributeAsNull.json");
        Request.put("Active", false);
        Response = putRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_OK);
        Request.put("Active", true);
        Response = putRequest(Request.toString(), ApiConstants.Route_master+pathparam, HttpURLConnection.HTTP_OK);
    }

    @Then("verify Get modified date event")
    public void verify_Get_modified_date_event() throws IOException {
        GetattributefromResponse(Response, "Modified");
    }

}
