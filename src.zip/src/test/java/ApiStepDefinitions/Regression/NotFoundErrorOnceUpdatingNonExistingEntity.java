package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class NotFoundErrorOnceUpdatingNonExistingEntity extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String ResourcePath="/RegressionTests/QueueAction/NotFoundErrorOnceUpdatingNonExistingEntity";



    @Given("Login into Odata for not Found Error Once Updating Non Existing Entity")

    public void login_into_odata_for_not_found_error_once_updating_non_existing_entity() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "Login into Odata for not Found Error Once Updating Non Existing Entity");
        Readprerequest();
    }

    @When("Send a PUT request to update non existing entity by PUT request")
    public void send_a_PUT_request_to_update_non_existing_entity_by_put_request() throws Exception {

        reportInstance.logInfo("STEPS : ", "Send a PUT request to update non existing entity by PUT request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateNonExistingEntityByPUTRequest.json");
        Response= putRequest(Request.toString(), ApiConstants.nurse,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_NOT_FOUND);

    }



    @Then("Verify the error message for updated non existing entity by PUT request")

    public void verify_the_error_message_for_updated_non_existing_entity_by_put_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for updated non existing entity by PUT request");
        VerifyErrorMessageWithinDetails(Response,"3001","Error updating entity","2005","Could not find entity by the identifier: NURR44444.");
    }



    @When("Send a PATCH request to update non existing entity by PATCH request")
    public void send_a_patch_request_to_update_non_existing_entity_by_patch_request() throws Exception {

        reportInstance.logInfo("STEPS : ", "Send a PATCH request to update non existing entity by PATCH request");
        JSONObject Request= ReadJsonInput(ResourcePath+"/UpdateNonExistingEntityByPatchRequest.json");
        Response= patchRequest(Request.toString(), ApiConstants.nurse,UpdateRequestHeader("if-match","*"), HttpURLConnection.HTTP_NOT_FOUND);

    }

    @Then("Verify the error message for updated non existing entity by PATCH request")

    public void verify_the_error_message_for_updated_non_existing_entity_by_patch_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the error message for updated non existing entity by PUT request");
        VerifyErrorMessageWithinDetails(Response,"3001","Error updating entity","2005","Could not find entity by the identifier: NURR44444.");
    }


}
