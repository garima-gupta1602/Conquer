package ApiStepDefinitions.Regression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.tools.ant.taskdefs.Get;
import org.json.simple.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;

public class Immutable_Properties_StepDefination extends DBHelper {

    HttpURLConnection Conn;
    JSONObject Response,Request;
    HttpURLConnection conn;
    String RequestUnescapedName;

    @Given("^Login into ODATA to modify the properties$")
    public void loginIntoODATAToModifyTheProperties() {
        reportInstance =SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("^Perform PUT request with the value \"([^\"]*)\" to change the description field$")
    public void performPUTRequestWithTheValueToChangeTheDescriptionField(String path) throws Throwable {

        Request=ReadJsonInput("/ImmutableProperty/Put_SampleRequest.json");
        Response=putRequest(Request.toString(), ApiConstants.Route_master+path,HttpURLConnection.HTTP_OK);
    }

    @Then("^Validate the The request should be ignored and description value remains same i,e \"([^\"]*)\" in the response body$")
    public void validateTheTheRequestShouldBeIgnoredAndDescriptionValueRemainsSameIEInTheResponseBody(String Original_Description) {
        VerifyEntityData(Response,"DESCRIPTION",Original_Description);
    }

    @When("Create a POST request to edit the container")
    public void create_a_post_request_to_edit_the_container() throws Exception {
        String txtpath = "src/test/resources/YETI/ImmutableProperty/BatchRequest.txt";
        String body = readEntireText(txtpath);
        Conn = SendRequest(ApiConstants.Route_BatchRequest, body, UpdateRequestHeader("Content-Type", "multipart/mixed;boundary=batch_9a0d6c58-3e67-4650-b483-243e89a85453"), "POST");
    }

    @Then("^verify success response for edit container$")
    public void verifySuccessResponseForEditContainer() throws IOException {
        int responsecode = Conn.getResponseCode();
        ValidateExceptedResponseCode(responsecode, HttpURLConnection.HTTP_OK);
    }

    @When("^Create a POST request to create an entity with the value \"([^\"]*)\"$")
    public void createAPOSTRequestToCreateAnEntityWithTheValue(String pathparm) throws Throwable {
        Request=ReadJsonInput("/ImmutableProperty/Post_CreateEntity.json");
        RequestUnescapedName="Test Name "+RandomAlphanumericGenerate(4);
        Request.put("Name",RequestUnescapedName);
        Response=postRequest(Request.toString(),ApiConstants.Route_master+pathparm,HttpURLConnection.HTTP_CREATED);

    }

    @Then("^Verify the entity is created successfully by verifying its description value \"([^\"]*)\"$")
    public void verifyTheEntityIsCreatedSuccessfullyByVerifyingItsDescriptionValue(String Description) {
        VerifyEntityData(Response,"DESCRIPTION",Description);
    }


    public static String readEntireText(String path) {
        File content = new File(path);
        String fileContent="";
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(content);
            byte[] Value = new byte[(int) content.length()];
            fileInputStream.read(Value);
            fileInputStream.close();
            fileContent = new String(Value, "UTF-8");

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return fileContent;
    }


}
