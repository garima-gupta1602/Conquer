/*
 * Copyright (c) 2020 Thermo Fisher Scientific
 * All rights reserved.
 */


package ApiStepDefinitions;

import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * TODO: Class description
 */
public class AddDeleteAttributeOfSuperType extends DBHelper
{
    /** TODO: Field description */
    JSONObject Response = new JSONObject();
    private SharedAttributes sharedAttributes;

    /** TODO: Field description */
    JSONParser parseJson = new JSONParser();

    public AddDeleteAttributeOfSuperType(SharedAttributes share) throws Exception {
        this.sharedAttributes = share;
        Readprerequest();
        reportInstance = SharedClassApi.getReportInstance();
    }
    private static final String ADD_ATTRIBUTE_REQUEST_BODY = "/adddeletesupertypeattribute/AddAttributeToSuperType.json";
    private static final String DUPLICATED_ATTRIBUTE_RESPONSE_BODY = "/adddeletesupertypeattribute/DuplicatedAttributeResponseBody.json";


    @Given("Preparation for adding an attribute to super type is done")
    public void preparationForAddingAnAttributeToSuperTypeIsDone() throws Exception {
        Readprerequest();
        reportInstance=SharedClassApi.getReportInstance();
    }

    /**
     * TODO: Method description
     *
     * @param attributeName
     * @param attributeDataType
     * @param superTypeName
     * @throws Exception
     */
    @When("Post request to add an attribute with name {string}, data type {string} to the super type {string}")
    public void postTheRequestToAddAnAttributeToAnSuperType(String attributeName, String attributeDataType, String superTypeName) throws Exception
    {
        try
        {
            JSONObject Request = ReadJsonInput(ADD_ATTRIBUTE_REQUEST_BODY);
            sharedAttributes.customAttributes.put("attributeName", attributeName);
            Request.replace("AttributeName", attributeName);
            Request.replace("ENTITY_TYPE@odata.bind", String.format("/ENTITY_TYPE('%s')", superTypeName));
            Request.replace("DATA_TYPE@odatRequesta.bind", String.format("/DATA_TYPE('%s')", attributeDataType));
            Response = postRequest(Request.toString(), ApiConstants.Route_Type_Attribute, HttpURLConnection.HTTP_CREATED);
            reportInstance
            .logPass("STEP - ", String.format("Post the request to add an attribute" + " with name %s and data type %s to the super type %s", attributeName, attributeDataType, superTypeName));
        }
        catch (Exception ex)
        {
            reportInstance
            .logFail("STEP - ", String.format("Post the request to add an attribute" + " with name %s and data type %s to the super type %s", attributeName, attributeDataType, superTypeName));
            Assert.fail();
        }
    }

    /**
     * TODO: Method description
     *
     * @param attributeName
     * @param attributeDataType
     * @param superTypeName
     *
     * @throws IOException
     */
    @When("Post request to add an existent attribute with name {string}, data type {string} to the super type {string}")
    public void postTheRequestToAddAnExistentAttributeWithNameDataTypeToTheSuperType(String attributeName, String attributeDataType, String superTypeName) throws IOException
    {
        try
        {
            reportInstance = SharedClassApi.getReportInstance();
            JSONObject Request = ReadJsonInput(ADD_ATTRIBUTE_REQUEST_BODY);
            Request.replace("AttributeName", attributeName);
            Request.replace("ENTITY_TYPE@odata.bind", String.format("/ENTITY_TYPE('%s')", superTypeName));
            Request.replace("DATA_TYPE@odatRequesta.bind", String.format("/DATA_TYPE('%s')", attributeDataType));
            Response = postRequest(Request.toString(), ApiConstants.Route_Type_Attribute, HttpURLConnection.HTTP_BAD_REQUEST);

            reportInstance
            .logPass("STEP - ", String
            .format("Post the request to add an existent attribute" + " with name %s and data type %s to the super type %s", attributeName, attributeDataType, superTypeName));
        }
        catch (Exception ex)
        {
            reportInstance
            .logFail("STEP - ", String.format("Post the request to add an attribute" + " with name %s and data type %s to the super type %s", attributeName, attributeDataType, superTypeName));
            Assert.fail();
        }
    }

    /**
     * TODO: Method description
     *
     * @param attributeName
     * @param superTypeName
     * @throws Exception
     */
    @Then("Verify the attribute {string} is associated with super type {string} at database level")
    public void verifyTheAttributeIsAssociatedWithSuperTypeAtDatabaseLevel(String attributeName, String superTypeName) throws Exception
    {
        try
        {
            String results = ExecuteQueryToGetExpectedColumn(DbQueries.RETRIEVE_SUPER_TYPE_ATTRIBUTES.replace("{superTypeNameAnchor}", superTypeName).replace("{attributeNameAnchor}", attributeName), "attribute_name");
            if (results.equalsIgnoreCase(attributeName))
            {
                reportInstance.logPass("STEP - ", String.format("Verify the attribute %s is associated with super type %s at database level", attributeName, superTypeName));
            }
            else
            {
                reportInstance.logFail("STEP - ", String.format("Verify the attribute %s is associated with super type %s at database level", attributeName, superTypeName));
                Assert.fail();
            }
        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - ", String.format("Verify the attribute %s is associated with super type %s at database level", attributeName, superTypeName));
            Assert.fail();
        }
    }


    /**
     * TODO: Method description
     *
     * @throws IOException
     */
    @When("GET request to reload Metadata")
    public void getRequestToReloadMetadata() throws IOException
    {
        try
        {
            reportInstance = SharedClassApi.getReportInstance();
            String XMLResponse = GetRequest(ApiConstants.Route_MetaDataOnReload, "Metadata request");
            sharedAttributes.customAttributes.put("metadata", XMLResponse);
            reportInstance.logPass("STEP - ", "Reload Metadata");

        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - ", "Reload Metadata");
            Assert.fail();
        }
    }

    /**
     * TODO: Method description
     *
     * @param attributeName
     * @param entityTypeName
     * @throws IOException
     */
    @Then("Verify attribute {string} associated to entity type {string}, unescaped name is {string}")
    public void verifyAttributeAssociatedToEntityType(String attributeName, String entityTypeName, String unescapedName) throws IOException
    {
        try
        {
            reportInstance=SharedClassApi.getReportInstance();
            String patternString = String.format("<EntityType Name=\"%s\" BaseType=\"pfs\\.\\S+\">(.*)<Annotation Term=\"pfs\\.UnescapedName\"><String>%s<\\/String><\\/Annotation><\\/EntityType>", entityTypeName, unescapedName);
            Pattern pattern = Pattern.compile(patternString);
            String metadata = sharedAttributes.customAttributes.get("metadata").toString();
            Matcher matcher = pattern.matcher(metadata);
            String content = "";
            if(matcher.find()){
                content = matcher.group(1);
            }
            String property = String.format("<Property Name=\"%s\"", SharedClassApi.escapeName(attributeName));
            if (content.contains(property))
            {
                reportInstance.logPass("STEP - ", "Verify that attribute " + attributeName + " associated to entity type " + entityTypeName);
            }
            else
            {
                reportInstance.logFail("STEP - ", "Verify that attribute " + attributeName + " associated to entity type " + entityTypeName);
                Assert.fail("Failed when verifying!");
            }
        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - ", "Verify that attribute " + attributeName + " associated to entity type " + entityTypeName);
            Assert.fail();
        }

    }


    /**
     * TODO: Method description
     *
     * @throws Exception
     */
    @Then("Verify response body is correct in case adding attribute to supertype")
    public void verifyResponseBodyIsCorrectInCaseAddingAttributeToSupertype() throws Exception
    {
        try
        {
            String originalAttributeName = sharedAttributes.customAttributes.get("attributeName").toString();
            String escapedName;
            if (originalAttributeName.matches("^[0-9].*"))
            {
                escapedName = ("_" + originalAttributeName).replace(" ", "_").toUpperCase();
            }
            else
            {
                escapedName = originalAttributeName.replace(" ", "_").toUpperCase();
            }

            if (Response.get("AttributeName").toString().equals(originalAttributeName) && Response.get("EscapedName").toString().equals(escapedName))
            {
                reportInstance.logPass("STEP - ", "Verify that response body is correct" + " in case adding attribute to supertype");
            }
            else
            {
                reportInstance.logFail("STEP - ", "Verify that response body is correct" + " in case adding attribute to supertype");
                throw new AssertionError("Failed at body validation");
            }
        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - ", "Verify that response body is correct" + " in case adding attribute to supertype");
            throw ex;
        }
    }

    /**
     * TODO: Method description
     *
     * @param attribute
     * @param entityType
     * @throws Exception
     */
    @Then("Verify response body in case re-adding existing attribute {string} to entity type {string}")
    public void verifyResponseBodyInCaseReAddingExistingAttributeToEntityType(String attribute, String entityType) throws Exception
    {
        try
        {
            String error = Response.get("error").toString();
            JSONObject errorCodeAndMessage = (JSONObject)parseJson.parse(error);
            JSONObject expectedValue = ReadJsonInput(DUPLICATED_ATTRIBUTE_RESPONSE_BODY);
            JSONObject expectedError = (JSONObject) expectedValue.get("error");
            VerifyEntityData(errorCodeAndMessage, "code", expectedError.get("code").toString());
            VerifyEntityData(errorCodeAndMessage, "message", expectedError.get("message").toString());
            VerifyEntityData(errorCodeAndMessage, "target", expectedError.get("target").toString()
                    .replace("{attributeNameAnchor}", attribute)
                    .replace("{entityTypeAnchor}", entityType));
        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - ", "Verify response body contains correct" + " error code and  message in case re-adding existing attribute to entity type");
            throw ex;
        }
    }

    @Given("Create new super type with unescaped name {string}")
    public void createNewSuperTypeWithUnescapedName(String unescapedName) throws Exception {
        reportInstance.logInfo("STEPS","Post the request to Create Super Type");
        reportInstance.logInfo("STEPS",unescapedName + " will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput("/CreateSuperType/CreateSuperTypeValidName.json");
        Request.put("UnescapedName", unescapedName);
        reportInstance.logInfo("STEPS",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
    }
}

