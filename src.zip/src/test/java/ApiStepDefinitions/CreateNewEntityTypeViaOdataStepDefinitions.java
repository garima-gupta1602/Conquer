/*
 * Copyright (c) 2020 Thermo Fisher Scientific
 * All rights reserved.
 */


package ApiStepDefinitions;

import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.util.Random;


/**
 * To Create New Enitity Type Via ODATA step definition
 */
public class CreateNewEntityTypeViaOdataStepDefinitions extends DBHelper
{
    /** To Store JSONOBJECT Response */
    JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestUnescapedName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/CreateNewEntityViaOdata";

    /**
     * Preparation for creation of a new entity type via odata
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new entity type via odata")
    public void preparation_for_creation_of_a_new_entity_type_via_odata() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "Preparation of the new entity type");
        Readprerequest();
    }


    /**
     * Post a valid request for a new entity type
     *
     * @param EntityPrefix
     *
     * @throws Exception
     */
    @When("Post a valid request for a new entity type {string}")
    public void post_a_valid_request_for_a_new_entity_type(String EntityPrefix) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestUnescapedName = EntityPrefix + RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS", RequestUnescapedName + " will be sending in the request to create the entity type");

        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateNewEntityType.json");
        Request.put("UnescapedName", RequestUnescapedName);
        reportInstance.logInfo("STEPS", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Entity_Type, HttpURLConnection.HTTP_CREATED);

    }

    /**
     * Verify the creation of the entity type with the unescaped name
     *
     * @throws Exception
     */
    @Then("Verify the creation of the entity type with the unescaped name")
    public void verify_the_creation_of_the_entity_type_with_the_unescaped_name() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyEntityData(Response, "UnescapedName", RequestUnescapedName);
    }

    /**
     * Verify the entity type error with code {string} and message
     *
     * @param Code
     * @param Message
     *
     * @throws Exception
     */
    @Then("Verify the entity type error with code {string} and message as {string}")
    public void verify_the_entity_type_error_with_code_and_message_as(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

    /**
     * Post a request for a new entity type with Unescapedname
     *
     * @param invalidunescapedname
     *
     * @throws Exception
     */
    @When("Post a request for a new entity type with {string}  Unescapedname")
    public void post_a_request_for_a_new_entity_type_with_Unescapedname(String invalidunescapedname) throws Exception
    {
        switch (invalidunescapedname)
        {
            case "digits":
            {
                Random random = new Random();
                RequestUnescapedName = String.valueOf(random.nextInt(1000));
                reportInstance.logInfo("STEPS", RequestUnescapedName + " will be sending in the request to create the entity type");
                break;
            }

            case "null":
            {
                RequestUnescapedName = null;
                break;
            }

            case "duplicate_same_case":
            {
                RequestUnescapedName = ReadExistingGetRequest();
                break;
            }

            case "duplicate_different_case":
            {
                RequestUnescapedName = ReadExistingGetRequest();
                RequestUnescapedName = reverseCase(RequestUnescapedName);
                break;
            }

            default:
            {
                RequestUnescapedName = invalidunescapedname;
                reportInstance.logInfo("STEPS", RequestUnescapedName + " will be sending in the request to create the entity type");
            }
        }

        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateNewEntityType.json");
        Request.put("UnescapedName", RequestUnescapedName);
        reportInstance.logInfo("STEPS", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Entity_Type, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    /**
     * Post a valid request for a new entity type with min length
     *
     * @throws Exception
     */
    @When("Post a valid request for a new entity type with min length")
    public void post_a_valid_request_for_a_new_entity_type_with_min_length() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        Random r = new Random();
        char c = (char)(r.nextInt(26) + 'a');
        char a = (char)(r.nextInt(26) + 'a');
        RequestUnescapedName = String.valueOf(c) + String.valueOf(a);
        reportInstance.logInfo("RequestUnescapedName for min char ", RequestUnescapedName);

        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateNewEntityType.json");
        Request.put("UnescapedName", RequestUnescapedName);
        Response = postRequest(Request.toString(), ApiConstants.Route_Entity_Type, HttpURLConnection.HTTP_CREATED);
    }

    /**
     * Post a request with with multiple invalid values of SuperTypeId, Prefix, DefaultLocationId for entity type
     *
     * @throws Exception
     */
    @When("Post a request with with multiple invalid values of SuperTypeId, Prefix, DefaultLocationId for entity type")
    public void post_a_request_with_with_multiple_invalid_values_of_SuperTypeId_Prefix_DefaultLocationId_for_entity_type() throws Exception
    {
        reportInstance.logInfo("STEPS", RequestUnescapedName + " will be sending in the request to create the entity type");

        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateNewEntityType.json");
        Request.put("SuperTypeId", 0);
        Request.put("Prefix", "0");
        Request.put("DefaultLocationId", 0);
        reportInstance.logInfo("STEPS", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Entity_Type, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    /**
     * Read Existing GET Request
     *
     * @return
     *
     * @throws Exception
     */
    public String ReadExistingGetRequest() throws Exception
    {
        String UnescapedName = "";
        try
        {
            String ResponseOfGet = GetRequest(ApiConstants.Route_Entity_Type, "");
            JSONObject GETresponse = StringToJSONObject(ResponseOfGet);
            JSONArray jsarray = JSONObjectToJsonArray(GETresponse, "value");
            GETresponse = (JSONObject)jsarray.get(0);
            UnescapedName = GetattributefromResponse(GETresponse, "UnescapedName");
        }
        catch (Exception e)
        {
            reportInstance.logFail("Read Existing Get Request ", e.getMessage());

            throw e;
        }
        return UnescapedName;
    }

    /**
     * To Reverse the case of the given String
     *
     * @param text
     *
     * @return
     */
    public static String reverseCase(String text)
    {
        char[] chars = text.toCharArray();
        for (int i = 0; i < chars.length; i++)
        {
            char c = chars[i];
            if (Character.isUpperCase(c))
            {
                chars[i] = Character.toLowerCase(c);
            }
            else if (Character.isLowerCase(c))
            {
                chars[i] = Character.toUpperCase(c);
            }
        }
        return new String(chars);
    }

}

