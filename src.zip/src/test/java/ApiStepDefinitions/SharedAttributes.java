package ApiStepDefinitions;

import com.reports.Reports;
import java.net.HttpURLConnection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class SharedAttributes {
    ResultSet dbResult;
    HttpURLConnection connection;
    Map<String,Object> customAttributes = new HashMap<>();
}
