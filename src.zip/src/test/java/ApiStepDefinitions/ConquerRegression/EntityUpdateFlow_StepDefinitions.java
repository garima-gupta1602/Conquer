package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.common.Utils;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.*;

public class EntityUpdateFlow_StepDefinitions extends DBHelper {

    JSONObject Response;
    HttpURLConnection conn;
    JSONObject Request;
    String ResourcePath = "/Entity_Update_Flow";
    String  locationIdForUpdate, projectIdForUpdate,entityIdForUpdate;;
    static String ResponseEntityId,ResponseBarcode,jsonEntityTypeName,updatedEntityName,entityNameBeforeUpdate,duplicateEntityName,dbEntityId,dbLockedEntityId;
    static String dbBarcodeParam, projectBarcode,addedAssociation,addAssociatedBarcode;
    String entityTypeName;
    String metaDataResponse;
    String ciBrand,ciColor,ciOptionalRemark,ciTier,ciType;
    static boolean updatedActiveFlag;
    String putOdataMediaReadLink,putJsonBarcode;
    static Set<String> navigationUniqueArr = new TreeSet<String>() ;
    static Set<String> projectIdArr = new TreeSet<String>() ;
    static ArrayList<String> reqBarcodeArr = new ArrayList<>() ;
    static String dbEntityTypeId1,dbEntityTypeId2,dbBarcode1,dbBarcode2;

    @Given("Read the request for entity update flow")
    public void Read_the_request_for_entity_update_flow() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }
    @When("Send the Post Request for entity creation")
    public void  send_the_post_request_for_entity_creation() throws Exception {
        duplicateEntityName = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityIDWithOrderBy, "entity_name");
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
        jsonEntityTypeName =  Request.get("EntityTypeName").toString();
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName, HttpURLConnection.HTTP_CREATED);
        ResponseEntityId = GetattributefromResponse(Response,"Id");
        ResponseBarcode = GetattributefromResponse(Response,"Barcode");
    }
    @When("Send the PUT Request for update location")
    public void send_the_put_request_for_update_location() throws Exception {
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");

        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_Location_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;

        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",ResponseBarcode);
        putRequestJson.put("Barcode",ResponseBarcode);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        String locationOdataBind =putRequestJson.get("LOCATION@odata.bind").toString();
        String jsonBarcode = locationOdataBind.substring(locationOdataBind.indexOf('(')+2,locationOdataBind.indexOf(')')-1);
        locationIdForUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(jsonBarcode),"location_id");
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the {string} response in database entity and entity_association table")
    public void validate_the_response_in_database_entity_and_entity_association_table(String param) throws Exception {
        String locationIdAfterUpdate,projectIdAfterUpdate,activeFlgAfterUpdate,entityNameAfterUpdate;
        switch(param.toUpperCase()) {
            case ("LOCATION"):
                locationIdAfterUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "location_id");
                if (locationIdForUpdate.equals(locationIdAfterUpdate))
                    reportInstance.logPass(locationIdForUpdate + " is updated in Database entity table", "Entity got updated with location id");
                else
                    reportInstance.logFail(locationIdForUpdate + " is not updated in Database entity table", "Entity not get updated with location id");
                break;
            case ("PROJECT"):
                projectIdAfterUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "project_ids");
                if (projectIdAfterUpdate.contains(projectIdForUpdate))
                    reportInstance.logPass(projectIdForUpdate + " is updated in Database entity table", "Entity got updated with project id");
                else
                    reportInstance.logFail(projectIdForUpdate + " is not updated in Database entity table", "Entity not get updated with project id");
                break;

            case ("ACTIVE"):
                activeFlgAfterUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "active");
                if ((activeFlgAfterUpdate.equals("0") && (!updatedActiveFlag))||(activeFlgAfterUpdate.equals("1") && (!updatedActiveFlag)))
                    reportInstance.logPass(activeFlgAfterUpdate + " is updated in Database entity table", "Entity got updated with project id");
                else
                    reportInstance.logFail(activeFlgAfterUpdate + " is not updated in Database entity table", "Entity not get updated with project id");
                break;
            case ("ENTITY_NAME"):
                entityNameAfterUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "entity_name");
                if (entityNameAfterUpdate.contains(updatedEntityName))
                    reportInstance.logPass(entityNameAfterUpdate + " is updated in Database entity table", "Entity got updated with entity name");
                else
                    reportInstance.logFail(entityNameAfterUpdate + " is not updated in Database entity table", "Entity not get updated with entity name");
                break;
            case ("DUPLICATE_NAVIGATION"):
                int projectMatchCnt = 0;
                String[] projects;
                projectIdAfterUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "project_ids");
                projects = projectIdAfterUpdate.split(",");
                Arrays.sort(projects);
                for(String projectUpdated:navigationUniqueArr){
                   for(int i = 0 ;i<projects.length;i++) {
                       if (projects[i].equals(projectUpdated))
                           projectMatchCnt = projectMatchCnt+1;
                   }
                }
                   if(projectMatchCnt == navigationUniqueArr.size())
                        reportInstance.logPass(navigationUniqueArr + " is updated in Database entity table", "Entity got updated with project id");
                   else
                        reportInstance.logFail(navigationUniqueArr + " is not updated in Database entity table", "Entity not get updated with project id");
                  break;
            case ("MULTI_SELECT_PROJECT"):
                int projectUpdatedCnt = 0;
                String[] projectIDs;
                projectIdAfterUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "project_ids");
                projectIDs = projectIdAfterUpdate.split(",");
                Arrays.sort(projectIDs);
                for(String projectUpdated:projectIdArr){
                    for(int i = 0 ;i<projectIDs.length;i++) {
                        if (projectIDs[i].equals(projectUpdated))
                            projectUpdatedCnt = projectUpdatedCnt+1;
                    }
                }
                if(projectUpdatedCnt == projectIdArr.size())
                    reportInstance.logPass(projectIdArr + " is updated in Database entity table", "Entity got updated with project id");
                else
                    reportInstance.logFail(projectIdArr + " is not updated in Database entity table", "Entity not get updated with project id");
                break;
        }
        HashMap results = ExecuteQuery(DbQueries.SelectEntityAssociation + querySearchFormat(ResponseEntityId));
        if (results.size() >= 1)
            reportInstance.logPass(ResponseEntityId, " is created in entity_association table in db");
        else
            reportInstance.logFail(ResponseEntityId, " is not created in entity_association table in db");

    }
    @When("Send the PUT Request for update project")
    public void send_the_put_request_for_update_project() throws Exception {
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");

        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_Project_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;

        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",ResponseBarcode);
        putRequestJson.put("Barcode",ResponseBarcode);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        String projectOdataBind =putRequestJson.get("PROJECT@odata.bind").toString();
        String jsonBarcode = projectOdataBind.substring(projectOdataBind.indexOf('(')+2,projectOdataBind.indexOf(')')-1);
        projectIdForUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(jsonBarcode),"entity_id");
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_OK);
    }
    @When("Send the PUT Request for update active status")
    public void send_the_put_request_for_update_active_status() throws Exception {
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        String dbActiveFlagBeforeUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId),"active");
        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");
        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_ActiveFlag_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;
        if(dbActiveFlagBeforeUpdate.equals("0"))
            updatedActiveFlag = true;
        else
            updatedActiveFlag = false;
        putRequestJson.put("Active",updatedActiveFlag);
        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",ResponseBarcode);
        putRequestJson.put("Barcode",ResponseBarcode);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        entityIdForUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(ResponseBarcode),"entity_id");
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_OK);
     }

    @When("Send the PUT Request for update entity name")
    public void send_the_put_request_for_update_entity_name() throws Exception {
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        updatedEntityName = "Test "+ RandomAlphanumericGenerate(6);
        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");
        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_EntityName_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;
        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",updatedEntityName);
        putRequestJson.put("Barcode",ResponseBarcode);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        entityNameBeforeUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(ResponseBarcode),"entity_name");
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_OK);
    }

    @When("Send the PUT Request for Duplicate navigation property for project")
    public void send_the_put_request_for_duplicate_navigation_property_for_project() throws Exception {
        String jsonBarcode,projectIdBeforeUpdate;
        String[] projectIdBeforeUpdateArr;
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        projectIdBeforeUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "project_ids");

        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");

        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Post_DuplicateNavigation_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;

        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",ResponseBarcode);
        putRequestJson.put("Barcode",ResponseBarcode);

        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        String projectOdataBind =putRequestJson.get("PROJECT@odata.bind").toString();
        String[] navigationArr = projectOdataBind.split(",");
        for(int i=0;i<navigationArr.length;i++){
            jsonBarcode = navigationArr[i].substring(navigationArr[i].indexOf('(')+2,navigationArr[i].indexOf(')')-1);
            projectIdForUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(jsonBarcode),"entity_id");
            navigationUniqueArr.add(projectIdForUpdate);
        }
        if(projectIdBeforeUpdate.contains(",")){
            projectIdBeforeUpdateArr = projectIdBeforeUpdate.split(",");
            for(int i=0 ; i<projectIdBeforeUpdateArr.length;i++)
            navigationUniqueArr.add(projectIdBeforeUpdateArr[i]);
        }else
            navigationUniqueArr.add(projectIdBeforeUpdate);
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_OK);
    }

    @When("Send the PUT Request for Unique name")
    public void send_the_put_request_for_unique_name() throws Exception {
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");
        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_UniqueEntityName_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;
        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",duplicateEntityName);
        putRequestJson.put("Barcode",ResponseBarcode);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify response of {string} with error code {string} and message as {string} for entity update")
    public void verify_response_with_error_code_and_message_as_for_entity_update(String validateFor, String code, String message) throws Exception
    {
        if(validateFor.equalsIgnoreCase("Unique Name"))
           message = message.replace(message.split(" ")[0],duplicateEntityName);
        if(validateFor.equalsIgnoreCase("entity locked"))
            message = message.replace(message.split(": ")[1],dbLockedEntityId);
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_UPDATING_ENTITY, ApiConstants.ERROR_MESSAGE_UPDATING_ENTITY,code,message);
    }

    @When("Send the PUT Request for update attribute values")
    public void send_the_put_request_for_update_attribute_values() throws Exception {
        String randamVal = RandomAlphanumericGenerate(2);
        String dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIdFromEntityForBeer, "Barcode");
        dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIdFromEntityForBeer, "entity_id");
        String dbEntityName = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIdFromEntityForBeer, "entity_name");
        String dbSequence = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIdFromEntityForBeer, "seq");
        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_UniqueAttributeValue_ValidRequest.json");
        putRequestJson.put("Sequence",Integer.parseInt(dbSequence));
        putRequestJson.put("Id",Integer.parseInt(dbEntityId));
        putRequestJson.put("Name",dbEntityName);
        putRequestJson.put("Barcode",dbBarcode);
        ciBrand = "Sarges"+randamVal;
        ciColor = "Dark"+randamVal;
        ciOptionalRemark = "Bold"+randamVal;
        ciTier = "Premium1"+randamVal;
        ciType = "Lager"+randamVal;
        putRequestJson.put("CI_BRAND",ciBrand);
        putRequestJson.put("CI_COLOR",ciColor);
        putRequestJson.put("CI_OPTIONAL_REMARK",ciOptionalRemark);
        putRequestJson.put("CI_TIER",ciTier);
        putRequestJson.put("CI_TYPE",ciType);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_Beer.concat("('"+dbBarcode+"')"), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response in database value table")
    public void validate_the_response_in_database_value_table() throws Exception {
        String dbCIBrand_EntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveAttributeData + querySearchFormat(ciBrand), "entity_id");
        String dbCIColor_EntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveAttributeData + querySearchFormat(ciColor), "entity_id");
        String dbCIOptionalRemark_EntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveAttributeData + querySearchFormat(ciOptionalRemark), "entity_id");
        String dbCITier_EntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveAttributeData + querySearchFormat(ciTier), "entity_id");
        String dbCIType_EntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveAttributeData + querySearchFormat(ciType), "entity_id");
        if (dbCIBrand_EntityID.equals(dbEntityId)&&dbCIColor_EntityID.equals(dbEntityId)&&dbCIOptionalRemark_EntityID.equals(dbEntityId)&&dbCITier_EntityID.equals(dbEntityId)&&dbCIType_EntityID.equals(dbEntityId))
            reportInstance.logPass("Value attributes are updated in Database value table : CI_BRAND , CI_COLOR, CI_TIER, CI_TYPE, CI_OPTIONAL_REMARK","Attributes got updated in value table");
        else
            reportInstance.logFail("Value attributes are not updated in Database value table", "Attributes are not get updated with in Value table");

    }

    @When("Send the Patch Request for {string} with {string} entity type")
    public void send_the_patch_request_for_condition_with_entity_type(String param,String api) throws Exception {
         String dbEntityTypeId="",jsonReqBody = null;
        dbBarcodeParam ="";
         if(param.equalsIgnoreCase("location not null") && api.equalsIgnoreCase("Nurse")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat("NURSE"), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"LOCATION@odata.bind\": null}";
            }
         if(param.equalsIgnoreCase("mandatory attribute value") && api.equalsIgnoreCase("ATTRIBUTE_TEST")){
             dbBarcodeParam = "ATTT1";
             jsonReqBody = " { \"FLOAT_MAN\": null,\"INTEGER_MAN\": 123}";
          }
        if(param.equalsIgnoreCase("invalid value") && api.equalsIgnoreCase("ATTRIBUTE_TEST")){
            dbBarcodeParam = "ATTT1";
            jsonReqBody = " { \"FLOAT_MAN\": 1.3,\"INTEGER_MAN\": 123,\"STRING_MAN\": 123,\"STRING_NON_MAN\":\"String non mandatory\"}";
        }
        if(param.equalsIgnoreCase("Integrity update") && api.equalsIgnoreCase("ANIMAL_INTEGRITY_CHECK")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"INTEGER_INTEGRITY_ATTRIBUTE\": 11,\"STRING_INTEGRITY_ATTRIBUTE\": \"string for INTC-011\",\"TEXT_INTEGRITY_ATTRIBUTE\": \"text for INTC-011\"}";
        }
        if(param.equalsIgnoreCase("Project not null") && api.equalsIgnoreCase("TEXT_FILE")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"PROJECT@odata.bind\": null}";
        }
        if(param.equalsIgnoreCase("Project value as blank") && api.equalsIgnoreCase("TEXT_FILE")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"PROJECT@odata.bind\": []}";
        }
        if(param.equalsIgnoreCase("duplicate navigation property") && api.equalsIgnoreCase("BEER")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"LOCATION@odata.bind\": \"/LOCATION_LIMITED('LC1')\",\"LOCATION@odata.bind\": \"/LOCATION_LIMITED('LC2')\",\"LOCATION@odata.bind\": \"/LOCATION_LIMITED('LC1')\"}";
        }
        if(param.equalsIgnoreCase("non existing Location") && api.equalsIgnoreCase("BEER")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"LOCATION@odata.bind\":\"/LOCATION_LIMITED('LC101')\"}";
        }
        if(param.equalsIgnoreCase("Esignature") && api.equalsIgnoreCase("Entity_Type")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityTypeEsignReq, "entity_type_id");
            api = ExecuteQueryToGetExpectedColumn(DbQueries.selectEntityTypePrefix+ querySearchFormat(dbEntityTypeId), "entity_type_name");
            if (api.trim().contains(" "))
                api =    api.trim().replace(" ","_");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{  \"Name\": \"GelatinABC\"}";
        }
          Response = patchRequest(jsonReqBody, ApiConstants.Route_EntityType_Name+api.toUpperCase().concat("('"+ dbBarcodeParam +"')"),HttpURLConnection.HTTP_BAD_REQUEST);
     }


    @When("Send the PUT Request for entity not locked")
    public void send_the_put_request_for_entity_not_locked() throws Exception {
        String dbEntityLockedBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityLockedId, "Barcode");
        dbLockedEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityLockedId, "entity_id");
        String dbEntityName = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityLockedId, "entity_name");
        String dbSequence = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityLockedId, "seq");
        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_EntityLocked_ValidRequest.json");
        String entityTypeName = putRequestJson.get("EntityTypeName").toString();
        putRequestJson.put("Sequence",Integer.parseInt(dbSequence));
        putRequestJson.put("Id",Integer.parseInt(dbLockedEntityId));
        putRequestJson.put("Name",dbEntityName);
        putRequestJson.put("Barcode",dbEntityLockedBarcode);
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name + entityTypeName.concat("('"+dbEntityLockedBarcode+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Verify patch response with error code {string} and message as {string} for entity update")
    public void verify_patch_response_with_error_code_and_message_as_for_entity_update(String code,String message) throws Exception {
        reportInstance.logInfo("STEPS", "Verify patch response with error code and message for entity update");
        if(message.contains("Annotation")||message.contains("Edm")){
            message = ("\"")+(message)+("\"");
        }
        VerifyErrorMessage(Response, code, message);
    }
    @When("Send the PUT Request for entity with non existing Project")
    public void send_the_put_request_for_entity_with_non_existing_project() throws Exception {
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");
        JSONObject putRequestJson = ReadJsonInput(ResourcePath + "/Put_NonExistingProject_ValidRequest.json");
        putOdataMediaReadLink = putRequestJson.get("@odata.mediaReadLink").toString();
        putJsonBarcode = putOdataMediaReadLink.substring(putOdataMediaReadLink.indexOf("(")+1,putOdataMediaReadLink.indexOf(")"));
        putOdataMediaReadLink= putOdataMediaReadLink.replace(putJsonBarcode,"'"+ResponseBarcode+"'") ;
        putRequestJson.put("@odata.mediaReadLink", putOdataMediaReadLink);
        putRequestJson.put("Id",Integer.parseInt(ResponseEntityId));
        putRequestJson.put("Name",duplicateEntityName);
        putRequestJson.put("Barcode",ResponseBarcode);
        projectBarcode = putRequestJson.get("PROJECT@odata.bind").toString();
        projectBarcode = projectBarcode.substring(projectBarcode.indexOf("(")+1, projectBarcode.indexOf(")"));
        reportInstance.logInfo("STEPS :", putRequestJson.toString());
        Response=putRequest(putRequestJson.toJSONString(), ApiConstants.Route_EntityType_Name +jsonEntityTypeName.concat("('"+ResponseBarcode+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @When("Send the Patch Request for updating {string} with {string} entity type")
    public void send_the_patch_request_for_updating_with_api_for_entity_type(String param,String api) throws Exception {
        String dbEntityTypeId="",jsonReqBody = null;
        dbBarcodeParam ="";
        if(param.equalsIgnoreCase("Trigger Run") && api.equalsIgnoreCase("SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = "{\"CI_TRIGGER_RUNS\":11}";
        }
        if(param.equalsIgnoreCase("Multi Select association") && api.equalsIgnoreCase("ANIMAL_SUBJECT_ACCESS_TEST")){
            dbEntityTypeId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(api.replace("_"," ")), "entity_type_id");
            dbBarcodeParam = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId), "barcode");
            jsonReqBody = GenerateJSONBody("src/test/resources/YETI/Entity_Update_Flow/Patch_ MultiSelectAssociationForProject_ValidRequest.json");
        }
         Response = patchRequest(jsonReqBody, ApiConstants.Route_EntityType_Name+api.toUpperCase().concat("('"+ dbBarcodeParam +"')"),HttpURLConnection.HTTP_OK);

    }
    @Then("Validate the Response Body with database entity table for trigger update")
    public void validate_the_response_body_with_database_entity_table_for_trigger_update() throws Exception {
        long req_ciTriggerRuns = (long)11;
        String response_entityId = GetattributefromResponse(Response,"Id");
        String db_entityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(response_entityId), "entity_id");
        if (response_entityId.equals(db_entityId))
            reportInstance.logPass("Entity id is created in entity table: ", db_entityId);
        else
            reportInstance.logFail("Entity id is not created in entity table: ", db_entityId);
        String res_ciTriggerRuns = GetattributefromResponse(Response,"CI_TRIGGER_RUNS");
        if(req_ciTriggerRuns >= req_ciTriggerRuns) {
            if (req_ciTriggerRuns + 1 == Long.parseLong(res_ciTriggerRuns))
                reportInstance.logPass("Increment Trigger lot is successful Request CI_TRIGGER_RUNS: " + req_ciTriggerRuns + "And Response CI_TRIGGER_RUNS:" + res_ciTriggerRuns, "CI_TRIGGER_RUNS field is incremented by one");
            else
                reportInstance.logFail("Increment Trigger lot is failed Request CI_TRIGGER_RUNS: " + req_ciTriggerRuns + "And Response CI_TRIGGER_RUNS:" + res_ciTriggerRuns, "CI_TRIGGER_RUNS field is not incremented by one");
        }
    }
    @When("Send the patch request for Multi select association property for project")
    public void send_the_patch_request_for_multi_select_association_property_for_project() throws Exception {
        String projectIdBeforeUpdate,jsonReqBody,projectInRequest,projectId;
        String[] projectIdBeforeUpdateArr,projectsInRequest;
        String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        projectIdBeforeUpdate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "project_ids");

        if(ResponseEntityId.equals(dbEntityId))
            reportInstance.logPass(ResponseEntityId  +" is created in Database entity table", "Entity got created");
        else
            reportInstance.logFail(ResponseEntityId  +" is not created in Database entity table","Entity not created");
        jsonReqBody = "{\"PROJECT@odata.bind\": [\"/PROJECT_LIMITED('PJ2')\",\"/PROJECT_LIMITED('PJ3')\",\"/PROJECT_LIMITED('PJ4')\"]}";
        projectsInRequest = jsonReqBody.split(":")[1].split(",");
        for(int i = 0; i<projectsInRequest.length;i++){
            projectInRequest = (projectsInRequest[i].substring(projectsInRequest[i].indexOf('(')+2,projectsInRequest[i].indexOf(")")-1));
            projectId = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(projectInRequest), "entity_id");
            projectIdArr.add(projectId);
        }
        if(projectIdBeforeUpdate.contains(",")){
            projectIdBeforeUpdateArr = projectIdBeforeUpdate.split(",");
            for(int i=0 ; i<projectIdBeforeUpdateArr.length;i++)
                projectIdArr.add(projectIdBeforeUpdateArr[i]);
        }else
            projectIdArr.add(projectIdBeforeUpdate);
        Response = patchRequest(jsonReqBody, ApiConstants.Route_EntityType_Name+jsonEntityTypeName.toUpperCase().concat("('"+ ResponseBarcode +"')"),HttpURLConnection.HTTP_OK);
     }

    @When("Send the Post Request for update association of entity")
    public void  send_the_post_request_for_update_association_of_entity() throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_AssociationCreation_ValidRequest.json");
        String associatedBarcode = Request.get("ASSOCIATION_ACCESS_TEST@odata.bind").toString();
        String[] barcodesInRequest = associatedBarcode.split(",");
        for(int i = 0; i<barcodesInRequest.length;i++){
            String barcodeInRequest = barcodesInRequest[i].substring(barcodesInRequest[i].indexOf('(')+2,barcodesInRequest[i].indexOf(")")-1);
            String associatedEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(barcodeInRequest), "entity_id");
            reqBarcodeArr.add(associatedEntityId);
        }
        updatedEntityName = "TEST"+RandomAlphanumericGenerate(6);
        entityTypeName = "ANIMAL_MULTIPLE_NAVIGATION";
        Request.put("Name",updatedEntityName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_EntityType_Name +entityTypeName, HttpURLConnection.HTTP_CREATED);
        ResponseEntityId = GetattributefromResponse(Response,"Id");
        ResponseBarcode = GetattributefromResponse(Response,"Barcode");
    }

    @When("Send the {string} request to {string} association")
    public void send_the_request_to_association(String requestMethod,String action) throws Exception {
        entityTypeName = "ANIMAL_MULTIPLE_NAVIGATION";
        dbEntityTypeId1 = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(entityTypeName.replace("_"," ")), "entity_type_id");
        dbBarcode1 = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId1), "barcode");
        dbEntityTypeId2 = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(ApiConstants.str_US_ANIMAL_REQUEST_ACCESS_TEST.replace("_"," ")), "entity_type_id");
        dbBarcode2 = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId2), "barcode");
        if(action.equalsIgnoreCase("Delete"))
          conn=SendRequest(ApiConstants.Route_EntityType_Name+entityTypeName+"('"+dbBarcode1+"')"+"/"+ApiConstants.Str_ASSOCIATION_ACCESS_TEST+"/$ref?$id="+ApiConstants.str_US_ANIMAL_REQUEST_ACCESS_TEST+"('"+dbBarcode2+"')","",DefaultRequestHeader(),requestMethod.toUpperCase());
        if(action.equalsIgnoreCase("Add")) {
            Request = ReadJsonInput(ResourcePath + "/Post_AddAssociation_ValidRequest.json");
            String odataId = Request.get("@odata.id").toString();
            addAssociatedBarcode = odataId.substring(odataId.indexOf("(") + 2, odataId.indexOf(")") - 1);
            addedAssociation = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(addAssociatedBarcode), "entity_id");
            conn = SendRequest(ApiConstants.Route_EntityType_Name + entityTypeName + "('" + dbBarcode1 + "')" + "/" + ApiConstants.Str_ASSOCIATION_ACCESS_TEST + "/$ref", Request.toString(), DefaultRequestHeader(), requestMethod.toUpperCase());
        }
        if(action.equalsIgnoreCase("Validate")) {
           String Route= ApiConstants.Route_EntityType_Name  + entityTypeName + "('" + dbBarcode1 + "')?$expand=" +ApiConstants.Str_ASSOCIATION_ACCESS_TEST;
           conn=SendRequest(Route,"",DefaultRequestHeader(),requestMethod.toUpperCase());
           Response=ValidateResponse(conn,true,HttpStatus.SC_OK,false,new HashMap());
       }
    }

    @When("Send the Get request to validate association")
    public void send_the_get_request_to_validate_association() throws Exception {
        entityTypeName = "ANIMAL_MULTIPLE_NAVIGATION";
        dbEntityTypeId1 = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(entityTypeName.replace("_", " ")), "entity_type_id");
        dbBarcode1 = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeId1), "barcode");
        String Route = ApiConstants.Route_EntityType_Name + entityTypeName + "('" + dbBarcode1 + "')?$expand=" + ApiConstants.Str_ASSOCIATION_ACCESS_TEST;
        conn = SendRequest(Route, "", DefaultRequestHeader(), "GET");
        Response = ValidateResponse(conn, true, HttpStatus.SC_OK, false, new HashMap());

    }
    @Then("Validate the Response code {int} for {string}")
    public void Validate_the_response_code_for(int getResponseCode,String action) throws Exception {
        int responseCode=conn.getResponseCode();
        if(responseCode== HttpStatus.SC_NO_CONTENT && (getResponseCode==204))
            reportInstance.logPass("",action +" was successful where response code is 204 No Content");
        else if(responseCode== HttpStatus.SC_OK &&  (getResponseCode==200))
            reportInstance.logPass("",action +" was successful where response code is 200 OK");
        else
            reportInstance.logFail("",action +" was not successful where response code is "+String.valueOf(responseCode));

    }
    @Then("Validate the Response in database record related should be {string} into entity_association table")
    public void Validate_the_Response_in_database_record_related_should_be_into_entity_association_table(String action) throws Exception {
        HashMap results = null; String entityId2,associatedBarCodeId="";
        JSONArray entityResponse ;
        if(action.equalsIgnoreCase("CREATED")) {
            entityId2=reqBarcodeArr.toString().replace("[","").replace("]","");
            results = ExecuteQuery(DbQueries.SelectAssociatedEntityID.replace("entityId2",entityId2).replace("entityId1",ResponseEntityId));
            if (results.size() == reqBarcodeArr.size())
                reportInstance.logPass(entityId2, " is created in entity_association table in db");
            else
                reportInstance.logFail(entityId2, " is not created in entity_association table in db");
        }
        if(action.equalsIgnoreCase("DELETED")) {
            String deletedAssociatedEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode+ querySearchFormat(dbBarcode2), "entity_id");
            results = ExecuteQuery(DbQueries.SelectAssociatedEntityID.replace("entityId2",deletedAssociatedEntityId).replace("entityId1",ResponseEntityId));
            if (results.size() == 0)
                reportInstance.logPass(deletedAssociatedEntityId, " is deleted in entity_association table in db");
            else
                reportInstance.logFail(deletedAssociatedEntityId, " is not deleted in entity_association table in db");
        }
        if(action.equalsIgnoreCase("ADDED")) {
            results = ExecuteQuery(DbQueries.SelectAssociatedEntityID.replace("entityId2",addedAssociation).replace("entityId1",ResponseEntityId));
            if (results.size() >= 1)
                reportInstance.logPass(addAssociatedBarcode, " is added in entity_association table in db");
            else
                reportInstance.logFail(addAssociatedBarcode, " is not added in entity_association table in db");
        }
        if(action.equalsIgnoreCase("PRESENT")) {
            entityResponse = JSONObjectToJsonArray(Response, "ASSOCIATION_ACCESS_TEST");
            for (int i = 0; i < entityResponse.size(); i++) {
                String firstresp = entityResponse.get(i).toString();
                String responseEntityID = StringToJSONObject(firstresp).get("Id").toString();
                String responseBarcode = StringToJSONObject(firstresp).get("Barcode").toString();
                String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(responseEntityID), "entity_id");
                String dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(responseEntityID), "barcode");
                if (dbEntityId.equals(responseEntityID) && dbBarcode.equals(responseBarcode))
                    reportInstance.logPass("entityId: " + dbEntityId + "and dbBarcode: " + dbBarcode + "is present in entity table", " in the db");
                else
                    reportInstance.logFail("entityId: " + dbEntityId + "and dbBarcode: " + dbBarcode + "is not present in entity table", " in the db");

                associatedBarCodeId = associatedBarCodeId+dbEntityId+",";
            }
            associatedBarCodeId= associatedBarCodeId.substring(0,associatedBarCodeId.lastIndexOf(","));
            String query = DbQueries.SelectAssociatedEntityID.replace("entityId2",associatedBarCodeId).replace("entityId1","18161877");//ResponseEntityId);
            results = ExecuteQuery(query);
            if (entityResponse.size() == results.size())
                reportInstance.logPass(associatedBarCodeId, " presents in entity_association table in db");
            else
                reportInstance.logFail(associatedBarCodeId, " is not presents in entity_association table in db");
        }

    }

}
