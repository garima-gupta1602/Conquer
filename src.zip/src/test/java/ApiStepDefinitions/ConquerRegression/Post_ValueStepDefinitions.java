package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Post_ValueStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
    JSONObject Response;
    String ResourcePath = "/Value";
    /** To Store UnEscapedName used in all the requests */
    String RequestName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResponseEntityId = "";
    String dbResponseValueId = "";
    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    String todaysDateStr = sharedFunctions.todaysDate();
    /**
     * Preparation for creation of a new entity     type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new Value_id")
    public void preparation_for_creation_of_a_new_value_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for creation of a new Value_id");
            Readprerequest();
        }
        /**
         * Post a valid request for a creating new entity type "New Event "
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new Value")
        public void post_a_valid_request_for_a_creating_new_value() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestName = "TEST" +  sharedFunctions.getRandomString(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_Value_ValidRequest.json");
            Request.put("Name", RequestName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, HttpURLConnection.HTTP_CREATED);
        }

    @Then("Verify record got inserted in Entity and Value table")
    public void verify_record_got_inserted_in_entity_and_value_table() throws Exception {
        dbResponseValueId = "";
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        dbResponseValueId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectValueId + querySearchFormat(ResponseEntityId), "value_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectValueId + querySearchFormat(ResponseEntityId), "created_on");
        if (!dbResponseValueId.equals("")) {
            reportInstance.logPass("Verify record got inserted in Value table", " is created in the value table");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(dbResponseValueId, " is created in the value table on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the value table on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("value_id", " is not created in the value table");
        }

    @Then("Verify record got inserted in Value_View table")
    public void verify_record_got_inserted_in_value_View_table() throws Exception {
        dbResponseValueId = "";
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        dbResponseValueId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectValueViewId + querySearchFormat(ResponseEntityId), "value_id");
        if (!dbResponseValueId.equals(""))
            reportInstance.logPass("Verify record got inserted in Value_View table", " is created in the db");
       else
            reportInstance.logFail("value_id", " is not created in the value_view table");
    }

    @Then("Verify Value_id should be in long integer datatype format")
    public void Verify_value_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(dbResponseValueId) && sharedFunctions.isIdDisplayedAfterSetSequence(dbResponseValueId,sharedFunctions.maxIntVal))
            reportInstance.logPass("value_id "+dbResponseValueId +" is generated within Long data type range", ":"+ dbResponseValueId);
        else
            reportInstance.logFail("value_id "+dbResponseValueId +"is not generated within Long data type range", ":"+ dbResponseValueId);
    }

    @When ("Post a new request for an value table with null Name field")
    public void Post_a_new_request_for_an_value_table_with_null_Name_field() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_Value_ValidRequest.json");
        Request.put("Name", null);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify error response with error code {string} and message as {string}")
    public void verify_error_post_response_with_error_code_and_message_as(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }
}
