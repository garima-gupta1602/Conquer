package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;


public class Post_AccessLevelStepDefinitions  extends DBHelper {
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Via ODATA step definition and validate the ACCESS_LEVEL API post request
     */

    /**
     * To Store JSONOBJECT Response
     */
    JSONObject Response;


    /**
     * To Store UnEscapedName used in all the requests
     */
    String RequestUnescapedName = "";

    /**
     * To Get the JSON DATA - Resource Path
     */
    String ResourcePath = "/Entity_Type";
    /**
     * Retrive entity_id for validation
     */
    String ResponseUnescapedName = "";
    String record_id = "";
    String created_on_DBDate;
    String todaysDateStr;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    static String maxIntVal ="";

    /**
     * Preparation for creation of a new entity type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new entity")
    public void preparation_for_creation_of_a_new_entity() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "Preparation for creation of a new entity");
        //maxIntVal =  ExecuteQueryToGetExpectedColumn(DbQueries.sequenceQuery ,"setval");
        Readprerequest();
    }


    /**
     * Post a valid request for a creating new entity "New Entity "
     *
     * @param EntityPrefix
     * @throws Exception
     */
    @When("Post a valid request for a creating new entity {string}")
    public void post_a_valid_request_for_a_creating_new_entity(String EntityPrefix) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        // HashMap QueryResult= ExecuteQuery(DbQueries.sequenceQuery);
        RequestUnescapedName = EntityPrefix + " " + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
        Request.put("UnescapedName", RequestUnescapedName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_CREATED);
    }

    /**
     * Verify the entity type with the unescaped name got created
     *
     * @throws Exception
     */
    @Then("Verify the entity with the given name got created")
    public void verify_the_entity_with_the_given_name_got_created() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        VerifyEntityData(Response, "UnescapedName", RequestUnescapedName);
    }

    @Then("Verify unescaped name as entity_name field is created in entity_type table in database with current date")
    public void Verify_unescaped_name_as_entity_name_field_is_created_in_entity_type_table_in_database_with_current_date() throws Exception {
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseUnescapedName = GetattributefromResponse(Response, "UnescapedName");
        String entity_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(ResponseUnescapedName), "entity_type_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(ResponseUnescapedName), "created_on");
        if (!(entity_type_id.equals("")) || (created_on_DBDate != null))
            reportInstance.logPass("entity_type record", " is created in the db on " + created_on_DBDate);
        else
            reportInstance.logFail("entity_type record", " is created in the db on " + created_on_DBDate);
        if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
            if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("Entity record is inserted into Access_Level_Control table and", " is created in the db on " + created_on_DBDate);
            else
                reportInstance.logFail("Entity record", " is created in the db on " + created_on_DBDate);
        }
    }

    @Then("Verify new record get inserted into access_level_control table in database with current date")
    public void Verify_new_record_get_inserted_into_access_level_control_table_in_database_with_current_date() throws Exception {
        record_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnEntityType + querySearchFormat(ResponseUnescapedName), "record_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnEntityType + querySearchFormat(ResponseUnescapedName), "created_on");
        if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
            if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("Access_Level_Control table: record", " is created in the db on " + created_on_DBDate);
            else
                reportInstance.logFail("Access_Level_Control table: record", " is created in the db on " + created_on_DBDate);
        }
    }

    @Then("Verify access_level_id should be in long integer format")
    public void Verify_entity_id_should_be_in_long_integer_format() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(record_id)&&sharedFunctions.isIdDisplayedAfterSetSequence(record_id,sharedFunctions.maxIntVal))
            reportInstance.logPass("record_id is generated within Long integer range", ":" + record_id);
        else
            reportInstance.logFail("record_id is not generated within long integer type range", ":" + record_id);
    }

    @When("Post a request for a new entity type with {string} for column {string}")
    public void Post_a_request_for_a_new_entity_type_with_for_column(String EntityPrefix, String columnId) throws Exception {
        RequestUnescapedName = EntityPrefix + " " + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
        Request.put("UnescapedName", RequestUnescapedName);
        switch (columnId.toLowerCase()) {
            case "supertypeid": {
                Request.put("SuperTypeId", 9223372036854775808F);
                reportInstance.logInfo("STEPS", "supertypeid: 9223372036854775808F will be sending in the request to create the entity type");
                break;
            }

            case "defaultlocationid": {
                Request.put("DefaultLocationId", 9223372036854775808F);
                reportInstance.logInfo("STEPS", "defaultlocationld: 9223372036854775808 will be sending in the request to create the entity type");
                break;
            }
        }
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error with code {string} and message as {string}")
    public void verify_the_error_with_code_and_message_as(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }
}
