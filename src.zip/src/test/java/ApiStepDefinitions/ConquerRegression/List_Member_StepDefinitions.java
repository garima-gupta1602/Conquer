package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.net.HttpURLConnection;
import java.util.HashMap;


public class List_Member_StepDefinitions extends DBHelper {
    JSONObject Response;
    String stringResponse;
    String ResponseFileId;
    String idAttribute;
    HttpURLConnection conn;
    String ResourcePath = "/List_Member";
    String created_on_DBDate;
    String todaysDateStr;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for List_Member")
    public void Read_the_URL_and_Set_Up_the_Headers_for_List_Member() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the GET Request for list_member_id {string}")
    public void Send_the_GET_Request_for_list_member_id(String routeparam) throws Exception {
        stringResponse=GetRequest(ApiConstants.Route_master+routeparam, "");
        Response=StringToJSONObject(stringResponse);
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(stringResponse), "value");
        String resp = value.get(0).toString();
        Response = StringToJSONObject(resp);
        idAttribute = GetattributefromResponse(Response, "Id");
        conn = SendRequest(ApiConstants.Route_master+routeparam+"("+idAttribute+")", "", DefaultRequestHeader(), "GET");
    }

    @Then("Validate the Response code for GET list_member_id")
    public void Validate_the_Response_code_for_GET_list_member_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body for GET list_member table")
    public void Validate_the_Response_Body_for_GET_list_member_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "Id", idAttribute);
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String listmemberId =  ExecuteQueryToGetExpectedColumn(DbQueries.RetreiveListMemberId + querySearchFormat(ResponseFileId), "list_member_id");
        if (listmemberId.equals(ResponseFileId))
            reportInstance.logPass("listmemberId: "+listmemberId+"" , " are found in the db");
        else
            reportInstance.logFail("file record", " is not found in the db");
    }

    @When("Send the POST Request for list_member_id {string}")
    public void Send_the_POST_Request_for_list_member_id(String routeparam) throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_List_Member.json");
        conn = SendRequest(ApiConstants.Route_master+routeparam, String.valueOf(Request), DefaultRequestHeader(), "POST");
    }

    @Then("Validate the Response code for POST list_member_id")
    public void Validate_the_Response_code_for_POST_list_member_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body for POST list_member table")
    public void Validate_the_Response_Body_for_POST_list_member_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(stringResponse), "value");
        String resp = value.get(0).toString();
        Response = StringToJSONObject(resp);
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String listmemberId =  ExecuteQueryToGetExpectedColumn(DbQueries.RetreiveListMemberId + querySearchFormat(ResponseFileId), "list_member_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.RetreiveListMemberId + querySearchFormat(ResponseFileId), "created_on");
        if (!(listmemberId.equals("")) || (created_on_DBDate != null))
            reportInstance.logPass("list_member record", " is created in the db on " + created_on_DBDate);
        else
            reportInstance.logFail("list_member record", " is created in the db on " + created_on_DBDate);
        if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
            if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("list_member  is inserted into list_member  table and", " is created in the db on " + created_on_DBDate);
            else
                reportInstance.logFail("list_member ", " is created in the db on " + created_on_DBDate);
        }
    }

    @Then("Verify list_member_id should be in long integer format")
    public void Verify_list_member_id_should_be_in_long_integer_format() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(ResponseFileId)&&sharedFunctions.isIdDisplayedAfterSetSequence(ResponseFileId,sharedFunctions.maxIntVal))
            reportInstance.logPass("record_id is generated within Long integer range", ":" + ResponseFileId);
        else
            reportInstance.logFail("record_id is not generated within long integer type range", ":" + ResponseFileId);
    }

    @When("Send the DELETE Request for list_member_id {string} and {string}")
    public void Send_the_DELETE_Request_for_list_member_id(String routeparamforadd, String routeparamfordelete) throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_List_Member.json");
        Response = postRequest(String.valueOf(Request),ApiConstants.Route_master+routeparamforadd, HttpURLConnection.HTTP_OK);
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        String resp = value.get(0).toString();
        Response = StringToJSONObject(resp);
        ResponseFileId=GetattributefromResponse(Response, "Id");
        String delRequest="{"+ "\"ListMemberIds\"" + ":" + "["+ResponseFileId+"]"+"}";
        conn = SendRequest(ApiConstants.Route_master+routeparamfordelete, delRequest, DefaultRequestHeader(), "POST");
    }

    @Then("Validate the Response code for DELETE list_member_id")
    public void Validate_the_Response_code_for_DELETE_list_member_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_NO_CONTENT);
    }

    @Then("Validate the Response Body for DELETE list_member table")
    public void Validate_the_Response_Body_for_DELETE_list_member_table()  throws Exception {
        HashMap results =  ExecuteQuery(DbQueries.RetreiveListMemberId + querySearchFormat(ResponseFileId));
        reportInstance.logInfo("", String.valueOf(results.size()));
        if (results.size()==0)
            reportInstance.logPass("list_member record", " is not found in the db");
        else
            reportInstance.logFail("list_member record", " is created in the db on ");
    }
}

