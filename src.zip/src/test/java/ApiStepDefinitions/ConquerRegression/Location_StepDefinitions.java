package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class Location_StepDefinitions extends DBHelper {

    JSONObject EntityType_Response , Location_Response,projectObj  ;
    String metaDataResponse,getLocationResponse;
    Object locationObj;
    String RequestUnescapedName;
    String dbEntityID;
    String ResponseEntityId;
    String dbEntityTypeID;
    String todaysDateStr;
    String created_on_DBDate;
    String seqNumber;
    String dbSeqNumber;
    HttpURLConnection conn;
    String entity_type_id;
    String defaultLocationId;
    String dbDefaultLocationId;
    String ResourcePath = "/Location";
    String dbName;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the POST Request for location")
    public void Read_the_POST_Request() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the POST Request for creating entity")
    public void Send_the_POST_Request_for_creating_entity_with_location() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_EntityType_ValidRequest.json");
        RequestUnescapedName  = "TEST" + SharedFunctionsInTest.getRandomString(4);
        Request.put("UnescapedName",RequestUnescapedName);
        Request.put("Prefix", RequestUnescapedName);
        EntityType_Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_CREATED);
    }


    @When("Send the Get request metadata and validate entity_type in response")
    public void Send_the_get_request_metadata_for_loading_all_new_entities() throws Exception{
        metaDataResponse = GetRequest(ApiConstants.Route_MetaDataOnReload,"Metadata request");
        if (metaDataResponse.contains(RequestUnescapedName))
            reportInstance.logPass(RequestUnescapedName  +"found in response", "Entity got created");
       else
           reportInstance.logFail(RequestUnescapedName  +" not found in response","Entity not created");
    }
    @When("Send the post location request with location")
    public void send_the_post_location_request_with_location() throws Exception {
        Thread.sleep(2000);
        JSONObject location_Request=ReadJsonInput(ResourcePath+"/Post_Location_ValidRequest.json");
        String context = location_Request.get("@odata.context").toString();
        context = context+RequestUnescapedName;
        location_Request.put("@odata.context",context);
        Location_Response = postRequest(location_Request.toString(), ApiConstants.Route_EntityType_Name +RequestUnescapedName, HttpURLConnection.HTTP_CREATED);
    }
    @When("Send the post location request for without location")
    public void send_the_post_location_request_for_without_location() throws Exception {
        Thread.sleep(2000);
        JSONObject location_Request=ReadJsonInput(ResourcePath+"/Post_WithoutLocation_ValidRequest.json");
        String context = location_Request.get("@odata.context").toString();
        context = context+RequestUnescapedName;
        location_Request.put("@odata.context",context);
        Location_Response = postRequest(location_Request.toString(), ApiConstants.Route_EntityType_Name +RequestUnescapedName, HttpURLConnection.HTTP_CREATED);
    }
    @When("Send the post location request for without project")
    public void send_the_post_location_request_for_without_project() throws Exception {
        Thread.sleep(2000);
        JSONObject location_Request=ReadJsonInput(ResourcePath+"/Post_WithoutProject_ValidRequest.json");
        String context = location_Request.get("@odata.context").toString();
        context = context+RequestUnescapedName;
        location_Request.put("@odata.context",context);
        Location_Response = postRequest(location_Request.toString(), ApiConstants.Route_EntityType_Name +RequestUnescapedName, HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify RequestUnescapedName as entity_type_name field is created in entity_type table in database with current date")
    public void Verify_RequestUnescapedName_as_entity_type_name_field_is_created_in_entity_type_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(RequestUnescapedName), "created_on");
        entity_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(RequestUnescapedName), "entity_type_id");
        String sequenceName = "et_" + entity_type_id + "_seq";
        HashMap results = ExecuteQuery(DbQueries.SelectSequenceFromPgClass + querySearchFormat(sequenceName));
        int DbValue = results.size();
        if (DbValue == 1) {
            reportInstance.logPass(sequenceName, " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(sequenceName, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail(sequenceName, " is created in the db on " + created_on_DBDate);
            }
        }else
            reportInstance.logFail(sequenceName, " is not created in the db");
    }
    @Then ("Validate the location details in entity table in DB")
    public void Validate_the_location_details_in_entity_table_in_DB() throws Exception{
        defaultLocationId = GetattributefromResponse(EntityType_Response , "DefaultLocationId");
        dbEntityTypeID = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(RequestUnescapedName), "entity_type_id");
        dbEntityID = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDWithEntityTypeId + querySearchFormat(dbEntityTypeID),"entity_id");
        dbDefaultLocationId =ExecuteQueryToGetExpectedColumn(DbQueries.selectEntityTypePrefix + querySearchFormat(dbEntityTypeID), "default_location_id");
        if(defaultLocationId.equals(dbDefaultLocationId))
            reportInstance.logPass("defaultLocationId: " + defaultLocationId + " is matched with dbDefaultLocationId:"+dbDefaultLocationId, " in the db");
           else
            reportInstance.logFail("defaultLocationId: " + defaultLocationId + " is not matched with dbDefaultLocationId:"+dbDefaultLocationId, " in the db");
        String locationIdFromLocationTbl = ExecuteQueryToGetExpectedColumn(DbQueries.selectLocationId + querySearchFormat(dbDefaultLocationId), "location_id");
        if(!(locationIdFromLocationTbl.equals("")))
            reportInstance.logPass("locationIfFromLocationTbl: " + locationIdFromLocationTbl + " is found in location table", " in the db");
        else
            reportInstance.logFail("locationIfFromLocationTbl: " + locationIdFromLocationTbl + " is not found in location table"+dbDefaultLocationId, " in the db");

    }
    @Then ("Validate the response in entity_association table in DB")
    public void Validate_the_response_in_entity_association_table_in_DB() throws Exception {
       String entityAssociationID =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityAssociation + querySearchFormat(dbEntityID), "entity_association_id");
        if(!entityAssociationID.equals(""))
            reportInstance.logPass("entityAssociationID: " + entityAssociationID + " is present in entity_association table", " in the db");
        else
            reportInstance.logFail("entityAssociationID: " + entityAssociationID + " is not present in entity_association table", " in the db");

    }

    @When("Send the GET Request for {string} with filter {string} and expand {string}")
    public void Send_the_GET_Request_for_with_parameter(String apiStr,String filter,String expand) throws Exception {
        dbEntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityIDWithOrderBy, "entity_id");
        if(apiStr.toUpperCase().equals("ENTITY")){
             filter = filter.replace("responseEntityId",dbEntityID);
             getLocationResponse = GetRequest(ApiConstants.Route_ENTITY_MASTER+"?$filter="+URLEncoderForRequests(filter)+"&$expand="+URLEncoderForRequests(expand),"Metadata request");
             Location_Response = StringToJSONObject(getLocationResponse);
        }
        if(apiStr.toUpperCase().equals("ANIMAL_SUBJECT")){
            getLocationResponse = GetRequest(ApiConstants.Route_ANIMAL_SUBJECT+"?$filter="+URLEncoderForRequests(filter)+"&$expand="+URLEncoderForRequests(expand),"Metadata request");
            Location_Response = StringToJSONObject(getLocationResponse);
        }
   }

    @Then ("Validate the location details and project details in entity table in DB for {string}")
    public void Validate_the_location_details_and_project_details_in_entity_table_in_DB(String api) throws Exception {
        JSONArray entityResponse = JSONObjectToJsonArray(Location_Response, "value");
        for (int i = 0; i < 1; i++) {
            String firstresp = entityResponse.get(i).toString();
            String responseEntityID = StringToJSONObject(firstresp).get("Id").toString();
            String responseBarcode = StringToJSONObject(firstresp).get("Barcode").toString();
            String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(responseEntityID), "entity_id");
            String dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(responseEntityID), "barcode");
            if (dbEntityId.equals(responseEntityID) && dbBarcode.equals(responseBarcode))
                reportInstance.logPass("entityId: " + dbEntityId + "and dbBarcode: " + dbBarcode + "is present in entity table", " in the db");
            else
                reportInstance.logFail("entityId: " + dbEntityId + "and dbBarcode: " + dbBarcode + "is not present in entity table", " in the db");

            locationObj = (JSONObject) StringToJSONObject(firstresp).get("LOCATION");
            String responseLocationID = GetattributefromResponse((JSONObject) locationObj, "Id");
            String dbLocationId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(dbEntityId), "location_id");
            if (responseLocationID.equals(dbLocationId))
                reportInstance.logPass("Location Id: " + responseLocationID + "is present in entity table", " in the db");
            else
                reportInstance.logFail("Location Id: " + responseLocationID + "is not present in entity table", " in the db");

            if (api.equalsIgnoreCase("ENTITY")) {
                String projectResponse = StringToJSONObject(firstresp).get("PROJECT").toString();
                if (projectResponse.equals("[]"))
                    reportInstance.logFail("Project details not present in entity table", " in the db");
                else {
                    String dbProjectId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(dbEntityId), "project_ids");

                    if (projectResponse.contains(dbProjectId))
                        reportInstance.logPass("Project Id: " + dbProjectId + "is present in entity table", " in the db");
                    else
                        reportInstance.logFail("Project Id: " + dbProjectId + "is not present in entity table", " in the db");
                }
            }
        }
    }
      }


