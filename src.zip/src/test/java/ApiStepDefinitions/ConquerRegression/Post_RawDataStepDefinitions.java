package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.io.IOException;

public class Post_RawDataStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestSampleType = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Raw_Data";
   /** Retrive entity_id for validation*/
    String ResponseRecordId = "";

    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new record_id")
    public void preparation_for_creation_of_a_new_record_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "preparation_for_creation_of_a_new_record_id");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         *
         * @param EntityPrefix
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new record_id {string}")
        public void post_a_valid_request_for_a_creating_new_record_id(String EntityPrefix) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestSampleType = EntityPrefix + sharedFunctions.getRandomString(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_RawData_ValidRequest.json");
            Request.put("SAMPLE_TYPE", RequestSampleType);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_RAW_DATA, HttpURLConnection.HTTP_CREATED);
        }

        /**
         * Verify the record_id with the sample_type got created
         *
         * @throws Exception
         */
        @Then("Verify the record with the given sample_type got created")
        public void verify_the_record_with_the_given_sample_type_got_created() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "SAMPLE_TYPE", RequestSampleType);
        }
    @Then("Verify name as sample_type field is created in raw_data table in database with current date and record_id inserted in event table")
    public void verify_name_as_sample_type_field_is_created_in_raw_data_table_in_database_with_current_date_and_record_id_inserted_in_event_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseRecordId = GetattributefromResponse(Response, "Id");
        String sample_type =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnRawData + querySearchFormat(ResponseRecordId), "sample_type");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnRawData + querySearchFormat(ResponseRecordId), "created_on");
        if (sample_type.equals(RequestSampleType)) {
            reportInstance.logPass("Sample_Type", " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(ResponseRecordId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("Entity", " is not created in the db");
        }
    @Then("Verify record_id should be in long integer datatype format")
    public void Verify_record_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(ResponseRecordId) && sharedFunctions.isIdDisplayedAfterSetSequence(ResponseRecordId,sharedFunctions.maxIntVal))
            reportInstance.logPass("record_id "+ResponseRecordId +" is generated within Long data type range", ":"+ ResponseRecordId);
        else
            reportInstance.logFail("record_id "+ResponseRecordId +"is not generated within Long data type range", ":"+ ResponseRecordId);
    }

    @When("Post a new request for raw_data with sample_type field with null value")
    public void post_a_new_request_for_raw_data_with_sample_type_field_with_null_value()  throws Exception {
        // Write code here that turns the phrase above into concrete actions
        RequestSampleType = null;
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_RawData_ValidRequest.json");
        Request.put("SAMPLE_TYPE", null);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_RAW_DATA, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the response with error code {string} and message as {string} for Raw_Data")
    public void Verify_the_response_with_error_code_and_message_as(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

}
