package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.HashMap;


public class Get_TypeAssociationStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    JSONArray jsonArry;
    String ResponseTypeAssociationId = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for Type_Association")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Type_Association() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for Type_Association");
        Readprerequest();
    }
    @When("Create a GET request for type_association_id and send the GET Request")
    public void Create_a_GET_request_for_type_association_id_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for type_association_id and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_TypeAssociation,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseTypeAssociationId = GetattributefromResponse(Response, "Id");
    }

    @Then("Verify response with type_association table")
    public void verify_response_with_type_association_table() throws Exception {
        HashMap results=ExecuteQuery(DbQueries.SelectTypeAssociationID+querySearchFormat(ResponseTypeAssociationId));
        int DbValue=results.size();
        if(DbValue==1)
            reportInstance.logPass("Record found with type_association_id in 'Type_Association' table :", ResponseTypeAssociationId);
       else
            reportInstance.logFail("Record not found with type_association_id in 'Type_Association' table ", "");
        if(sharedFunctions.isDisplayedLongRange(ResponseTypeAssociationId))
            reportInstance.logPass("Type_Association_ID is generated within Long integer range", ":" + ResponseTypeAssociationId);
        else
            reportInstance.logFail("Type_Association_ID is not generated within long integer type range", ":" + ResponseTypeAssociationId);
     }
  }
