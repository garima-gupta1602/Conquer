package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.util.HashMap;


public class Get_SampleLotStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    JSONArray jsonArry;
    String ResponseLotId = "";
    String ResponseEntityId="";
    String metaDataResponse = "";
    String RequestUnescapedName = "";
    String SuperTypeName = "";
    String ResourcePath = "/Super_Type";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    @Given ("Preparation for getting record from entity table")
    @Given("Preparation for getting record from lot table")
    public void preparation_for_getting_record_from_lot_table() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Preparation for getting record from lot table");
        Readprerequest();
    }
    @When("Create a GET request for lot_id and send the GET Request")
    public void Create_a_GET_request_for_lot_id_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for lot_id and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_BeerSampleLot,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseLotId = GetattributefromResponse(Response, "Id");
    }

    @Then("Verify response with lot_id table")
    public void verify_response_with_lot_id_table() throws Exception {
        HashMap results=ExecuteQuery(DbQueries.SelectLotId+querySearchFormat(ResponseLotId));
        int DbValue=results.size();
        if(DbValue==1)
            reportInstance.logPass("Record found with lot_id in 'Lot' table :", ResponseLotId);
        else
            reportInstance.logFail("Record not found with lot_id in 'Lot' table ", "");
    }
    @When("Create a GET request for entity_id and send the GET Request")
    public void Create_a_GET_request_for_entity_id_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for entity_id and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_AssayData+"('TBXP174')/EXPERIMENT_SAMPLES('TBES1385')/ASSAY_DATA/Model.TURBIDITY_ASSAY_DATA","");
        Response = StringToJSONObject(stringResponse);
        ResponseEntityId = GetattributefromResponse(Response, "Id");
    }

    @When("Create a GET request for Filter on Timestamp {string} and send the GET Request")
    public void Create_a_GET_request_Filter_on_Timestamp_and_send_get_request(String filter) throws Exception {
        reportInstance.logInfo("STEPS : ", "Create_a_GET_request_Filter_on_Timestamp_and_send_get_request");
        stringResponse = GetRequest(ApiConstants.Route_AssayData+"?$filter="+URLEncoderForRequests(filter),"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseEntityId = GetattributefromResponse(Response, "Id");
    }

    @When("Create a GET request for metadata and send the GET Request")
    public void Create_a_GET_request_for_metadata_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for metadata and send the GET Request");
        metaDataResponse = GetRequest(ApiConstants.Route_MetaDataOnReload,"Metadata request");
        VerifyMetaDataEntity(metaDataResponse,SuperTypeName);
    }

    @When("Post the valid request for Super Type")
    public void post_the_valid_request_for_super_type() throws Exception
    {
        reportInstance.logInfo("","Post the request to Create Super Type");
        RequestUnescapedName="Test Name "+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_SuperType_ValidRequest.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response,"UnescapedName",RequestUnescapedName);
        SuperTypeName=GetattributefromResponse(Response,"Name");
    }
    @Then("Verify response with entity_id in entity table")
    public void verify_response_with_entity_id_in_entity_table() throws Exception {
        HashMap results=ExecuteQuery(DbQueries.SelectEntityIDFromEntity+querySearchFormat(ResponseEntityId));
        int DbValue=results.size();
        if(DbValue==1)
            reportInstance.logPass("Record found with entity_id in 'entity' table :", ResponseEntityId);
        else
            reportInstance.logFail("Record not found with entity_id in 'entity' table ", "");
    }

    @Then("Verify response with super_type_name in super_type table")
    public void verify_response_with_super_type_name_in_super_type_table() throws Exception {
        HashMap results=ExecuteQuery(DbQueries.SelectSuperTypeName+querySearchFormat(SuperTypeName));
        int DbValue=results.size();
        if(DbValue==1)
            reportInstance.logPass("Record found with superTypeName in 'entity' table  :", SuperTypeName);
        else
            reportInstance.logFail("Record not found with superTypeName in 'entity' table ", "");
    }


}
