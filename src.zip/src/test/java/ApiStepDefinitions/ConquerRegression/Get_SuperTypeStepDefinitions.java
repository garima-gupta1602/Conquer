package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.Random;


public class Get_SuperTypeStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestUnescapedName;
    String ResourcePath = "/Super_Type";
    String super_type_id = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();


    @Given("Read the URL and Set Up the Headers for Super_Type")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Super_Type() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for Super_Type");
        Readprerequest();
    }
    @When("Create a GET request for Super_Type_name and send the GET Request")
    public void Create_a_GET_request_for_Super_Type_name_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for Super_Type_name and send the GET Request");
        RequestUnescapedName = "SUPERTYPE" + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_SuperType_ValidRequest.json");
        Request.put("UnescapedName", RequestUnescapedName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response, "UnescapedName", RequestUnescapedName);
        stringResponse = GetRequest(ApiConstants.Route_SuperType+"('"+RequestUnescapedName+"')","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with super_type table")
    public void verify_response_with_super_type_table() throws Exception {
        super_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeName + querySearchFormat(RequestUnescapedName), "super_type_id");
        if(super_type_id!="")
            reportInstance.logPass("Super type record found with super_type_name: ","'"+RequestUnescapedName+"' and 'super_type_id' displayed as : "+super_type_id);
        else
            reportInstance.logFail("Super type record not found with super_type_name: ","'"+RequestUnescapedName+"'");
    }
    @Then("Verify super_type_id should be in long integer datatype format in super_type table")
    public void Verify_super_type_id_should_be_in_long_integer_datatype_format_in_super_type_table() throws Exception {
            if (sharedFunctions.isDisplayedLongRange(super_type_id))
                reportInstance.logPass("super_type_id is generated within Long integer data type range", ":" + super_type_id);
            else
                reportInstance.logFail("super_type_id is not generated within Long integer data type range", ":" + super_type_id);
        }
}
