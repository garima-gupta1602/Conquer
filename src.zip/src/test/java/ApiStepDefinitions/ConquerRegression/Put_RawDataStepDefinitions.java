package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Put_RawDataStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store RequestBarCode used in all the requests */
    String RequestSampleType = "";


    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Raw_Data";
    String ResponseRecordId = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity association
     *
     * @throws Exception
     */
    @Given("Preparation for updating an raw_data table record")
    public void preparation_for_updating_an_raw_data_table_record() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for updating an raw_data table record");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity association for "BarCode"
         *
         * @throws Exception
         */
        @When("Put a valid request for a updating sample_type in raw_data table")
        public void put_a_valid_request_for_a_updating_sample_type_in_raw_data_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            //Getting record from database raw_data table
            ResponseRecordId = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveRecordIDOfRawData, "record_id");
            RequestSampleType = "TEST" + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Put_RawData_ValidRequest.json");
            Request.put("SAMPLE_TYPE", RequestSampleType);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response=putRequest(Request.toJSONString(), ApiConstants.Route_RAW_DATA.concat("("+ResponseRecordId+")"), HttpURLConnection.HTTP_OK);

        }

    /**
         * Verify the entity type with the unescaped name got created
         *
         * @throws Exception
         */
        @Then("Verify the sample_type got updated in response with raw_data table")
        public void verify_the_sample_type_got_updated_in_response_with_raw_data_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "SAMPLE_TYPE", RequestSampleType);
        }

    @Then("Verify SAMPLE_TYPE as sample_type field is updated in raw_data table with current date")
    public void verify_SAMPLE_TYPE_as_sample_type_field_is_updated_in_raw_data_table_with_current_date() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String dbSampleType =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnRawData + querySearchFormat(ResponseRecordId), "sample_type");
        ResponseRecordId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnRawData+ querySearchFormat(ResponseRecordId), "record_id");
        String updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnRawData + querySearchFormat(ResponseRecordId), "updated_on");
        if (dbSampleType.equals(RequestSampleType)) {
            reportInstance.logPass("Sample_Type", " is created in the db");
            if(!(updated_on_DBDate.equals("")) || (updated_on_DBDate!=null)) {
                if (updated_on_DBDate.split("\\.")[0].contains(todaysDateStr))
                    reportInstance.logPass(ResponseRecordId, " is updated in the db on " + updated_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not updated in the db on " + updated_on_DBDate);
            }else
              reportInstance.logFail("updated_on_DBDate", "field not found in DB due to DB error");
        }else
            reportInstance.logFail("Record", " is not updated in the db");
       }
    @Then("Verify put response with error code {string} and message as {string} for Raw_Data")
    public void verify_put_response_with_error_code_and_message_as_for_Raw_Data(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

    @When("Put a new request for raw_data with sample_type field with null value")
    public void Put_a_request_for_a_new_entity_type_with_for_column_ID() throws Exception {
        ResponseRecordId = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveRecordIDOfRawData, "record_id");
        JSONObject Request = ReadJsonInput(ResourcePath + "/Put_RawData_ValidRequest.json");
        Request.put("SAMPLE_TYPE", null);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response=putRequest(Request.toJSONString(), ApiConstants.Route_RAW_DATA.concat("("+ResponseRecordId+")"), HttpURLConnection.HTTP_BAD_REQUEST);
     }
}
