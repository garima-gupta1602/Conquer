package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class Get_EntityStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestEntityName;
    String ResourcePath = "/Entity";
    String ResponseEntityId = "";
    String ResponseBarcode = "";
    JSONArray jsonArry;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for get request of Entity API")
    public void Read_the_URL_and_Set_Up_the_Headers_for_get_request_of_Entity_API() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for get request of Entity API");
        Readprerequest();
    }
    @When("Create a GET request for newly created record and send the GET Request of Entity API")
    public void Create_a_GET_request_for_newly_created_record_and_send_get_request_of_entity_API() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for newly created record and send the GET Request of Entity API");
        RequestEntityName = "TEST" + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_Entity_ValidRequest.json");
        Request.put("Name", RequestEntityName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Beer, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response, "Name", RequestEntityName);
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        ResponseBarcode = GetattributefromResponse(Response, "Barcode");
        stringResponse = GetRequest(ApiConstants.Route_Beer+"('"+ ResponseBarcode +"')","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify get response with entity table")
    public void verify_get_response_with_entity_table()  throws Exception {
        reportInstance.logInfo("verify_response_with_entity_table","");
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        RequestEntityName = GetattributefromResponse(Response, "Name");
        String dbEntityId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_id");
        String dbEntityName =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");

        if (dbEntityId.equals(ResponseEntityId)&&dbEntityName.equals(RequestEntityName))
            reportInstance.logPass("dbEntityId: "+dbEntityId+ "and RequestEntityName: "+ RequestEntityName, " are found in the db");
        else
            reportInstance.logFail("entity record", " is not found in the db");
    }

    @When("Create a GET request for Entity and send the GET Request")
    public void Create_a_GET_request_for_Entity_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for Entity and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_Beer,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseEntityId = GetattributefromResponse(Response, "Id");
    }

}
