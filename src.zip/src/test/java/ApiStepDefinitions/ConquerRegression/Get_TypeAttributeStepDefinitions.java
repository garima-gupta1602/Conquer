package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.Random;


public class Get_TypeAttributeStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestAttributeName;
    String RequestColumnHeaderName;
    String ResourcePath = "/Type_Attribute";
    String attribute_id = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for Type_Attribute")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Type_Attribute() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for Type_Attribute");
        Readprerequest();
    }
    @When("Create a GET request for type attribute and send the GET Request")
    public void Create_a_GET_request_for_type_attribute_name_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for entity_type_name and send the GET Request");
        RequestAttributeName = "Attribute " + sharedFunctions.getRandomString(4);
        RequestColumnHeaderName = "Test " + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_TypeAttribute_ValidRequest.json");
        Request.put("AttributeName", RequestAttributeName);
        Request.put("ColumnHeader", RequestColumnHeaderName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(),ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response, "AttributeName", RequestAttributeName);
        String ResponseAttributeId = GetattributefromResponse(Response,"Id");
        stringResponse = GetRequest(ApiConstants.Route_TypeAttribute+"("+ResponseAttributeId+")","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with attribute table")
    public void verify_response_with_entity_type_table() throws Exception {
        attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectAttribute + querySearchFormat(RequestAttributeName), "attribute_id");
        if(sharedFunctions.isDisplayedLongRange(attribute_id))
            reportInstance.logPass("Attribute record found with attribute_name: ","'"+RequestAttributeName+"' and 'attribute_id' displayed as : "+attribute_id);
        else
            reportInstance.logFail("Attribute record not found with attribute_name: ","'"+RequestAttributeName+"'");
    }
    @Then("Verify attribute_id should be in long integer datatype format in attribute table")
    public void Verify_entity_type_id_should_be_in_long_integer_datatype_format_in_entity_table() throws Exception {
            if (sharedFunctions.isDisplayedLongRange(attribute_id))
                reportInstance.logPass("attribute_id is generated within Long integer data type range", ":" + attribute_id);
            else
                reportInstance.logFail("attribute_id is not generated within Long integer data type range", ":" + attribute_id);
        }
    @Then("Verify column_header should be present in entity_type_attribute table")
    public void verify_column_header_should_be_present_in_entity_type_attribute_table() throws Exception {
        String ResponseColumnHeader = GetattributefromResponse(Response,"ColumnHeader");
        String DB_Attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeAttribute + querySearchFormat(ResponseColumnHeader), "attribute_id");
        if (DB_Attribute_id.equals(attribute_id))
            reportInstance.logPass("attribute_id is generated in 'entity_type_attribute' table", ":" + attribute_id);
        else
            reportInstance.logFail("attribute_id is not generated in 'entity_type_attribute' table", ":" + attribute_id);

    }
    @Then("Verify attribute_id should be present in super_type_attribute table")
    public void verify_attribute_id_should_be_present_in_super_type_attribute_table() throws Exception{
        String DB_Attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeAttribute + querySearchFormat(attribute_id), "attribute_id");
        if (DB_Attribute_id.equals(attribute_id))
            reportInstance.logPass("attribute_id is generated in 'super_type_attribute' table", ":" + attribute_id);
        else
            reportInstance.logFail("attribute_id is not generated in 'super_type_attribute' table", ":" + attribute_id);
    }
}
