package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Post_ExperimentContainerStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Experiment_Container";
   /** Retrive entity_id for validation*/
    String ResponseExperimentContainerId = "";

    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity     type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new experiment_container_id")
    public void preparation_for_creation_of_a_new_experiment_container_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "preparation_for_creation_of_a_new_experiment_container_id");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         *
          @throws Exception
         */
        @When("Post a valid request for a creating new experiment_container_id")
        public void post_a_valid_request_for_a_creating_new_experiment_container_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_ExperimentContainer_ValidRequest.json");
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentContainer, HttpURLConnection.HTTP_CREATED);
        }

    @Then("Verify the new record inserted in experiment_container table")
    public void verify_the_new_record_inserted_in_experiment_container_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseExperimentContainerId = GetattributefromResponse(Response, "Id");
        String dbExperimentContainerID =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentContainerId + querySearchFormat(ResponseExperimentContainerId), "experiment_container_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentContainerId + querySearchFormat(ResponseExperimentContainerId), "created_on");
        if (ResponseExperimentContainerId.equals(dbExperimentContainerID)) {
            reportInstance.logPass("SelectExperimentContainerId", " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass( "experiment_container_id:"+ResponseExperimentContainerId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("experiment_container_Id", " is not created in the db");
        }

    @Then("Verify experiment_container_id should be in long integer datatype format")
    public void Verify_experiment_container_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(ResponseExperimentContainerId) && sharedFunctions.isIdDisplayedAfterSetSequence(ResponseExperimentContainerId,sharedFunctions.maxIntVal))
            reportInstance.logPass("experiment_container_id :"+ResponseExperimentContainerId +" is generated within Long data type range", ":"+ ResponseExperimentContainerId);
        else
            reportInstance.logFail("experiment_container_id :"+ResponseExperimentContainerId +"is not generated within Long data type range", ":"+ ResponseExperimentContainerId);
    }

}
