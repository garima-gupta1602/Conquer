package ApiStepDefinitions.ConquerRegression;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class SharedFunctionsInTest {
    public static final String maxIntVal ="2147483648";
    public static String todaysDate() {
        Date date = new Date();
        SimpleDateFormat DateFor = new SimpleDateFormat("yyyy-MM-dd");
        String stringDate = DateFor.format(date);
        return stringDate;
    }
    public static boolean isDisplayedLongRange(String columnNameVal) throws IOException {
        Long max = Long.MAX_VALUE;
        try {
            long sequenceId = Long.parseLong(columnNameVal);
            if (sequenceId <= Long.MAX_VALUE)
                return true;
            else
                return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isIdDisplayedAfterSetSequence(String columnNameVal,String setVal) throws IOException {
        try {
            long setSequence = Long.parseLong(setVal);
            long retreiveCalumnVal = Long.parseLong(columnNameVal);
            if (setSequence <= retreiveCalumnVal)
                return true;
            else
                return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getRandomString(int n)
    {
        int lowerLimit = 65;
        int upperLimit = 90;
        Random random = new Random();
        StringBuffer r = new StringBuffer(n);
        for (int i = 0; i < n; i++) {
            int nextRandomChar = lowerLimit
                    + (int) (random.nextFloat()
                    * (upperLimit - lowerLimit + 1));
            r.append((char) nextRandomChar);
        }
        return r.toString();
    }

    public static ArrayList<String> convertStringToJsonArray(String responseStr, boolean isValidresponse) {
        ArrayList<String> validSetList = new ArrayList<String>();
        ArrayList<String> errSetList = new ArrayList<String>();
        if (responseStr.contains("{")) {
            String[] arrVal = responseStr.split("\\{");
            for (int i = 0; i < arrVal.length; i++) {
                if(arrVal[i].contains("}") && (arrVal[i].contains("@odata.context"))) {
                    int pos = arrVal[i].indexOf("}", 0);
                    String jArry =(arrVal[i].substring(0, pos));
                    validSetList.add(jArry);
                }else if(arrVal[i].contains("}") && arrVal[i].contains("code") && (arrVal[i].contains("message"))){
                    int pos = arrVal[i].indexOf("}", 0);
                    String jArry =(arrVal[i].substring(0, pos));
                    errSetList.add(jArry);
                }
            }
        }
        if(isValidresponse) return validSetList;
        else return errSetList;
 }

     public static String getValueFromResponse(String strJson, String key) {
         String value = null;
         Map<String,String> hJsonData = new HashMap<String,String>();
         String jsonFields[] = strJson.split(",");

         //iterate the parts and add them to a map
         for(String field : jsonFields) {
                 //split the employee data by : to get id and name
                 String entityData[] = field.split("\":");

                 String strId = entityData[0].trim();
                 String strName = entityData[1].trim();

                 //add to map
                 hJsonData.put(strId.replaceAll("\"", ""), strName.replaceAll("\"", ""));
             }


         for (Map.Entry<String,String> entry : hJsonData.entrySet())
           if(entry.getKey().equalsIgnoreCase(key))
               value = entry.getValue();
         return value;
     }


     

}
