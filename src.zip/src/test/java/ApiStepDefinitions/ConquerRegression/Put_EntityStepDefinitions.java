package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Put_EntityStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store RequestBarCode used in all the requests */
    String RequestEntityName = "";
    String RequestBarcode = "";



    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Entity";
    String ResponseEntityId = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity association
     *
     * @throws Exception
     */
    @Given("Preparation for updating an entity table record")
    public void preparation_for_updating_an_entity_table_record() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for updating an entity table record");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity association for "BarCode"
         *
         * @throws Exception
         */
        @When("Put a valid request for updating entity_name in entity table")
        public void put_a_valid_request_for_updating_entity_name_in_entity_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            //Getting record from database entity table
            ResponseEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIdFromEntityForBeer, "entity_id");
            RequestBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+querySearchFormat(ResponseEntityId),"barcode");
            RequestEntityName = "TEST" + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Put_entity_ValidRequest.json");
            Request.put("Name", RequestEntityName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response=putRequest(Request.toJSONString(), ApiConstants.Route_Beer.concat("('"+RequestBarcode+"')"), HttpURLConnection.HTTP_OK);
        }

    /**
         * Verify the entity type with the unescaped name got created
         *
         * @throws Exception
         */
        @Then("Verify entity_name got updated in response with entity table")
        public void verify_entity_name_got_updated_in_response_with_entity_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "Name", RequestEntityName);
        }

    @Then("Verify Name in request as entity_name field is updated in entity table with current date")
    public void verify_name_in_request_as_entity_name_field_is_updated_in_entity_table_with_current_date() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String dbEntityName =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");
        ResponseEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "entity_id");
        String updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "updated_on");
        if (dbEntityName.equals(RequestEntityName)) {
            reportInstance.logPass("entity_name", " is updated in the db");
            if(!(updated_on_DBDate.equals("")) || (updated_on_DBDate!=null)) {
                if (updated_on_DBDate.split("\\.")[0].contains(todaysDateStr))
                    reportInstance.logPass(ResponseEntityId, " is updated in the db on " + updated_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not updated in the db on " + updated_on_DBDate);
            }else
              reportInstance.logFail("updated_on_DBDate", "field not found in DB due to DB error");
        }else
            reportInstance.logFail("Record", " is not updated in the db");
       }
}
