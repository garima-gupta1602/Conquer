package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.HttpStatus;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class TriggersSpecification_StepDefinitions extends DBHelper {

    JSONObject Response;
    JSONObject Request;
    String ResourcePath = "/Entity_Creation_Flow/Triggers_Specifications";
    HttpURLConnection conn;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    String requestName ;
    @Given("Read the POST Request for triggers and specification")
    public void Read_the_POST_Request() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the POST Request for api {string} for condition {string}")
    public void Send_the_POST_Request_for_api_for_condition(String apiConstant,String condition) throws Exception {
        requestName = "Lot update test trigger "+SharedFunctionsInTest.getRandomString(4);
        if(condition.equalsIgnoreCase("Invalid Attribute"))
             Request = ReadJsonInput(ResourcePath + "/Post_AnimalIntegrityCheck_InvalidAttribute.json");
        if(condition.equalsIgnoreCase("Integrity Check"))
             Request = ReadJsonInput(ResourcePath + "/Post_AnimalIntegrityCheck_IntegrityCheck.json");
        if(condition.equalsIgnoreCase("Null Location"))
            Request = ReadJsonInput(ResourcePath + "/Post_EntityType_NullLocation.json");
        if(condition.equalsIgnoreCase("Unique name"))
            Request = ReadJsonInput(ResourcePath + "/Post_Worker_UniqueNameSpecification.json");
        if(condition.equalsIgnoreCase("Esignature"))
            Request = ReadJsonInput(ResourcePath + "/Post_TestForEsignatureSpecification.json");
        if(condition.equalsIgnoreCase("Increment Trigger Successful"))
            Request = ReadJsonInput(ResourcePath + "/Post_SampleForCheckIncrementTriggerLotSuccessful.json");
        if(condition.equalsIgnoreCase("Increment Trigger Failed"))
            Request = ReadJsonInput(ResourcePath + "/Post_SampleForCheckIncrementTriggerLotFailed.json");


        if(apiConstant.equalsIgnoreCase("ANIMAL_INTEGRITY_CHECK"))
            conn=SendRequest(ApiConstants.Route_ANIMAL_INTEGRITYCHECK,Request.toString(),DefaultRequestHeader(),"POST");
        if(apiConstant.equalsIgnoreCase("ENTITY_TYPE"))
            conn=SendRequest(ApiConstants.Route_ENTITY_TYPE,Request.toString(),DefaultRequestHeader(),"POST");
        if(apiConstant.equalsIgnoreCase("WORKER"))
            conn=SendRequest(ApiConstants.Route_WORKER,Request.toString(),DefaultRequestHeader(),"POST");
        if(apiConstant.equalsIgnoreCase("TEST_FOR_ESIGNATURE"))
            conn=SendRequest(ApiConstants.Route_TEST_FOR_ESIGNATURE,Request.toString(),DefaultRequestHeader(),"POST");
        if(apiConstant.equalsIgnoreCase("SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT")) {
            Request.put("Name", requestName );
            conn = SendRequest(ApiConstants.Route_SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT, Request.toString(), DefaultRequestHeader(), "POST");
        }
   }

    @Then("Verify the response with error code {string} and message as {string} for specification")
    public void verify_the_response_with_error_code_and_message_as_for_specification(String code, String message) throws Exception
    {
        Response=ValidateResponse(conn,true, HttpStatus.SC_BAD_REQUEST,false,new HashMap());
        VerifyErrorMessage(Response, code, message);
    }

    @Then("Verify detailed response with error code {string} and message as {string} for specification")
    public void verify_detailed_response_with_error_code_and_message_as_for_specification(String code, String message) throws Exception
    {
        Response=ValidateResponse(conn,true, HttpStatus.SC_BAD_REQUEST,false,new HashMap());
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY, ApiConstants.ERROR_MESSAGE_CREATING_ENTITY,code,message);
    }

    @Then("Validate the Response code 201 Created")
    public void verify_the_response_code_201_created() throws Exception
    {
        Response=ValidateResponse(conn,true, HttpStatus.SC_CREATED,false,new HashMap());
        int responseCode = conn.getResponseCode();
        if(responseCode==201)
            reportInstance.logPass("Response code is displayed as expected", "Response code:"+ responseCode);
        else
            reportInstance.logFail("Response code is not displayed as expected", "Response code:"+ responseCode);
    }
    @Then("Validate the Response Body with database entity table")
    public void validate_the_response_body_with_database_entity_table() throws Exception {
        VerifyEntityData(Response, "Name", requestName);
        long req_ciTriggerRuns = (long) Request.get("CI_TRIGGER_RUNS");
        String response_entityId = GetattributefromResponse(Response,"Id");
        String db_entityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityID + querySearchFormat(requestName), "entity_id");
        if (response_entityId.equals(db_entityId))
            reportInstance.logPass("Entity id is created in entity table: ", db_entityId);
        else
            reportInstance.logFail("Entity id is not created in entity table: ", db_entityId);
        String res_ciTriggerRuns = GetattributefromResponse(Response,"CI_TRIGGER_RUNS");
        if(req_ciTriggerRuns>10) {
            if (req_ciTriggerRuns + 1 == Long.parseLong(res_ciTriggerRuns))
                reportInstance.logPass("Increment Trigger lot is successful Request CI_TRIGGER_RUNS: " + req_ciTriggerRuns + "And Response CI_TRIGGER_RUNS:" + res_ciTriggerRuns, "CI_TRIGGER_RUNS field is incremented by one");
            else
                reportInstance.logFail("Increment Trigger lot is failed Request CI_TRIGGER_RUNS: " + req_ciTriggerRuns + "And Response CI_TRIGGER_RUNS:" + res_ciTriggerRuns, "CI_TRIGGER_RUNS field is not incremented by one");
        }else if(req_ciTriggerRuns< 10) {
            if (req_ciTriggerRuns == Long.parseLong(res_ciTriggerRuns))
                reportInstance.logPass("Increment Trigger should not be triggered, Request CI_TRIGGER_RUNS: " + req_ciTriggerRuns + "And Response CI_TRIGGER_RUNS:" + res_ciTriggerRuns, "Response CI_TRIGGER_RUNS field is Same as request CI_TRIGGER_RUNS field");
            else
                reportInstance.logFail("Increment Trigger lot is triggered, Request CI_TRIGGER_RUNS: " + req_ciTriggerRuns + "And Response CI_TRIGGER_RUNS:" + res_ciTriggerRuns, "Response CI_TRIGGER_RUNS field is not Same as request CI_TRIGGER_RUNS field");
        }
    }

}
