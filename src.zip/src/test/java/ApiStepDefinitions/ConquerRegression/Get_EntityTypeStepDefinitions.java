package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.Random;


public class Get_EntityTypeStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestUnescapedName;
    String ResourcePath = "/Entity_Type";
    String entity_type_id = "";
    JSONArray jsonArry;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    @Given("Read the URL and Set Up the Headers for Entity_Type")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Entity_Type() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for Entity_Type");
        Readprerequest();
    }
    @When("Create a GET request for entity_type_name and send the GET Request")
    public void Create_a_GET_request_for_entity_type_name_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for entity_type_name and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_Entity_Type,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        RequestUnescapedName = GetattributefromResponse(Response, "UnescapedName");
    }
    @When("Create a GET request for newly created entity_type_name and send the GET Request")
    public void Create_a_GET_request_for_newly_created_entity_type_name_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for newly created entity_type_name and send the GET Request");
        RequestUnescapedName = "NEW" + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
        Request.put("UnescapedName", RequestUnescapedName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Entity_Type, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response, "UnescapedName", RequestUnescapedName);
        stringResponse = GetRequest(ApiConstants.Route_Entity_Type+"('"+RequestUnescapedName+"')","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with entity_type table")
    public void verify_response_with_entity_type_table() throws Exception {
        entity_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(RequestUnescapedName), "entity_type_id");
        if(entity_type_id!="")
            reportInstance.logPass("Entity type record found with entity_type_name: ","'"+RequestUnescapedName+"' and 'entity_type_id' displayed as : "+entity_type_id);
        else
            reportInstance.logFail("Entity type record not found with entity_type_name: ","'"+RequestUnescapedName+"'");
    }

    @Then("Verify entity_type_id should be in long integer datatype format in entity_Type table")
    public void verify_entity_type_id_should_be_in_long_integer_datatype_format_in_entity_Type_table() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(entity_type_id))
            reportInstance.logPass("entity_type_id is generated within Long integer data type range", ":" + entity_type_id);
        else
            reportInstance.logFail("entity_type_id is not generated within Long integer data type range", ":" + entity_type_id);

    }
}
