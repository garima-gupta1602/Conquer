package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Post_SuperTypeStepDefinitions  extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestUnescapedName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Super_Type";
   /** Retrive super_type_id for validation*/
    String super_type_id = "";

    String created_on_DBDate ;

     SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new super type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new super type")
    public void preparation_for_creation_of_a_new_super_type() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation of the new super type");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new super type "New Super Type "
         *
         * @param EntityPrefix
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new super type {string}")
        public void post_a_valid_request_for_a_creating_new_super_type(String EntityPrefix) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestUnescapedName = EntityPrefix + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_SuperType_ValidRequest.json");
            Request.put("UnescapedName", RequestUnescapedName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        }

        /**
         * Verify the entity type with the unescaped name got created
         *
         * @throws Exception
         */
        @Then("Verify the super type with the unescaped name got created")
        public void verify_the_super_type_with_the_unescaped_name_got_created() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "UnescapedName", RequestUnescapedName);
        }

    @Then("Verify unescaped name as super_type_name field is created in super_type table in database with current date")
    public void Verify_unescaped_name_as_super_type_name_field_is_created_in_super_type_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        super_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeName + querySearchFormat(RequestUnescapedName), "super_type_id");
        if (super_type_id !="") {
            reportInstance.logPass("super_type_id:" + super_type_id , " is created in the db");
            created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeName + querySearchFormat(RequestUnescapedName), "created_on");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass("super_type_id:" + super_type_id , " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("super_type_id:" + super_type_id , " is created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("'super_type_id'", " is not created in the db");
        }
    @Then("Verify super_type_id should be in long integer datatype format")
    public void Verify_super_type_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(super_type_id)&& sharedFunctions.isIdDisplayedAfterSetSequence(super_type_id,sharedFunctions.maxIntVal))
            reportInstance.logPass("SequenceId is generated within Long integer data type range", ":"+ super_type_id);
        else
            reportInstance.logFail("SequenceId is not generated within Long integer data type range", ":"+ super_type_id);
    }


}
