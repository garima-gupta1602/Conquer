package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.Random;


public class Get_EventStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestName;
    String ResourcePath = "/Event";

    String ResponseEntityId = "";
    String ResponseBarcode = "";
    JSONArray jsonArry;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for EVENT")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Event() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for EVENT");
        Readprerequest();
    }
    @When("Create a GET request for newly created EVENT and send the GET Request")
    public void Create_a_GET_request_for_newly_created_event_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for newly created EVENT and send the GET Request");
        RequestName = "EVENT" + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_Event_ValidRequest.json");
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Event, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response, "Name", RequestName);
        ResponseBarcode = GetattributefromResponse(Response, "Barcode");
        stringResponse = GetRequest(ApiConstants.Route_Event+"('"+ResponseBarcode+"')","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with entity table")
    public void verify_response_with_entity_table() throws Exception {
        reportInstance.logPass("Entity type record found with entity_name: ","'"+RequestName);
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        RequestName = GetattributefromResponse(Response, "Name");
        String entity_name =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");
        String ResponseEventId = ExecuteQueryToGetExpectedColumn(DbQueries.selectEventIdFromEntityEvent+ querySearchFormat(ResponseEntityId), "event_id");
        if (entity_name.equals(RequestName))
            reportInstance.logPass("Entity_Name: "+entity_name+ "and event_id: "+ResponseEventId, " are found in the db");
        else
            reportInstance.logFail("Entity", " is not found in the db");
    }

    @When("Create a GET request for EVENT and send the GET Request")
    public void Create_a_GET_request_for_event_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for EVENT and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_Event,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseEntityId = GetattributefromResponse(Response, "Id");
    }

}
