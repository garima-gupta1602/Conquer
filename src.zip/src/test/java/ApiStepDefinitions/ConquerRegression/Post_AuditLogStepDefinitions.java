package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Post_AuditLogStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
    JSONObject Response;
    String ResourcePath = "/Audit_Log";
    /** To Store UnEscapedName used in all the requests */
    String RequestName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResponseEntityId = "";
    String ResponseAuditLogId = "";
    String dbResponseAuditLogId = "";
    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity     type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new Audit_Log_id")
    public void preparation_for_creation_of_a_new_audit_log_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for creation of a new Audit_Log_id");
            //alterSeq(DbQueries.alterSequenceQuery);
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new Audit_Log")
        public void post_a_valid_request_for_a_creating_new_audit_log() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_AuditLog_ValidRequest.json");
            Request.put("Name", RequestName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST, HttpURLConnection.HTTP_CREATED);
        }

    @Then("Verify record got inserted in audit_log table")
    public void verify_record_got_inserted_in_audit_log_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        dbResponseAuditLogId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectAuditLogId + querySearchFormat(ResponseEntityId), "audit_log_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectAuditLogId + querySearchFormat(ResponseEntityId), "created_on");
        if (!dbResponseAuditLogId.equals("")) {
            reportInstance.logPass("verify_record_got_inserted_in_audit_log_table", " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(dbResponseAuditLogId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("Audit_Log_id", " is not created in the db");
        }

    @Then("Verify Audit_Log_id should be in long integer datatype format")
    public void Verify_Audit_Log_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(dbResponseAuditLogId) && sharedFunctions.isIdDisplayedAfterSetSequence(dbResponseAuditLogId,sharedFunctions.maxIntVal))
            reportInstance.logPass("Audit_Log_id "+dbResponseAuditLogId +" is generated within Long data type range", ":"+ dbResponseAuditLogId);
        else
            reportInstance.logFail("Audit_Log_id "+dbResponseAuditLogId +"is not generated within Long data type range", ":"+ dbResponseAuditLogId);
    }
}
