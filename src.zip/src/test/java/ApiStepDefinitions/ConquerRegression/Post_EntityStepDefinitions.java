package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.io.IOException;

public class Post_EntityStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

   /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Entity";
   /** Retrive entity_id for validation*/
    String ResponseEntityId = "";
    String ResponseEntityName = "";
    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new entity_id")
    public void preparation_for_creation_of_a_new_entity_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for creation of a new entity_id");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         *
         * @param          *
         * @throws Exception
         */
        @When("Post a valid request for a creating new entity_id")
        public void post_a_valid_request_for_a_creating_new_entity_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_Entity_ValidRequest.json");
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_Beer, HttpURLConnection.HTTP_CREATED);
        }


    @Then("Verify name as entity_name field is created in Entity table in database with current date and entity_id inserted in entity table")
    public void verify_name_as_entity_name_field_is_created_in_entity_table_in_database_with_current_date_and_entity_id_inserted_in_entity_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        ResponseEntityName = GetattributefromResponse(Response, "Name");
        String dbEntityId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_id");
        String dbEntityName =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");

        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "created_on");
        if (ResponseEntityId.equals(dbEntityId) && ResponseEntityName.equals(dbEntityName)) {
            reportInstance.logPass("Entity record", " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(ResponseEntityId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Entity Record", " is not created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("Entity", " is not created in the db");
        }
    @Then("Verify entity_id should be in long integer datatype format")
    public void Verify_entity_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(ResponseEntityId) && sharedFunctions.isIdDisplayedAfterSetSequence(ResponseEntityId,sharedFunctions.maxIntVal))
            reportInstance.logPass("event_id "+ResponseEntityId +" is generated within Long data type range", ":"+ ResponseEntityId);
        else
            reportInstance.logFail("event_id "+ResponseEntityId +"is not generated within Long data type range", ":"+ ResponseEntityId);
    }

    @When ("Post a new request for an entity with blank CI_Brand field")
    public void Post_a_new_request_for_an_entity_with_blank_CI_Brand_field() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_Entity_ValidRequest.json");
        Request.put("CI_Brand", "");
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_Beer, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify post response with error code {string} and message as {string}")
    public void verify_post_response_with_error_code_and_message_as(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

}
