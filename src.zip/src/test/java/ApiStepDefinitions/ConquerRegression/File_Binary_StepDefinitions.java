package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class File_Binary_StepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String EntityName;
    String ResponseFileId;
    String ResponseContentType;
    String ResponseEntityName;
    String barcode;
    HttpURLConnection conn;
    String ResourcePath = "/File_Binary";
    String ResponseBarcode;
    String created_on_DBDate;
    String updated_on_DBDate;
    String todaysDateStr;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for file_binary")
    public void Read_the_URL_and_Set_Up_the_Headers_for_file_binary() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the GET Request for file_binary_id {string}")
    public void Send_the_GET_Request_for_file_binary_id(String routeparam) throws Exception {
        conn = SendRequest(ApiConstants.Route_master+routeparam, "", DefaultRequestHeader(), "GET");
    }

    @Then("Validate the Response code for GET file_binary_id")
    public void Validate_the_Response_code_for_GET_file_binary_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body for GET file_binary table {string}")
    public void Validate_the_Response_Body_for_GET_file_binary_table(String entityName)  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "Name", entityName);
        ResponseFileId =GetattributefromResponse(Response, "Id");
        ResponseContentType=GetattributefromResponse(Response, "CONTENT_TYPE");
        String dbFileId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectFromFileBinary + querySearchFormat(ResponseFileId), "file_id");
        String dbFileContent =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectFromFileBinary + querySearchFormat(ResponseFileId), "content_type");
        if (dbFileId.equals(ResponseFileId)&&dbFileContent.equals(ResponseContentType))
            reportInstance.logPass("dbFileId: "+dbFileId+ "and dbFileContent: "+ dbFileContent, " are found in the db");
        else
            reportInstance.logFail("file record", " is not found in the db");
    }


    @When("Send the POST Request for file_binary_id {string}")
    public void Send_the_POST_Request_for_file_binary_id(String routeparam) throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_File_Binary.json");
        conn = SendRequest(ApiConstants.Route_master+routeparam, String.valueOf(Request), DefaultRequestHeader(), "POST");
    }

    @Then("Validate the Response code for POST file_binary_id")
    public void Validate_the_Response_code_for_POST_file_binary_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Validate the Response Body for POST file_binary table {string}")
    public void Validate_the_Response_Body_for_POST_file_binary_table(String entityName)  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "EntityTypeName", entityName);
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String dbFileId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectFromFileBinary + querySearchFormat(ResponseFileId), "file_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectFromFileBinary + querySearchFormat(ResponseFileId), "created_on");
        if (!(dbFileId.equals("")) || (created_on_DBDate != null))
            reportInstance.logPass("file_Binary record", " is created in the db on " + created_on_DBDate);
        else
            reportInstance.logFail("file_Binary record", " is created in the db on " + created_on_DBDate);
        if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
            if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("file_Binary  is inserted into file_Binary  table and", " is created in the db on " + created_on_DBDate);
            else
                reportInstance.logFail("file_Binary ", " is created in the db on " + created_on_DBDate);
        }
    }

    @Then("Verify File_id should be in long integer format")
    public void Verify_File_id_should_be_in_long_integer_format() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(ResponseFileId)&&sharedFunctions.isIdDisplayedAfterSetSequence(ResponseFileId,SharedFunctionsInTest.maxIntVal))
            reportInstance.logPass("record_id is generated within Long integer range", ":" + ResponseFileId);
        else
            reportInstance.logFail("record_id is not generated within long integer type range", ":" + ResponseFileId);
    }

    @When("Send the PUT Request for file_binary_id {string}")
    public void Send_the_PUT_Request_for_file_binary_id(String routeparam) throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_File_Binary.json");
        Response=postRequest(String.valueOf(Request),ApiConstants.Route_master+routeparam,HttpURLConnection.HTTP_CREATED);
        EntityName="Test"+RandomAlphanumericGenerate(3);
        barcode=GetattributefromResponse(Response, "Barcode");
        Request.put("Name", EntityName);
        conn = SendRequest(ApiConstants.Route_master+routeparam+"('"+barcode+"')", String.valueOf(Request), DefaultRequestHeader(), "PUT");
    }

    @Then("Validate the Response code for PUT file_binary_id")
    public void Validate_the_Response_code_for_PUT_file_binary_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body for PUT file_binary table")
    public void Validate_the_Response_Body_for_PUT_file_binary_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "Name", EntityName);
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseBarcode =GetattributefromResponse(Response, "Barcode");
        ResponseEntityName=GetattributefromResponse(Response, "Name");
        String dbResponseEntityName =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "entity_name");
        updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(ResponseBarcode), "updated_on");
        if (!(dbResponseEntityName.equals("")) || (updated_on_DBDate != null))
            reportInstance.logPass("file_Binary record", " is updated in the db on " + updated_on_DBDate);
        else
            reportInstance.logFail("file_Binary record", " is created in the db on " + updated_on_DBDate);
        if (!(updated_on_DBDate.equals("")) || (updated_on_DBDate != null)) {
            if (updated_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("file_Binary  is inserted into file_Binary  table and", " is created in the db on " + updated_on_DBDate);
            else
                reportInstance.logFail("file_Binary ", " is created in the db on " + updated_on_DBDate);
        }
    }
}
