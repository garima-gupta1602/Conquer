package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Post_ExperimentDataStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Experiment_Data";
   /** Retrive entity_id for validation*/
    String ResponseExperimentSampleId = "";
    String dbExperimentDataId = "";
    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity     type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new experiment_data_id")
    public void preparation_for_creation_of_a_new_experiment_data_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for creation of a new experiment_data_id");
            //maxIntVal =  ExecuteQueryToGetExpectedColumn(DbQueries.sequenceQuery ,"setval");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         *
         * @param EntityPrefix
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new experiment_data {string}")
        public void post_a_valid_request_for_a_creating_new_experiment_data(String EntityPrefix) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestName = EntityPrefix + sharedFunctions.getRandomString(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_ExperimentData_ValidRequest.json");
            Request.put("Name", RequestName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentSample, HttpURLConnection.HTTP_CREATED);
        }

    @Then("Verify the new record inserted in experiment_data table")
    public void verify_the_new_record_inserted_in_experiment_data_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseExperimentSampleId = GetattributefromResponse(Response, "Id");
        String dbExperimentSampleID =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentSampleIdOnExperimentSample + querySearchFormat(ResponseExperimentSampleId), "experiment_sample_id");
        dbExperimentDataId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentDataId + querySearchFormat(ResponseExperimentSampleId), "experiment_data_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentDataId + querySearchFormat(ResponseExperimentSampleId), "created_on");
        if (ResponseExperimentSampleId.equals(dbExperimentSampleID)) {
            reportInstance.logPass("Sample_Type", " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(dbExperimentDataId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("Experiment_Sample_Id", " is not created in the db");
        }

    @Then("Verify experiment_data_id should be in long integer datatype format")
    public void Verify_experiment_data_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(dbExperimentDataId) && sharedFunctions.isIdDisplayedAfterSetSequence(dbExperimentDataId,sharedFunctions.maxIntVal))
            reportInstance.logPass("experiment_data_id "+dbExperimentDataId +" is generated within Long data type range", ":"+ dbExperimentDataId);
        else
            reportInstance.logFail("experiment_data_id "+dbExperimentDataId +"is not generated within Long data type range", ":"+ dbExperimentDataId);
    }
}
