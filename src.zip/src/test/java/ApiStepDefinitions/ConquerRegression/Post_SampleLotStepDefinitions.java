package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Post_SampleLotStepDefinitions extends DBHelper {
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New lot Via ODATA step definition
     */

    /**
     * To Store JSONOBJECT Response
     */
    JSONObject Response;

    /**
     * To Get the JSON DATA - Resource Path
     */
    String ResourcePath = "/Sample_Lot";
    /**
     * Retrive lot_id for validation
     */
    String ResponseLotId = "";

    String created_on_DBDate;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new lot_id")
    public void preparation_for_creation_of_a_new_lot_id() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "preparation_for_creation_of_a_new_lot_id");
        //maxIntVal = ExecuteQueryToGetExpectedColumn(DbQueries.sequenceQuery, "setval");
        Readprerequest();
    }


    /**
     * Post a valid request for a creating new entity type "New Event "
     *
     * @throws Exception
     */
    @When("Post a valid request for a creating new lot_id")
    public void post_a_valid_request_for_a_creating_new_lot_id() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_SampleLot_ValidRequest.json");
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_BeerSampleLot, HttpURLConnection.HTTP_CREATED);
    }


    @Then("Verify new lot_id got created in lot table in database with current date")
    public void verify_new_lot_id_got_created_in_lot_table_in_databse_with_current_date() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseLotId = GetattributefromResponse(Response, "Id");
        String dbLotId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectLotId + querySearchFormat(ResponseLotId), "lot_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectLotId + querySearchFormat(ResponseLotId), "created_on");
        if (ResponseLotId.equals(dbLotId)) {
            reportInstance.logPass("Lot_id", " is created in the db");
            if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(ResponseLotId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
            }
        } else
            reportInstance.logFail("New record", " is not created in the db");
    }

    @Then("Verify lot_id should be in long integer datatype format")
    public void Verify_lot_id_should_be_in_long_integer_datatype_format() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(ResponseLotId) && sharedFunctions.isIdDisplayedAfterSetSequence(ResponseLotId, sharedFunctions.maxIntVal))
            reportInstance.logPass("record_id " + ResponseLotId + " is generated within Long data type range", ":" + ResponseLotId);
        else
            reportInstance.logFail("record_id " + ResponseLotId + "is not generated within Long data type range", ":" + ResponseLotId);
    }

}