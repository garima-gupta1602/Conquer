package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Put_SampleLotStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store RequestBarCode used in all the requests */
    String RequestName = "";


    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Sample_Lot";
    String dbBarcode = "";
    String ResponseEntityId = "";
    String RequestBarcode = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity association
     *
     * @throws Exception
     */
    @Given("Preparation for updating entity record")
    public void preparation_for_updating_entity_record() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "preparation_for_updating_entity_record");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity association for "BarCode"
         *
         * @throws Exception
         */
        @When("Put a valid request for a updating record with {string}")
        public void put_a_valid_request_for_a_updating_record_with(String requestName) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            //Getting record from database entity table
            RequestBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarCodeFromEntityTbl+" 'BO%' order by created_on desc;","Barcode");
            RequestName = requestName + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Put_SampleLot_ValidRequest.json");
            Request.put("Name", RequestName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response=putRequest(Request.toJSONString(), ApiConstants.Route_BeerOrder.concat("('"+RequestBarcode+"')"), HttpURLConnection.HTTP_OK);
            ResponseEntityId = GetattributefromResponse(Response, "Id");
        }



    @Then("Verify record got updated in entity_table in database with current date")
    public void Verify_record_got_updated_in_entity_table_in_database_with_current_date() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String entity_name =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");
        String updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "updated_on");
        if (entity_name.equals(RequestName)) {
            reportInstance.logPass("Entity_Name", " is created in the db");
            if(!(updated_on_DBDate.equals("")) || (updated_on_DBDate!=null)) {
                if (updated_on_DBDate.split("\\.")[0].contains(todaysDateStr))
                    reportInstance.logPass(ResponseEntityId, " is updated in the db on " + updated_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not updated in the db on " + updated_on_DBDate);
            }else
              reportInstance.logFail("updated_on_DBDate", "field not found in DB due to DB error");
        }else
            reportInstance.logFail("Entity", " is not updated in the db");
       }
}
