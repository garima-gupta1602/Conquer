package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Put_EntityAssociationStepDefinitions  extends DBHelper {
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

    /**
     * To Store JSONOBJECT Response
     */
    JSONObject Response;

    /**
     * To Store RequestBarCode used in all the requests
     */
    String RequestName = "";
    String dbBarcode;


    /**
     * To Get the JSON DATA - Resource Path
     */
    String ResourcePath = "/Entity_Association";
    /**
     * Retrive entity_association_id for validation
     */
    String entity_association_id = "";
    String entity_id;
    String updated_on_DBDate;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity association
     *
     * @throws Exception
     */
    @Given("Preparation for updating an entity association record")
    public void preparation_for_updating_an_entity_association() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "Preparation for updating an entity association record");
        Readprerequest();
    }


    /**
     * Post a valid request for a creating new entity association for "BarCode"
     *
     * @param EntityPrefix
     * @throws Exception
     */
    @When("Post a valid request for a updating barcode in entity association {string}")
    public void post_a_valid_request_for_a_updating_barcode_in_entity_association(String EntityPrefix) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //Getting record from database entity table
        entity_id = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEAIDOfLongDataTypeBeerBatch, "entity_id");
        entity_association_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityAssociation + querySearchFormat(entity_id), "entity_association_id");
        dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(entity_id), "Barcode");
        RequestName = EntityPrefix + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Put_EntityAssociation_ValidRequest.json");
        Request.put("Barcode", dbBarcode);
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = putRequest(Request.toJSONString(), ApiConstants.Route_BeerBatch.concat("('" + dbBarcode + "')"), HttpURLConnection.HTTP_OK);
    }

    /**
     * Verify the entity type with the unescaped name got created
     *
     * @throws Exception
     */
    @Then("Verify the 'Barcode' got updated in response")
    public void verify_the_name_got_created_in_response() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        VerifyEntityData(Response, "Name", RequestName);
    }

    @Then("Verify name as barcode field is updated in entity table and mapped with entity_association table in database with current date")
    public void Verify_name_as_barcode_field_is_updated_in_entity_table_and_mapped_with_entity_association_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String entity_id = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityID + querySearchFormat(RequestName), "entity_id");
        entity_association_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityAssociation + querySearchFormat(entity_id), "entity_association_id");
        if (entity_association_id != "") {
            reportInstance.logPass("entity_association_id:" + entity_association_id, " is created in the db");
            updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(entity_id), "updated_on");
            if (!(updated_on_DBDate.equals("")) || (updated_on_DBDate != null)) {
                if (updated_on_DBDate.split("\\.")[0].contains(todaysDateStr))
                    reportInstance.logPass("entity_id:" + entity_id, " is updated in the db on " + updated_on_DBDate);
                else
                    reportInstance.logFail("entity_id:" + entity_id, " is not updated in the db on " + updated_on_DBDate);
            }
        } else
            reportInstance.logFail("'entity_association_id'", " is not found in the db");
    }

    @When("Put a request for a updating column {string} with null value")
    public void Put_a_request_for_a_updating_column_with_null_value(String columnName) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/Put_EntityAssociation_ValidRequest.json");
        if (columnName.toLowerCase().equals("id"))
            Request.put("Id", null);
        if (columnName.toLowerCase().equals("name"))
            Request.put("Name", null);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = putRequest(Request.toJSONString(), ApiConstants.Route_BeerBatch.concat("('" + dbBarcode + "')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the response error with code {string} and message as {string}")
    public void verify_the_response_error_with_code_and_message_as(String Code, String Message) throws Exception {

        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

}

