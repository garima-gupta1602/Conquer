package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.net.HttpURLConnection;

public class CELL_StepDefinitions extends DBHelper {
    JSONObject Response;
    String stringResponse;
    String EntityName;
    String ResponseFileId;
    String RequestUnescapedName;
    String barcode;
    String idAttribute;
    HttpURLConnection conn;
    String ResourcePath = "/CELL";
    String created_on_DBDate;
    String updated_on_DBDate;
    String todaysDateStr;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for Cell")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Cell() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the GET Request for Cell_id {string}")
    public void Send_the_GET_Request_for_Cell_id(String routeparam) throws Exception {
        stringResponse=GetRequest(ApiConstants.Route_master+routeparam, "");
        Response=StringToJSONObject(stringResponse);
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(stringResponse), "value");
        String resp = value.get(0).toString();
        Response = StringToJSONObject(resp);
        idAttribute = GetattributefromResponse(Response, "Id");
        conn = SendRequest(ApiConstants.Route_master+routeparam+"("+idAttribute+")", "", DefaultRequestHeader(), "GET");
    }

    @Then("Validate the Response code for Cell_id")
    public void Validate_the_Response_code_for_Cell_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body with Cell table")
    public void Validate_the_Response_Body_with_Cell_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "Id", idAttribute);
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String CellId =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveCellID + querySearchFormat(ResponseFileId), "cell_id");
        if (CellId.equals(ResponseFileId))
            reportInstance.logPass("CellId: "+CellId+"" , " are found in the db");
        else
            reportInstance.logFail("file record", " is not found in the db");
    }

    @When("Send the POST Request for Container {string}")
    public void Send_the_POST_Request_for_Container(String routeparam) throws Exception {
        RequestUnescapedName="Test Name "+RandomAlphanumericGenerate(4);
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_CELL.json");
        Request.put("Name",RequestUnescapedName);
        conn = SendRequest(ApiConstants.Route_master+routeparam, String.valueOf(Request), DefaultRequestHeader(), "POST");
    }

    @Then("Validate the Response code for POST Query for Cell_id")
    public void Validate_the_Response_code_for_POST_Query_for_Cell_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Validate the Response Body for POST with Cell table")
    public void Validate_the_Response_Body_for_POST_with_Cell_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String CellId =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveContainerId+querySearchFormat(ResponseFileId) , "container_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveContainerId+querySearchFormat(ResponseFileId), "created_on");
        if (!(CellId.equals("")) || (created_on_DBDate != null))
            reportInstance.logPass("CELL record", " is created in the db on " + created_on_DBDate);
        else
            reportInstance.logFail("CELL record", " is created in the db on " + created_on_DBDate);
        if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
            if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("CELL is inserted into list_member  table and", " is created in the db on " + created_on_DBDate);
            else
                reportInstance.logFail("CELL ", " is created in the db on " + created_on_DBDate);
        }
    }

    @Then("Verify cell_id should be in long integer format")
    public void Verify_cell_id_should_be_in_long_integer_format() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(ResponseFileId)&&sharedFunctions.isIdDisplayedAfterSetSequence(ResponseFileId,sharedFunctions.maxIntVal))
            reportInstance.logPass("record_id is generated within Long integer range", ":" + ResponseFileId);
        else
            reportInstance.logFail("record_id is not generated within long integer type range", ":" + ResponseFileId);
    }

    @When("Send the PUT Request for Container {string}")
    public void Send_the_PUT_Request_for_Container(String routeparam) throws Exception {
        EntityName="Test"+RandomAlphanumericGenerate(3);
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_CELL.json");
        Request.put("Name", EntityName);
        Response=postRequest(String.valueOf(Request),ApiConstants.Route_master+routeparam,HttpURLConnection.HTTP_CREATED);
        barcode=GetattributefromResponse(Response, "Barcode");
        EntityName="Test"+RandomAlphanumericGenerate(3);
        JSONObject putRequest=ReadJsonInput(ResourcePath+"/PUT_CELL.json");
        putRequest.put("Name", EntityName);
        conn = SendRequest(ApiConstants.Route_master+routeparam+"('"+barcode+"')", String.valueOf(putRequest), DefaultRequestHeader(), "PUT");
    }

    @Then("Validate the Response code for PUT Query for Cell_id")
    public void Validate_the_Response_code_for_PUT_Query_for_Cell_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body for PUT with Cell table")
    public void Validate_the_Response_Body_for_PUT_with_Cell_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "Name", EntityName);
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String dbResponseEntityName =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseFileId), "entity_name");
        updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseFileId), "updated_on");
        if (!(dbResponseEntityName.equals("")) || (updated_on_DBDate != null))
            reportInstance.logPass("cell record", " is updated in the db on " + updated_on_DBDate);
        else
            reportInstance.logFail("cell record", " is created in the db on " + updated_on_DBDate);
        if (!(updated_on_DBDate.equals("")) || (updated_on_DBDate != null)) {
            if (updated_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("cell  is inserted into file_Binary  table and", " is created in the db on " + updated_on_DBDate);
            else
                reportInstance.logFail("cell", " is created in the db on " + updated_on_DBDate);
        }
    }
}

