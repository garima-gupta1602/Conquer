package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Post_TypeAttributeStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestAttributeName = "";
    String RequestColumnHeaderName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Type_Attribute";
   /** Retrive entity_type_attribute_id for validation*/
    String entity_type_attribute_id = "";
    /** Retrive attribute_id for validation*/
    String attribute_id = "";
    /** Retrive super_type_attribute_id for validation*/
    String super_type_attribute_id = "";

    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new type attribute
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new type attribute")
    public void preparation_for_creation_of_a_new_entity_type() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation of the new type attribute");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Entity "
         *
         * @param EntityPrefix
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new type attribute {string} and column header {string}")
        public void post_a_valid_request_for_a_creating_new_type_attribute_and_column_header(String EntityPrefix,String columnHeader) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestAttributeName = EntityPrefix + RandomAlphanumericGenerate(4);
            RequestColumnHeaderName = "Test " + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_TypeAttribute_ValidRequest.json");
            Request.put("AttributeName", RequestAttributeName);
            Request.put("ColumnHeader", RequestColumnHeaderName);
            Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);

        }

        /**
         * Verify the column_header with the given name got created
         *
         * @throws Exception
         */
        @Then("Verify the {string} with the given name got created")
        public void verify_the_columnNameField_with_the_given_name_got_created(String columnName) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            switch (columnName.toLowerCase()){
                case "column_header":{
                    VerifyEntityData(Response, "ColumnHeader", RequestColumnHeaderName);
                    break;
                }
                case "attribute_name":{
                    VerifyEntityData(Response, "AttributeName", RequestAttributeName);
                    break;
                }
            }
        }

    @Then("Verify {string} field is created in {string} table in database with current date")
    public void Verify_field_is_created_in_table_in_database_with_current_date(String columnName,String tableName) throws Exception {
        created_on_DBDate = "";
        attribute_id ="";
        String todaysDateStr = sharedFunctions.todaysDate();
        switch (columnName.toLowerCase()){
            case "column_header":{
                entity_type_attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeAttribute + querySearchFormat(RequestColumnHeaderName), "entity_type_attribute_id");
                if (entity_type_attribute_id != "") {
                    reportInstance.logPass("entity_type_attribute_id is created in " +tableName +" in the db:", entity_type_attribute_id);
                }else
                    reportInstance.logFail("Record not inserted into DB", "entity_type_attribute_id is created in " +tableName +" in the db");
                created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeAttribute + querySearchFormat(RequestColumnHeaderName), "created_on");
                break;
            }
            case "attribute_name":{
                attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectAttribute + querySearchFormat(RequestAttributeName), "attribute_id");
                if (attribute_id != "") {
                    reportInstance.logPass("attribute_id is created in " +tableName +" the db: ", attribute_id);
                }else
                    reportInstance.logFail("Record not inserted into DB", "attribute_id is not created in " +tableName +" in the db");
                created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectAttribute + querySearchFormat(RequestAttributeName), "created_on");
                break;
            }
            case "attribute_id":{
                attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectAttribute + querySearchFormat(RequestAttributeName), "attribute_id");
                super_type_attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeAttribute + querySearchFormat(attribute_id), "super_type_attribute_id");
                if (super_type_attribute_id != "") {
                    reportInstance.logPass("super_type_attribute_id is created in " +tableName +" in the db", super_type_attribute_id);
                }else
                    reportInstance.logFail("Record not inserted into DB", "super_type_attribute_id is not created in " +tableName +" in the db");
                created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeAttribute + querySearchFormat(attribute_id), "created_on");
                break;
            }
        }
        if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(columnName, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record not inserted into DB  ", columnName+" is not created in the db");
              }
            else
            reportInstance.logFail("Record not inserted into DB", columnName+ " is not created in the db");
    }
    @Then("Verify newly generated ID {string} should be in long integer datatype format")
    public void Verify_newly_generated_attribute_Id_should_be_in_long_integer_datatype_format(String generatedId) throws Exception
    {
       String  newlyCreatedId = "";
        switch (generatedId) {
            case "entity_type_attribute_id": {
                newlyCreatedId = entity_type_attribute_id;
                break;
            }
            case "attribute_id": {
                newlyCreatedId = attribute_id;
                break;
            }
            case "super_type_attribute_id": {
                newlyCreatedId = super_type_attribute_id;
                break;
            }
        }
      if(sharedFunctions.isDisplayedLongRange(newlyCreatedId)&& sharedFunctions.isIdDisplayedAfterSetSequence(newlyCreatedId,sharedFunctions.maxIntVal) )
      reportInstance.logPass(generatedId + " is generated within Long integer data type range", ":"+ newlyCreatedId);
      else
      reportInstance.logFail(generatedId+ " is not generated within Long integer data type range", ":"+ newlyCreatedId);
    }
}
