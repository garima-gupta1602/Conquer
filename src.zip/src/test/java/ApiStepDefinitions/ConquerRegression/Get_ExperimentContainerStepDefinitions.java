package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class Get_ExperimentContainerStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String ResponseExperimentContainerId = "";
    String ResourcePath = "/Experiment_Container";
    JSONArray jsonArry;

    @Given("Read the URL and Set Up the Headers for get request of Experiment_Container API")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Event() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for get request of Experiment_Container API");
        Readprerequest();
    }
   @When("Create a GET request for newly created experiment_container record and send the GET Request")
       public void create_a_GET_request_for_newly_created_experiment_container_record_and_send_the_GET_Request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for newly created experiment_container record and send the GET Request");
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_ExperimentContainer_ValidRequest.json");
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentContainer, HttpURLConnection.HTTP_CREATED);
        String ResponseBarcode = GetattributefromResponse(Response, "Barcode");
        stringResponse = GetRequest(ApiConstants.Route_ExperimentContainer+"('"+ResponseBarcode+"')","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with experiment_container table")
    public void verify_response_with_experiment_container_table() throws Exception {
        ResponseExperimentContainerId = GetattributefromResponse(Response, "Id");
        reportInstance.logPass("experiment_container record found with experiment_container_id: ","'"+ResponseExperimentContainerId);
        String dbExperimentContainerId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentContainerId + querySearchFormat(ResponseExperimentContainerId), "experiment_container_id");
        if (ResponseExperimentContainerId.equals(dbExperimentContainerId))
            reportInstance.logPass("experiment_sample_id: "+dbExperimentContainerId+ "and record_id: "+ dbExperimentContainerId, " are found in the db");
        else
            reportInstance.logFail("experiment_sample_id", " is not found in the db");
    }

    @When("Create a GET request for experiment_container and send the GET Request")
    public void Create_a_GET_request_for_experiment_container_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for experiment_container and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_ExperimentContainer,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseExperimentContainerId = GetattributefromResponse(Response, "Id");
    }

}
