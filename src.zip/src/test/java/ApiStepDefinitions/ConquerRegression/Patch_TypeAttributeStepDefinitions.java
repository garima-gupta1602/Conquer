package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Patch_TypeAttributeStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestAttributeName = "";
    String RequestColumnHeaderName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Type_Attribute";
   /** Retrive entity_type_attribute_id for validation*/
    String entity_type_attribute_id = "";

    /**
     * Preparation for creation of a new type attribute
     *
     * @throws Exception
     */
    @Given("Preparation for updating existing type attribute")
    public void preparation_for_updating_existing_type_attribute() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation of updating existing type attribute");
            Readprerequest();
        }


        /**
         * Post a valid request for a updating existing entity type attribute
         *
         * @throws Exception
         */
        @When("Patch a valid request for a updating entity type attribute")
        public void patch_a_valid_request_for_a_updating_entity_type_attribute() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestAttributeName = "TEST" + RandomAlphanumericGenerate(4);
            RequestColumnHeaderName = "TEST " + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_TypeAttribute_ValidRequest.json");
            Request.put("AttributeName", RequestAttributeName);
            Request.put("ColumnHeader", RequestColumnHeaderName);
            Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
            entity_type_attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeAttribute + querySearchFormat(RequestColumnHeaderName), "entity_type_attribute_id");
            Response = patchRequest("{\"DisplaySeq\": 10}", ApiConstants.Route_TypeAttribute+"("+entity_type_attribute_id+")", HttpURLConnection.HTTP_OK);
        }

    @Then("Verify the response code for patch request for the entity type attribute as {string} and message as {string}")
    public void verify_the_error_message_for_empty_unescapedname(String Code, String Message) throws Exception
    {
        reportInstance.logInfo("STEPS","To verify the entity type attribute");
        VerifyErrorMessage(Response, Code, Message);
    }
    @When("Patch a request for a updating string attribute with invalid value")
    public void patch_a_request_for_a_updating_string_attribute_with_invalid_value() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestAttributeName = "TEST" + RandomAlphanumericGenerate(4);
        RequestColumnHeaderName = "TEST " + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_TypeAttribute_ValidRequest.json");
        Request.put("AttributeName", RequestAttributeName);
        Request.put("ColumnHeader", RequestColumnHeaderName);
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
        entity_type_attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeAttribute + querySearchFormat(RequestColumnHeaderName), "entity_type_attribute_id");
        Response = patchRequest("{\"AttributeName\": 0}", ApiConstants.Route_TypeAttribute+"("+entity_type_attribute_id+")", HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Patch a request for a updating displaySequence with null value")
    public void patch_a_request_for_a_updating_displaySequence_with_null_value() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestAttributeName = "TEST" + RandomAlphanumericGenerate(4);
        RequestColumnHeaderName = "TEST " + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_TypeAttribute_ValidRequest.json");
        Request.put("AttributeName", RequestAttributeName);
        Request.put("ColumnHeader", RequestColumnHeaderName);
        Response = postRequest(Request.toString(), ApiConstants.Route_TypeAttribute, HttpURLConnection.HTTP_CREATED);
        entity_type_attribute_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeAttribute + querySearchFormat(RequestColumnHeaderName), "entity_type_attribute_id");
        Response = patchRequest("{\"DisplaySeq\": null}", ApiConstants.Route_TypeAttribute+"("+entity_type_attribute_id+")", HttpURLConnection.HTTP_OK);
    }
}
