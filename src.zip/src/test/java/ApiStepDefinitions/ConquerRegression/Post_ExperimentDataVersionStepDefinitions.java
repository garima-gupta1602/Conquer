package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;

public class Post_ExperimentDataVersionStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

    /** To Store JSONOBJECT Response */
    JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestName = "";
    String stringResponse;
    JSONArray jsonArry;
    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Experiment_Data_Version";
   /** Retrive entity_id for validation*/
    String ResponseBarCode = "";
    String dbExperimentDataId = "";
    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity     type
     *
     * @throws Exception
     */
    @Given("Preparation for experiment_data_version record")
    public void preparation_for_experiment_data_version_records() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for creation of a new experiment_data_version record");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         * @throws Exception
         */
        @When("Post a valid request for a creating new record in experiment_data_version")
        public void post_a_valid_request_for_a_creating_new_record_in_experiment_data_version() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance.logInfo("STEPS : ", "Create a GET request for type_association_id and send the GET Request");
            stringResponse = GetRequest(ApiConstants.Route_ExperimentDataVersion+"?$expand=EXPERIMENT_SAMPLES","");
            Response = StringToJSONObject(stringResponse);
            jsonArry = JSONObjectToJsonArray(Response,"value");
            Response = (JSONObject)jsonArry.get(0);
            ResponseBarCode = GetattributefromResponse(Response, "Barcode");
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_ExperimentDataVersion_ValidRequest.json");
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentDataVersion+"('"+ResponseBarCode+"')/EXPERIMENT.Publish", HttpURLConnection.HTTP_OK);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentDataVersion+"('"+ResponseBarCode+"')/EXPERIMENT.Unpublish", HttpURLConnection.HTTP_OK);
        }

    @Then("Verify the barcode got created in response")
    public void verify_the_barcode_got_created_in_response() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String postResponsebarcode = GetattributefromResponse(Response, "Barcode");
        VerifyEntityData(Response,"Barcode",postResponsebarcode);
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.selectExperimentDataVersionId, "created_on");
           if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(dbExperimentDataId, " is created in the db on " + created_on_DBDate);
                    else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
              }else
               reportInstance.logFail("Record", " is not created in the db on ");

    }

    @Then("Verify column value experiment_data_id should be in long integer datatype format")
    public void Verify_column_value_experiment_data_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        String dbExperimentDataID = ExecuteQueryToGetExpectedColumn(DbQueries.selectExperimentDataVersionId, "experiment_data_id");;
        if(sharedFunctions.isDisplayedLongRange(dbExperimentDataID) && sharedFunctions.isIdDisplayedAfterSetSequence(dbExperimentDataID,sharedFunctions.maxIntVal))
            reportInstance.logPass("experiment_data_id "+dbExperimentDataID +" is generated within Long data type range", ":"+ dbExperimentDataID);
        else
            reportInstance.logFail("experiment_data_id "+dbExperimentDataID +"is not generated within Long data type range", ":"+ dbExperimentDataID);
    }

    /**
     * Post a valid request for a creating new entity type "New Event "
     * @throws Exception
     */
    @When("Put a valid request for updating the new record in experiment_data_version")
    public void put_a_valid_request_for_updation_the_new_record_in_experiment_data_version() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestName = "TEST" +  sharedFunctions.getRandomString(4);
        stringResponse = GetRequest(ApiConstants.Route_ExperimentDataVersion+"?$expand=EXPERIMENT_SAMPLES","");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseBarCode = GetattributefromResponse(Response, "Barcode");
        JSONObject Request = ReadJsonInput(ResourcePath + "/Put_ExperimentDataVersion_ValidRequest.json");
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response=putRequest(Request.toJSONString(), ApiConstants.Route_ExperimentDataVersion+"('"+ResponseBarCode+"')", HttpURLConnection.HTTP_OK);
    }
    /**
     * Put a valid request for a updating request
     * @throws Exception
     */
    @Then("Verify the name got updated in response")
    public void Verify_the_name_got_updated_in_response() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String ResponseName = GetattributefromResponse(Response, "Name");
        String ResponseEntityId = GetattributefromResponse(Response, "Id");
        VerifyEntityData(Response, "Name", ResponseName);
        String updated_on = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId), "updated_on");
        if (!(updated_on.equals("")) || (updated_on != null)) {
            if (updated_on.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("Record ", " is updated in the db on " + updated_on);
            else
                reportInstance.logFail("Record", " is not created in the db on " + updated_on);
        } else
            reportInstance.logFail("Record", " is not updated in the db");

    }
}
