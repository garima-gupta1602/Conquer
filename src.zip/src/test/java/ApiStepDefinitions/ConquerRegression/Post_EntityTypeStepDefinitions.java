package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Post_EntityTypeStepDefinitions  extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;
        JSONObject Response_SuperType;

    /** To Store UnEscapedName used in all the requests */
    String RequestUnescapedName = "";
    String RequestSuperTypeUnescapedName = "";


    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Entity_Type";
    String SuperTypeResourcePath = "/Super_Type";
   /** Retrive entity_type_id for validation*/
    String entity_type_id = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    String created_on_DBDate ;
    String superTypeID = "";
    /**
     * Preparation for creation of a new entity type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new entity type")
    public void preparation_for_creation_of_a_new_entity_type() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation of the new entity type");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Entity "
         *
         * @param EntityPrefix
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new entity type {string}")
        public void post_a_valid_request_for_a_creating_new_entity_type(String EntityPrefix) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestUnescapedName = EntityPrefix + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
            Request.put("UnescapedName", RequestUnescapedName);
            Request.put("Prefix", "PRE"+sharedFunctions.getRandomString(4));
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_Entity_Type, HttpURLConnection.HTTP_CREATED);

        }

        /**
         * Verify the entity type with the unescaped name got created
         *
         * @throws Exception
         */
        @Then("Verify the entity type with the unescaped name got created")
        public void verify_the_entity_type_with_the_unescaped_name_got_created() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "UnescapedName", RequestUnescapedName);
        }

    @Then("Verify unescaped name as entity_type_name field is created in entity_type table in database with current date")
    public void Verify_unescaped_name_as_entity_type_name_field_is_created_in_entity_type_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(RequestUnescapedName), "created_on");
        entity_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityType + querySearchFormat(RequestUnescapedName), "entity_type_id");
        String sequenceName = "et_" + entity_type_id + "_seq";
        HashMap results = ExecuteQuery(DbQueries.SelectSequenceFromPgClass + querySearchFormat(sequenceName));
        int DbValue = results.size();
        if (DbValue == 1) {
            reportInstance.logPass(sequenceName, " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(sequenceName, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail(sequenceName, " is created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail(sequenceName, " is not created in the db");
        }
    @Then("Verify entity_type_id should be in long integer datatype format")
    public void Verify_entity_type_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(entity_type_id) && sharedFunctions.isIdDisplayedAfterSetSequence(entity_type_id,sharedFunctions.maxIntVal) )
            reportInstance.logPass("SequenceId is generated within Long integer data type range", ":"+ entity_type_id);
        else
            reportInstance.logFail("SequenceId is not generated within Long integer data type range", ":"+ entity_type_id);
    }
    @When("Post a request for a new entity type with column {string} value {string}")
    public void Post_a_request_for_a_new_entity_type_with_column(String columnName, String columnValue) throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
        if ((columnName.toLowerCase().equals("supertypeid"))&&(columnValue.equals("zero")))
            Request.put("SuperTypeId", 0);
        if ((columnName.toLowerCase().equals("supertypeid"))&&(columnValue.equals("null")))
            Request.put("SuperTypeId", null);
        if ((columnName.toLowerCase().equals("defaultlocationid"))&&(columnValue.equals("zero")))
            Request.put("DefaultLocationId", 0);
        if ((columnName.toLowerCase().equals("defaultlocationid"))&&(columnValue.equals("null")))
            Request.put("DefaultLocationId", null);

        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the response with error code {string} and message as {string} for invalid_request")
    public void verify_the_response_with_error_code_and_message_as_for_invalid_request(String Code, String Message) throws Exception {

        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }
    @When("Post a valid request for a creating new super type Id with name {string}")
    public void post_a_valid_request_for_a_creating_new_super_type_Id_with_name (String EntityPrefix) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestSuperTypeUnescapedName = EntityPrefix + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(SuperTypeResourcePath + "/Post_SuperType_ValidRequest.json");
        Request.put("UnescapedName", RequestSuperTypeUnescapedName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response_SuperType = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
    }
    @Then("Verify the super type got created with the unescaped name")
    public void verify_the_super_type_got_created_with_the_unescaped_name() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyEntityData(Response_SuperType, "UnescapedName", RequestSuperTypeUnescapedName);
    }
    @When ("Post a valid request for a creating new entity type and new supertypeId")
    public void Post_a_valid_request_for_a_creating_new_entity_type_and_new_supertypeId() throws Exception {
        superTypeID = ExecuteQueryToGetExpectedColumn(DbQueries.SelectSuperTypeName + querySearchFormat(RequestSuperTypeUnescapedName), "super_type_id");
        RequestUnescapedName = "Test " + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_EntityType_ValidRequest.json");
        Request.put("UnescapedName", RequestUnescapedName);
        Request.put("SuperTypeId", Long.parseLong(superTypeID));
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_CREATED);
    }
}
