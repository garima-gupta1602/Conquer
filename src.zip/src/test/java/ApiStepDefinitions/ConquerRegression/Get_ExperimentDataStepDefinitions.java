package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class Get_ExperimentDataStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestSampleType;
    String ResourcePath = "/Experiment_Data";
    String ResponseExperimentDataId = "";
    JSONArray jsonArry;
    String RequestName;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for get request of Experiment_Data")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Event() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for Experiment_Sample");
        Readprerequest();
    }
    @When("Create a GET request for newly created record and send the GET Request")
    public void Create_a_GET_request_for_newly_created_record_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for newly created record and send the GET Request");
        RequestName = "TEST" + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_ExperimentData_ValidRequest.json");
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentSample, HttpURLConnection.HTTP_CREATED);
        String ResponseBarcode = GetattributefromResponse(Response, "Barcode");
        stringResponse = GetRequest(ApiConstants.Route_ExperimentSample+"('"+ResponseBarcode+"')","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with experiment_data table")
    public void verify_response_with_experiment_sample_table() throws Exception {
        reportInstance.logPass("experiment_data record found with experiment_sample_id: ","'"+RequestSampleType);
        ResponseExperimentDataId = GetattributefromResponse(Response, "Id");
        String dbExperimentDataId =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentDataId + querySearchFormat(ResponseExperimentDataId), "experiment_data_id");
        if (!dbExperimentDataId.equals(""))
            reportInstance.logPass("experiment_data_id: "+ResponseExperimentDataId+ "and record_id: "+ ResponseExperimentDataId, " are found in the db");
        else
            reportInstance.logFail("experiment_data_id", " is not found in the db");
    }

    @When("Create a GET request for experiment_data and send the GET Request")
    public void Create_a_GET_request_for_experiment_data_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for experiment_data and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_ExperimentSample,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseExperimentDataId = GetattributefromResponse(Response, "Id");
    }

}
