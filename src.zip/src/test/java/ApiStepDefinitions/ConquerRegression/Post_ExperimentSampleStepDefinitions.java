package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Post_ExperimentSampleStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Enitity Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
    JSONObject Response;

    /** To Store UnEscapedName used in all the requests */
    String RequestName = "";

    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Experiment_Sample";
   /** Retrive entity_id for validation*/
    String ResponseExperimentSampleId = "";

    String created_on_DBDate ;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    /**
     * Preparation for creation of a new entity     type
     *
     * @throws Exception
     */
    @Given("Preparation for creation of a new experiment_sample_id")
    public void preparation_for_creation_of_a_new_experiment_sample_id() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "preparation_for_creation_of_a_new_experiment_sample_id");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity type "New Event "
         *
         * @param EntityPrefix
         *
         * @throws Exception
         */
        @When("Post a valid request for a creating new experiment_sample_id {string}")
        public void post_a_valid_request_for_a_creating_new_experiment_sample_id(String EntityPrefix) throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            RequestName = EntityPrefix + sharedFunctions.getRandomString(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Post_ExperimentSample_ValidRequest.json");
            Request.put("Name", RequestName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response = postRequest(Request.toString(), ApiConstants.Route_ExperimentSample, HttpURLConnection.HTTP_CREATED);
        }

    @Then("Verify the new record inserted in experiment_sample table")
    public void verify_the_new_record_inserted_in_experiment_sample_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseExperimentSampleId = GetattributefromResponse(Response, "Id");
        String dbExperimentSampleID =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentSampleIdOnExperimentSample + querySearchFormat(ResponseExperimentSampleId), "experiment_sample_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentSampleIdOnExperimentSample + querySearchFormat(ResponseExperimentSampleId), "created_on");
        if (ResponseExperimentSampleId.equals(dbExperimentSampleID)) {
            reportInstance.logPass("Sample_Type", " is created in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(ResponseExperimentSampleId, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
              }
            }else
            reportInstance.logFail("Experiment_Sample_Id", " is not created in the db");
        }
    @Then("Verify name as entity_name field is created in entity table in database")
    public void Verify_name_as_entity_name_field_is_created_in_entity_table_in_database() throws Exception {
        ResponseExperimentSampleId = GetattributefromResponse(Response, "Id");
        String dbSampleEntityID =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectExperimentSampleIdOnExperimentSample + querySearchFormat(ResponseExperimentSampleId), "experiment_sample_id");
        if (ResponseExperimentSampleId.equals(dbSampleEntityID))
            reportInstance.logPass("dbSampleEntityID:"+ dbSampleEntityID +"ResponseExperimentSampleId:"+ResponseExperimentSampleId, " is matched");
        else
            reportInstance.logFail("dbSampleEntityID:"+ dbSampleEntityID +"ResponseExperimentSampleId:"+ResponseExperimentSampleId, " is not matched");
    }
    @Then("Verify experiment_sample_id should be in long integer datatype format")
    public void Verify_experiment_sample_id_should_be_in_long_integer_datatype_format() throws Exception
    {
        if(sharedFunctions.isDisplayedLongRange(ResponseExperimentSampleId) && sharedFunctions.isIdDisplayedAfterSetSequence(ResponseExperimentSampleId,sharedFunctions.maxIntVal))
            reportInstance.logPass("event_id "+ResponseExperimentSampleId +" is generated within Long data type range", ":"+ ResponseExperimentSampleId);
        else
            reportInstance.logFail("event_id "+ResponseExperimentSampleId +"is not generated within Long data type range", ":"+ ResponseExperimentSampleId);
    }
}
