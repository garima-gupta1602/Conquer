package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Put_EventStepDefinitions  extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store RequestBarCode used in all the requests */
    String RequestName = "";


    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Event";
    String dbBarcode = "";
    String ResponseEntityId = "";
    String ResponseEventId = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity association
     *
     * @throws Exception
     */
    @Given("Preparation for updating an entity and event record")
    public void preparation_for_updating_an_entity_and_event_record() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "preparation_for_updating_an_entity_and_event_record");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity association for "BarCode"
         *
         * @throws Exception
         */
        @When("Put a valid request for a updating entity_name in entity")
        public void put_a_valid_request_for_a_updating_entity_name_in_entity() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            //Getting record from database entity table
            ResponseEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIDOfEvent, "entity_id");
            dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId),"Barcode");
            RequestName = "TEST" + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Put_Event_ValidRequest.json");
            Request.put("Name", RequestName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response=putRequest(Request.toJSONString(), ApiConstants.Route_Event.concat("('"+dbBarcode+"')"), HttpURLConnection.HTTP_OK);

        }

    /**
         * Verify the entity type with the unescaped name got created
         *
         * @throws Exception
         */
        @Then("Verify the entity_name got updated in response with entity table")
        public void verify_the_entity_name_got_updated_in_response_with_entity_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "Name", RequestName);
        }

    @Then("Verify name as entity_name field is updated in entity table and mapped with event table in database with current date")
    public void Verify_name_as_entity_name_field_is_updated_in_entity_table_and_mapped_with_event_table_in_database_with_current_date() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String entity_name =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");
        ResponseEventId = ExecuteQueryToGetExpectedColumn(DbQueries.selectEventIdFromEntityEvent+ querySearchFormat(ResponseEntityId), "event_id");
        String updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "updated_on");
        ResponseEventId = ExecuteQueryToGetExpectedColumn(DbQueries.selectEventIdFromEvent+ querySearchFormat(ResponseEventId), "event_id");

        if (entity_name.equals(RequestName)) {
            reportInstance.logPass("Entity_Name", " is created in the db");
            if(!(updated_on_DBDate.equals("")) || (updated_on_DBDate!=null)) {
                if (updated_on_DBDate.split("\\.")[0].contains(todaysDateStr))
                    reportInstance.logPass(ResponseEntityId, " is updated in the db on " + updated_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not updated in the db on " + updated_on_DBDate);
            }else
              reportInstance.logFail("updated_on_DBDate", "field not found in DB due to DB error");
        }else
            reportInstance.logFail("Entity", " is not updated in the db");
       }
    @Then("Verify the response with error code {string} and message as {string} for ID")
    public void Verify_the_response_with_error_code_and_message_as_for_id(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

    @When("Put a request for a new entity type with {string} for column ID")
    public void Put_a_request_for_a_new_entity_type_with_for_column_ID(String EntityPrefix) throws Exception {
        ResponseEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveEntityIDOfEvent, "entity_id");
        dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(ResponseEntityId),"Barcode");
        RequestName = EntityPrefix + RandomAlphanumericGenerate(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Put_Event_ValidRequest.json");
        Request.put("Name", RequestName);
        Request.put("Id", 9223372036854775808F);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response=putRequest(Request.toJSONString(), ApiConstants.Route_Event.concat("('"+dbBarcode+"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }
}
