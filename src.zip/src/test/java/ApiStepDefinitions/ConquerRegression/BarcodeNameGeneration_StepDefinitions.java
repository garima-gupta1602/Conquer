package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.sourceforge.htmlunit.corejs.javascript.regexp.SubString;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class BarcodeNameGeneration_StepDefinitions extends DBHelper {

    JSONObject Response;
    JSONObject Request_EntityType;
    String RequestUnescapedName;
    String RequestName;
    String ResponseEntityId;
    String dbEntityID;
    String created_on_DBDate;
    String seqNumber;
    String dbSeqNumber;
    String entity_type_id;
    String prefixVal;
    String responseBarcode;
    String responseName;
    String ResourcePath = "/BarcodeNameGeneration";
    String dbName;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the POST Request")
    public void Read_the_POST_Request() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the POST Request for ENTITY_TYPE with prefix more than 9 characters")
    public void Send_the_POST_Request_for_Entity_Type_with_prefix_more_than_9_characters() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_EntityType_ValidRequest.json");
        RequestUnescapedName  = "TESTING" + SharedFunctionsInTest.getRandomString(4);
        Request.put("UnescapedName",RequestUnescapedName);
        Request.put("Prefix",RequestUnescapedName);
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Send the POST Request for CONCENTRATION")
    public void Send_the_POST_Request_for_CONCENTRATION() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_Concentration_ValidRequest.json");
        RequestName  = "TEST CONCENTRATION " + RandomAlphanumericGenerate(4);
        Request.put("Name",RequestName);
        Response = postRequest(Request.toString(), ApiConstants.Route_CONCENTRATION, HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the newly created barcode inserted in entity table")
    public void verify_the_newly_created_barcode_inserted_in_entity_table() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        dbEntityID =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectAuditLogId + querySearchFormat(ResponseEntityId), "created_on");
        if (!dbEntityID.equals("")) {
            reportInstance.logPass("Verify the newly created barcode inserted in entity table", " in the db");
            if(!(created_on_DBDate.equals("")) || (created_on_DBDate!=null)) {
                if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                    reportInstance.logPass(dbEntityID, " is created in the db on " + created_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
            }
        }else
            reportInstance.logFail("Audit_Log_id", " is not created in the db");
    }
    @When("Send the POST Request for ANIMAL_SUBJECT")
    public void Send_the_POST_Request_for_ANIMAL_SUBJECT() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_AnimalSubject_ValidRequest.json");
        RequestName  = "ANIMAL SUBJECT " + RandomAlphanumericGenerate(4);
        Request.put("Name",RequestName);
        Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT, HttpURLConnection.HTTP_CREATED);
    }

    @When("Send the POST Request for ANIMAL_SUBJECT without name")
    public void Send_the_POST_Request_for_ANIMAL_SUBJECT_without_name() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_AnimalSubject_WithoutName_ValidRequest.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT, HttpURLConnection.HTTP_CREATED);
    }
    @When("Send the POST Request for BODY_WEIGHT_ON_STUDY")
    public void Send_the_POST_Request_for_Body_Weight_On_Study() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_BodyWeightOnStudy_ValidRequest.json");
        RequestName  = "BODY_WEIGHT " + SharedFunctionsInTest.getRandomString(4);
        Request.put("Name",RequestName);
        Response = postRequest(Request.toString(), ApiConstants.Route_BODY_WEIGHT_ON_STUDY, HttpURLConnection.HTTP_CREATED);
    }

    @When("Send the POST Request for duplicate Entity Type request")
    public void Send_the_POST_Request_for_duplicate_Entity_Type_request() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_EntityType_ValidRequest.json");
        RequestUnescapedName  = "TEST" + SharedFunctionsInTest.getRandomString(4);
        Request.put("UnescapedName",RequestUnescapedName);
        Request.put("Prefix",RequestUnescapedName);
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_CREATED);
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Send the POST Request for ENTITY_TYPE with prefix less than 2 characters")
    public void Send_the_POST_Request_for_Entity_Type_with_prefix_less_than_2_characters() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_EntityType_ValidRequest.json");
        RequestUnescapedName  = "TESTING" + SharedFunctionsInTest.getRandomString(4);
        Request.put("UnescapedName",RequestUnescapedName);
        Request.put("Prefix",SharedFunctionsInTest.getRandomString(1));
        Response = postRequest(Request.toString(), ApiConstants.Route_ENTITY_TYPE, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Send the POST Concentration Request with name as blank")
    public void Send_the_POST_Concentration_Request_with_name_as_blank() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_Concentration_ValidRequest.json");
        RequestName  = "";
        Request.put("Name",RequestName);
        Response = postRequest(Request.toString(), ApiConstants.Route_CONCENTRATION, HttpURLConnection.HTTP_CREATED);
    }

    @When("Send the POST Concentration Request for name as null value")
    public void Send_the_POST_Concentration_Request_for_name_as_null_value() throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/Post_Concentration_ValidRequest.json");
        RequestName  = null;
        Request.put("Name",RequestName);
        Response = postRequest(Request.toString(), ApiConstants.Route_CONCENTRATION, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the response with error code {string} and message as {string} for Barcode generation")
    public void verify_the_response_with_error_code_and_message_as_for_Barcode_generation(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }
    @Then("Verify prefix value in entity type followed by sequence no")
    public void verify_prefix_value_in_entity_type_followed_by_sequence_no() throws Exception {
        responseBarcode = GetattributefromResponse(Response, "Barcode");
        seqNumber = GetattributefromResponse(Response, "Sequence");
        dbSeqNumber = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "seq");
        entity_type_id = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_type_id");
        prefixVal= ExecuteQueryToGetExpectedColumn(DbQueries.selectEntityTypePrefix + querySearchFormat(entity_type_id), "Prefix");

        if (dbSeqNumber.equals(seqNumber))
            reportInstance.logPass("sequence in entity table matched", " in the db");
        else
            reportInstance.logFail("Record", " is not created in the db on " + created_on_DBDate);
       if(!prefixVal.equals("")) {
           if (responseBarcode.contains(prefixVal.split("#")[0]))
               reportInstance.logPass("Prefix " + prefixVal + " of barcode is matched", " in the db");
           else
               reportInstance.logFail("Prefix", prefixVal + " is not matched in the db ");
       }else
           reportInstance.logFail("Prefix", prefixVal + " is not found in the db ");
    }
    @Then("Verify Zero padding should be appended in barcode")
    public void verify_zero_value_padding_should_be_appended_in_barcode() throws Exception {
        System.out.print("prefixVal:"+prefixVal);
        String zeroAppendedBarcode= "";
        zeroAppendedBarcode = prefixVal.split("#")[0]+"000"+seqNumber;
        if(zeroAppendedBarcode.equals(responseBarcode))
            reportInstance.logPass("Zero padding is appending in barcode "+zeroAppendedBarcode, " in the db");
        else
            reportInstance.logFail("Zero padding is not appending in barcode ", zeroAppendedBarcode );
    }

    @Then("Verify Zero padding should be appended in name")
    public void verify_zero_value_padding_should_be_appended_in_name() throws Exception {
        String zeroAppendedName= "";
        System.out.print("prefixVal:"+prefixVal);
        responseName = GetattributefromResponse(Response, "Name");
        dbName =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(ResponseEntityId), "entity_name");
        zeroAppendedName = prefixVal.split("#")[0]+"000"+seqNumber;
        if(zeroAppendedName.equals(responseName) && (dbName.equals(responseName)))
            reportInstance.logPass("Zero padding is appending in name "+zeroAppendedName, " in the db");
        else
            reportInstance.logFail("Zero padding is not appending in name ", zeroAppendedName );
    }

    @Then("Verify the name should be same as barcode")
    public void verify_the_name_should_be_same_as_barcode() throws Exception {
        responseBarcode = GetattributefromResponse(Response, "Barcode");
        responseName = GetattributefromResponse(Response,"Name");
        dbEntityID =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveBarcode + querySearchFormat(responseBarcode), "entity_id");
        if (!dbEntityID.equals("")&&(responseName.equals(responseBarcode)))
            reportInstance.logPass("Name is same as barcode", " in the entity table of db");
       else
            reportInstance.logFail("Name is not same as barcode", " in the entity table of db");
    }
}
