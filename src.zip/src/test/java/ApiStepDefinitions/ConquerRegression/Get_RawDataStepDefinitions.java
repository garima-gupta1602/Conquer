package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class Get_RawDataStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestSampleType;
    String ResourcePath = "/Raw_Data";
    String ResponseRecordId = "";
    JSONArray jsonArry;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for get request of Raw_Data API")
    public void Read_the_URL_and_Set_Up_the_Headers_for_Event() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Read the URL and Set Up the Headers for Raw_Data");
        Readprerequest();
    }
    @When("Create a GET request for newly created record and send the GET Request of Raw_Data API")
    public void Create_a_GET_request_for_newly_created_record_and_send_get_request_of_Raw_Data_API() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for newly created record and send the GET Request of Raw_Data API");
        RequestSampleType = "TEST" + sharedFunctions.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_RawData_ValidRequest.json");
        Request.put("SAMPLE_TYPE", RequestSampleType);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_RAW_DATA, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response, "SAMPLE_TYPE", RequestSampleType);
        ResponseRecordId = GetattributefromResponse(Response, "Id");
        stringResponse = GetRequest(ApiConstants.Route_RAW_DATA+"("+ResponseRecordId+")","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify response with raw_data table")
    public void verify_response_with_raw_data_table() throws Exception {
        reportInstance.logPass("Raw_Data record found with Sample_Type: ","'"+RequestSampleType);
        ResponseRecordId = GetattributefromResponse(Response, "Id");
        RequestSampleType = GetattributefromResponse(Response, "SAMPLE_TYPE");
        String sampleType =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectRecordIDOnRawData + querySearchFormat(ResponseRecordId), "sample_type");
        if (sampleType.equals(RequestSampleType))
            reportInstance.logPass("Sample_Type: "+sampleType+ "and record_id: "+ResponseRecordId, " are found in the db");
        else
            reportInstance.logFail("record_id", " is not found in the db");
    }

    @When("Create a GET request for Raw_Data and send the GET Request")
    public void Create_a_GET_request_for_Raw_Data_and_send_get_request() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request for Raw_Data and send the GET Request");
        stringResponse = GetRequest(ApiConstants.Route_RAW_DATA,"");
        Response = StringToJSONObject(stringResponse);
        jsonArry = JSONObjectToJsonArray(Response,"value");
        Response = (JSONObject)jsonArry.get(0);
        ResponseRecordId = GetattributefromResponse(Response, "Id");
    }

}
