package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class Entity_Comment_StepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String idAttribute;
    String EntityCommentId;
    String ResponseCommentText;
    String todaysDateStr;
    String created_on_DBDate;
    String ResponseFileId;
    HttpURLConnection conn;
    String ResourcePath = "/Entity_Comment";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the URL and Set Up the Headers for entity_comment")
    public void Read_the_URL_and_Set_Up_the_Headers_for_entity_comment() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the GET Request for entity_comment_id {string}")
    public void Send_the_GET_Request_for_entity_comment_id(String routeparam) throws Exception {
        stringResponse=GetRequest(ApiConstants.Route_master+routeparam, "");
        Response=StringToJSONObject(stringResponse);
        JSONArray value = JSONObjectToJsonArray(StringToJSONObject(stringResponse), "value");
            String resp = value.get(0).toString();
            Response = StringToJSONObject(resp);
            idAttribute = GetattributefromResponse(Response, "Id");
            conn = SendRequest(ApiConstants.Route_master+routeparam+"("+idAttribute+")", "", DefaultRequestHeader(), "GET");
    }

    @Then("Validate the Response code for GET entity_comment_id")
    public void Validate_the_Response_code_for_GET_entity_comment_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_OK);
    }

    @Then("Validate the Response Body for GET entity_comment table")
    public void Validate_the_Response_Body_for_GET_entity_comment_table()  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "Id", idAttribute);
        EntityCommentId =GetattributefromResponse(Response, "Id");
        ResponseCommentText=GetattributefromResponse(Response, "COMMENT_TEXT");
        String dbCommentId =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityComment + querySearchFormat(EntityCommentId), "entity_comment_id");
        String dbCommentText =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityComment + querySearchFormat(EntityCommentId), "comment_text");
        if (dbCommentId.equals(EntityCommentId)&&dbCommentText.equals(ResponseCommentText))
            reportInstance.logPass("dbCommentId: "+dbCommentId+ "and dbCommentText: "+ dbCommentText, " are found in the db");
        else
            reportInstance.logFail("file record", " is not found in the db");
    }

    @When("Send the POST Request for entity_comment_id {string}")
    public void Send_the_POST_Request_for_entity_comment_id(String routeparam) throws Exception {
        JSONObject Request=ReadJsonInput(ResourcePath+"/POST_Entity_Comment.json");
        conn = SendRequest(ApiConstants.Route_master+routeparam, String.valueOf(Request), DefaultRequestHeader(), "POST");
    }

    @Then("Validate the Response code for POST entity_comment_id")
    public void Validate_the_Response_code_for_POST_entity_comment_id()  throws Exception {
        ValidateExceptedResponseCode(conn.getResponseCode(), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Validate the Response Body for POST entity_comment table {string}")
    public void Validate_the_Response_Body_for_POST_entity_comment_table(String entityName)  throws Exception {
        stringResponse=GetResponseBody(conn);
        Response=StringToJSONObject(stringResponse);
        VerifyEntityData(Response, "COMMENT_TEXT", entityName);
        todaysDateStr = sharedFunctions.todaysDate();
        ResponseFileId =GetattributefromResponse(Response, "Id");
        String dbFileId =  ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityComment + querySearchFormat(ResponseFileId), "entity_comment_id");
        created_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityComment + querySearchFormat(ResponseFileId), "created_on");
        if (!(dbFileId.equals("")) || (created_on_DBDate != null))
            reportInstance.logPass("file_Binary record", " is created in the db on " + created_on_DBDate);
        else
            reportInstance.logFail("file_Binary record", " is created in the db on " + created_on_DBDate);
        if (!(created_on_DBDate.equals("")) || (created_on_DBDate != null)) {
            if (created_on_DBDate.split(" ")[0].equals(todaysDateStr))
                reportInstance.logPass("file_Binary  is inserted into file_Binary  table and", " is created in the db on " + created_on_DBDate);
            else
                reportInstance.logFail("file_Binary ", " is created in the db on " + created_on_DBDate);
        }
    }

    @Then("Verify entity_comment_id should be in long integer format")
    public void Verify_entity_comment_id_should_be_in_long_integer_format() throws Exception {
        if (sharedFunctions.isDisplayedLongRange(ResponseFileId)&&sharedFunctions.isIdDisplayedAfterSetSequence(ResponseFileId,sharedFunctions.maxIntVal))
            reportInstance.logPass("record_id is generated within Long integer range", ":" + ResponseFileId);
        else
            reportInstance.logFail("record_id is not generated within long integer type range", ":" + ResponseFileId);
    }
}
