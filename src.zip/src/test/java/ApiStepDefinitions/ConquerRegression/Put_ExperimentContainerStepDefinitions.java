package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class Put_ExperimentContainerStepDefinitions extends DBHelper{
    /*
     * Copyright (c) 2020 Thermo Fisher Scientific
     * All rights reserved.
     */
    /**
     * To Create New Super Type Via ODATA step definition
     */

        /** To Store JSONOBJECT Response */
        JSONObject Response;

    /** To Store RequestEntityName used in all the requests */
    String RequestEntityName = "";
    String RequestBarCode = "";


    /** To Get the JSON DATA - Resource Path*/
    String ResourcePath = "/Experiment_Container";
    String experiment_container_id = "";
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();
    /**
     * Preparation for creation of a new entity association
     *
     * @throws Exception
     */
    @Given("Preparation for updating an experiment_container table record")
    public void preparation_for_updating_an_experiment_container_table_record() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            reportInstance = SharedClassApi.getReportInstance();
            reportInstance.logInfo("", "Preparation for updating an experiment_container table record");
            Readprerequest();
        }


        /**
         * Post a valid request for a creating new entity association for "BarCode"
         *
         * @throws Exception
         */
        @When("Put valid request for updating entity_name in entity table")
        public void put_valid_request_for_updating_entity_name_in_entity_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            //Getting record from database raw_data table
            experiment_container_id = ExecuteQueryToGetExpectedColumn(DbQueries.RetriveExperimentContainerId, "experiment_container_id");
            RequestBarCode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity+ querySearchFormat(experiment_container_id),"barcode");
            RequestEntityName = "TEST" + RandomAlphanumericGenerate(4);
            JSONObject Request = ReadJsonInput(ResourcePath + "/Put_ExperimentContainer_ValidRequest.json");
            Request.put("Name", RequestEntityName);
            reportInstance.logInfo("STEPS :", Request.toString());
            Response=putRequest(Request.toJSONString(), ApiConstants.Route_ExperimentContainer.concat("('"+ RequestBarCode +"')"), HttpURLConnection.HTTP_OK);
        }

    /**
         * Verify the entity type with the unescaped name got created
         *
         * @throws Exception
         */
        @Then("Verify given entity_name got updated in response with entity table")
        public void verify_given_entity_name_got_updated_in_response_with_entity_table() throws Exception
        {
            // Write code here that turns the phrase above into concrete actions
            VerifyEntityData(Response, "Name", RequestEntityName);
        }

    @Then("Verify entity_name field is updated with given name in entity table with current date")
    public void Verify_entity_name_field_is_updated_with_given_name_in_entity_table_with_current_date() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        String dbEntity_Name =  ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(experiment_container_id), "entity_name");
        String updated_on_DBDate = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(experiment_container_id), "updated_on");
        if (dbEntity_Name.equals(RequestEntityName)) {
            reportInstance.logPass("entity_name", " is updated in the db");
            if(!(updated_on_DBDate.equals("")) || (updated_on_DBDate!=null)) {
                if (updated_on_DBDate.split("\\.")[0].contains(todaysDateStr))
                    reportInstance.logPass(experiment_container_id, " is updated in the db on " + updated_on_DBDate);
                else
                    reportInstance.logFail("Record", " is not updated in the db on " + updated_on_DBDate);
            }else
              reportInstance.logFail("updated_on_DBDate", "field not found in DB due to DB error");
        }else
            reportInstance.logFail("Record", " is not updated in the db");
       }
    @Then("Verify the Put response with error code {string} and message as {string} for Name")
    public void Verify_the_Put_response_with_error_code_and_message_as_for_name(String Code, String Message) throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        VerifyErrorMessage(Response, Code, Message);
    }

    @When("Put a request for experiment_container with null name field")
    public void Put_a_request_for_experiment_container_with_null_name_field() throws Exception {
        JSONObject Request = ReadJsonInput(ResourcePath + "/Put_ExperimentContainer_ValidRequest.json");
        Request.put("Name", null);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response=putRequest(Request.toJSONString(), ApiConstants.Route_ExperimentContainer.concat("('"+ RequestBarCode +"')"), HttpURLConnection.HTTP_BAD_REQUEST);
    }
}
