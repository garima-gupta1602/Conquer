package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import org.springframework.http.ResponseEntity;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class EntityCreationFlow_StepDefinitions extends DBHelper {

    JSONObject Response;
    JSONObject Request_EntityType;
    String RequestUnescapedName;
    String RequestName;
    String ResponseEntityCommentId;
    String dbEntityID;
    String dbEventIDFromCommentTbl;
    String dbEventIDFromEventTbl;
    String created_on_DBDate;
    String seqNumber;
    String dbSeqNumber;
    HttpURLConnection conn;
    String entity_type_id;
    String prefixVal;
    String responseBarcode;
    String ResponseEntityId;
    String CommentResourcePath = "/Entity_Comment";
    String ResourcePath = "/Entity_Creation_Flow";
    String dbEntityIDFromEntity;
    String dbValueId, dbEntityEventId, dbEntityAssociationId;
    SharedFunctionsInTest sharedFunctions = new SharedFunctionsInTest();

    @Given("Read the POST Request for entity creation flow")
    public void Read_the_POST_Request() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the POST request for Comment API with valid inputs")
    public void Send_the_POST_request_for_Comment_API_with_valid_inputs() throws Exception {
        JSONObject Request = ReadJsonInput(CommentResourcePath + "/POST_Entity_Comment.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_COMMENT, HttpURLConnection.HTTP_CREATED);
    }

    @Then("Validate the record inserted in entity_comment, entity, entity_association, value, event tables")
    public void Validate_the_record_inserted_in_entity_Comment_and_entity_association_value_event_tables() throws Exception {
        String todaysDateStr = sharedFunctions.todaysDate();
        ResponseEntityCommentId = GetattributefromResponse(Response, "Id");
        dbEntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityComment + querySearchFormat(ResponseEntityCommentId), "entity_id");
        dbEntityIDFromEntity = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(dbEntityID), "entity_id");
        dbEventIDFromCommentTbl = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityComment + querySearchFormat(ResponseEntityCommentId), "event_id");
        dbValueId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectValueId + querySearchFormat(dbEntityID), "value_id");
        dbEntityEventId = ExecuteQueryToGetExpectedColumn(DbQueries.selectEventIdFromEntityEvent + querySearchFormat(dbEntityID), "entity_event_id");
        dbEntityAssociationId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityAssociation + querySearchFormat(dbEntityID), "entity_association_id");
        if ((dbEntityIDFromEntity.equals(dbEntityID)) && (!dbEventIDFromCommentTbl.equals("")))
            reportInstance.logPass("Records got inserted in entity_comment, entity and event tables", " in the db");
        else
            reportInstance.logFail("Records not inserted in entity_comment, entity and event tables", " in the db");
        if ((!dbValueId.equals("")) && (!dbEntityEventId.equals("")) && (!dbEntityAssociationId.equals("")))
            reportInstance.logPass("Records got inserted in entity_association, value, entity_event tables", " in the db");
        else
            reportInstance.logFail("Records not inserted in entity_association, value, entity_event tables", " in the db");
    }

    @Then("Verify the response with error code {string} and message as {string} for Entity Creation flow")
    public void verify_the_response_with_error_code_and_message_as_for_Entity_Creation_flow(String Code, String Message) throws Exception {
        reportInstance.logInfo("", "Verify the error message and error code");
        VerifyErrorMessageWithinDetails(Response, "3000", "Error creating entity", Code, Message);
    }

    @When("Send the POST Request with missing mandatory navigation property")
    public void Send_the_POST_Request_with_missing_mandatory_navigation_property() throws Exception {
        JSONObject Request = ReadJsonInput(CommentResourcePath + "/POST_EntityComment_MissingMandatoryNavigation.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_COMMENT, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Send the POST Request with missing mandatory attributes")
    public void Send_the_POST_Request_with_missing_mandatory_attributes() throws Exception {
        JSONObject Request = ReadJsonInput(CommentResourcePath + "/POST_EntityComment_MissingMandatoryAttribute.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_COMMENT, HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @When("Send the POST Request with duplicate navigation property")
    public void Send_the_POST_Request_with_duplicate_navigation_property() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestName = "Animal Subject Access"+ SharedFunctionsInTest.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_AnimalSubjectAccess_ValidRequest.json");
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST,HttpURLConnection.HTTP_CREATED);
    }

    @When("Send the POST Request with missing navigation property")
    public void Send_the_POST_Request_with_missing_navigation_property() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestName = "Animal Subject Access"+ SharedFunctionsInTest.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_AnimalSubjectAccess_MissingNavigation.json");
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST,HttpURLConnection.HTTP_CREATED);
    }

    @When("Send the POST Request with missing attributes")
    public void Send_the_POST_Request_with_missing_attributes() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        RequestName = "Beer_Batch"+ SharedFunctionsInTest.getRandomString(4);
        JSONObject Request = ReadJsonInput(ResourcePath + "/Post_BeerBatch_ValidRequest.json");
        Request.put("Name", RequestName);
        reportInstance.logInfo("STEPS :", Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_BeerBatch,HttpURLConnection.HTTP_CREATED);
    }


    @Then ("Verify duplicate record is not inserted into entity table")
    public void Verify_duplicate_record_is_not_inserted_into_entity_table() throws Exception{
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        HashMap results=ExecuteQuery(DbQueries.RetrieveEntityID+querySearchFormat(RequestName));
        int DbValue=results.size();
        if(DbValue==1)
            reportInstance.logPass("Successfully entry in DB",RequestName);
        else
            reportInstance.logFail("Not entered in DB",RequestName);
       }
    @Then ("Verify entity, entity association and value table for newly created records")
    public void Verify_entity_entity_association_and_value_table_for_newly_created_records() throws Exception{
        ResponseEntityId = GetattributefromResponse(Response, "Id");
        dbEntityID = ExecuteQueryToGetExpectedColumn(DbQueries.RetrieveEntityID + querySearchFormat(RequestName), "entity_id");
        dbValueId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectValueId + querySearchFormat(dbEntityID), "value_id");
        dbEntityAssociationId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityAssociation + querySearchFormat(dbEntityID), "entity_association_id");
        if ((!dbValueId.equals("")) && (!dbEntityAssociationId.equals("")))
            reportInstance.logPass("Records got inserted in entity_association and value tables", " in the db");
        else
            reportInstance.logFail("Records not inserted in entity_association and value tables", " in the db");

    }
}