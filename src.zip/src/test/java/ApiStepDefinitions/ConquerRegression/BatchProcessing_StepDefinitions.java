package ApiStepDefinitions.ConquerRegression;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;

public class BatchProcessing_StepDefinitions extends DBHelper {


    String ResourcePath = "src/test/resources/YETI/Entity_Creation_Flow/BatchProcessing";
    HttpURLConnection Conn;
    String BatchResponse ;
    @Given("Read the POST Request for Batch Processing")
    public void Read_the_POST_Request_for_batch_processing() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Send the POST Request for {string} processing")
    public void Send_the_valid_POST_Request_for_processing(String param) throws Exception {
        JSONObject Request = null;
        String txtpath = "", body;
        if (param.equalsIgnoreCase("One changeset successful"))
            txtpath = ResourcePath + "/Post_BatchProcessing_OneChangesetSuccessful.txt";

        if (param.equalsIgnoreCase("One changeset with failure"))
            txtpath = ResourcePath + "/Post_BatchProcessing_OneChangesetWithFailure.txt";

        if (param.equalsIgnoreCase("Multiple chagesets successful"))
            txtpath = ResourcePath + "/Post_BatchProcessing_MultipleChagesetsSuccessful.txt";

        if (param.equalsIgnoreCase("Multiple change set successful and failure"))
            txtpath = ResourcePath + "/Post_BatchProcessing_MultipleChangeSetSuccessfulAndFailure.txt";

        if (param.equalsIgnoreCase("Multiple change sets all failure"))
            txtpath = ResourcePath + "/Post_BatchProcessing_MultipleChangeSetsAllFailure.txt";

        if (param.equalsIgnoreCase("One change sets with trigger successful"))
            txtpath = ResourcePath + "/Post_BatchProcessing_OneChangesetsWithTriggerSuccessful.txt";

        if (param.equalsIgnoreCase("One change set with trigger failure"))
            txtpath = ResourcePath + "/Post_BatchProcessing_OneChangesetWithTriggerFailure.txt";

        if (param.equalsIgnoreCase("Multiple changesets with trigger all successful"))
            txtpath = ResourcePath + "/Post_BatchProcessing_MultipleChangesetsWithTriggerAllSuccessful.txt";

        if (param.equalsIgnoreCase("Multiple changesets with trigger all failure"))
            txtpath = ResourcePath + "/Post_BatchProcessing_MultipleChangesetsWithTriggerAllFailure.txt";

        if (param.equalsIgnoreCase("Multiple changesets with trigger successful and failure"))
            txtpath = ResourcePath + "/Post_BatchProcessing_MultipleChangesetsWithTriggerSuccessfulAndFailure.txt";

        body = readEntireText(txtpath);

        BatchResponse = postBatchRequest(body, ApiConstants.Route_BatchRequest,  UpdateRequestHeader("Content-Type","multipart/mixed; boundary=batch_43be9f41-ef52-44f6-8a3a-779859f2daf7"), HttpURLConnection.HTTP_OK);

    }

    @Then("Validate the Response Body in entity and entity_association table in the database")
    public void Validate_the_response_body_in_entity_and_entity_association_table_in_the_database() throws Exception {
        reportInstance.logInfo("Then: ", "Validate the Response Body in entity and entity_association table in the database");
        ArrayList<String> entityArray = SharedFunctionsInTest.convertStringToJsonArray(BatchResponse,true);
        for (int i = 0; i < entityArray.size(); i++) {
            String entitySet = entityArray.get(i).toString();
            String responseEntityID = SharedFunctionsInTest.getValueFromResponse(entitySet, "Id");
            String responseBarcode = SharedFunctionsInTest.getValueFromResponse(entitySet, "Barcode");
            String dbEntityId = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(responseEntityID), "entity_id");
            String dbBarcode = ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityIDFromEntity + querySearchFormat(responseEntityID), "barcode");
            if (dbEntityId.equals(responseEntityID) && dbBarcode.equals(responseBarcode))
                reportInstance.logPass("entityId: " + dbEntityId + "and dbBarcode: " + dbBarcode + "is present in entity table", " in the db");
            else
                reportInstance.logFail("entityId: " + dbEntityId + "and dbBarcode: " + dbBarcode + "is not present in entity table", " in the db");

            HashMap results = ExecuteQuery(DbQueries.SelectEntityAssociation + querySearchFormat(responseEntityID));
            if (results.size() >= 1)
                reportInstance.logPass(responseEntityID, " is created in entity_association table in db");
            else
                reportInstance.logFail(responseEntityID, " is not created in entity_association table in db");
        }
    }
    @Then("Validate the response Code {string} and error message {string} for batch processing")
      public void validate_the_response_code_and_error_message_for_batch_processing(String resErrCode, String errorMsg) throws Exception {
        ArrayList<String> entityErrArray = SharedFunctionsInTest.convertStringToJsonArray(BatchResponse,false);
        for (int i = 0; i < entityErrArray.size(); i++) {
            String entityErrSet = entityErrArray.get(i).toString();
            String errorCode = SharedFunctionsInTest.getValueFromResponse(entityErrSet, "Code");
            String resErrorMsg = SharedFunctionsInTest.getValueFromResponse(entityErrSet, "message");
            if (errorCode.equalsIgnoreCase(resErrCode) && errorMsg.equals(resErrorMsg))
                reportInstance.logPass(resErrCode +":" + errorMsg, " is displayed in response");
            else
                reportInstance.logFail(resErrCode +":" + errorMsg, " is displayed in response");
         }
    }
    public static String readEntireText(String path) {
        File content = new File(path);
        String fileContent="";
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(content);
            byte[] Value = new byte[(int) content.length()];
            fileInputStream.read(Value);
            fileInputStream.close();
            fileContent = new String(Value, "UTF-8");

        } catch (IOException e) {

            e.printStackTrace();
        }
        return fileContent;
    }
 }


