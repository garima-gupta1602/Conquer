/*
 * Copyright (c) 2020 Thermo Fisher Scientific
 * All rights reserved.
 */


package ApiStepDefinitions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import java.net.HttpURLConnection;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.api.RequestHeaders;
import com.db.DBHelper;

import com.mongodb.util.JSON;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.junit.Assert;

import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import YETI.DbQueries;

import static ApiStepDefinitions.SharedClassApi.escapeName;
import static ApiStepDefinitions.SharedClassApi.retrieveResponseBody;


/**
 * TODO: Class description
 */
public class JWTToken extends DBHelper
{
    /**
     * TODO: Field description
     */
    JSONObject Response = new JSONObject();
    private SharedAttributes sharedAttributes;
    private static final String DECODED_JWT_BODY = "/jwt/DecodedJWTBody.json";
    private static final String DECODED_JWT_HEADER = "/jwt/DecodedJWTHeader.json";
    private static final String INVALID_CREDENTIAL_ERROR_MESSAGE = "User's credentials are invalid.";

    /**
     * TODO: Field description
     */
    JSONParser parseJson = new JSONParser();

    /**
     * TODO: Constructs ...
     *
     * @param share
     * @throws Exception
     */
    public JWTToken(SharedAttributes share) throws Exception
    {
        this.sharedAttributes = share;
        Readprerequest();
        this.reportInstance = SharedClassApi.getReportInstance();
    }

    /**
     * TODO: Method description
     *
     * @throws Exception
     */
    @Given("Preparation for authenticating and authorizing with JWT token is done")
    public void preparationForAuthenticatingAndAuthorizingWithJWTTokenIsDone() throws Exception
    {
        Readprerequest();
        reportInstance = SharedClassApi.getReportInstance();
    }


    /**
     * TODO: Method description
     *
     * @param entityTypeName
     * @param globalUserId
     * @param email
     * @param fullName
     * @throws Exception
     */
    @When("GET request to retrieve entities of entity type {string} by employee with global user id {string}, email {string}, and full name {string}")
    public void getRequestToRetrieveEntitiesOfEntityTypeByEmployeeWithGlobalUserIdEmailAndName(String entityTypeName, String globalUserId, String email, String fullName) throws Exception
    {
        try
        {
            String url = String.format("entity-service/odata/%s", entityTypeName);
            reportInstance.logInfo("GET Request ", String.format("with url %s", url));

            HashMap header = new HashMap();
            JSONObject jwtBody = ReadJsonInput(DECODED_JWT_BODY);
            JSONObject jwtHeader = ReadJsonInput(DECODED_JWT_HEADER);
            header.put(HttpHeaders.CONTENT_TYPE, RequestHeaders.Header_Content_Type);
            header.put(HttpHeaders.ACCEPT, RequestHeaders.Header_Accept);
            header
            .put("Authorization", "Bearer " + encodeString(jwtHeader.toString()) + "." + encodeString(jwtBody.toJSONString().replace("{subAnchor}",
                    encodeString(globalUserId + " pic_cdc")).replace("{emailAnchor}", email).replace("{fullNameAnchor}", fullName)));
            System.out
            .println(String
            .format("Escaped JWT token: %s",
                    "Bearer " + encodeString(jwtHeader.toString()) + "." + encodeString(jwtBody.toJSONString().replace("{subAnchor}",
                            encodeString(globalUserId + " pic_cdc")).replace("{emailAnchor}", email).replace("{fullNameAnchor}", fullName))));

            HttpURLConnection con = SendRequest(url, StringUtils.EMPTY, header, HttpMethod.GET.name());
            sharedAttributes.connection = con;
            String body = retrieveResponseBody(con);
            sharedAttributes.customAttributes.put("responseBody", body);
            System.out.println(String.format("Response status code:\n%s", con.getResponseCode()));
            System.out.println(String.format("Response header:\n%s", con.getHeaderFields().toString()));
            System.out.println(String.format("Response body:\n%s", body));
            reportInstance.logPass("STEP - GET request with the response","");
            reportInstance.logInfo(String.format("Status code: %d", con.getResponseCode()), "");
            reportInstance.logInfo(String.format("Header: %s", con.getHeaderFields().toString()), "");
            reportInstance.logInfo(String.format("Body: %s", body), "");
        }
        catch (Exception ex)
        {
            reportInstance.logFail("STEP - GET request got error with the exception ", String.format("%s", ex.getMessage()));
        }
    }

    /**
     * TODO: Method description
     *
     * @param entityTypeName
     * @throws IOException
     * @throws ParseException
     */
    @Then("Verify the response contains correct entity type {string}")
    public void verifyTheResponseContainsCorrectEntityType(String entityTypeName) throws IOException, ParseException
    {
        JSONArray value = new JSONArray();
        if (sharedAttributes.customAttributes.get("responseBody").toString().matches("^\\{.*\\}$")
                && sharedAttributes.customAttributes.get("responseBody").toString().contains("value"))
        {
            value = (JSONArray)((JSONObject)parseJson.parse(sharedAttributes.customAttributes.get("responseBody").toString())).get("value");
        }

        if (value.size() <= 0)
        {
            reportInstance.logFail("Expected that number for entities must be greater than 0, ", String.format("actual size is %s", value.size()));
            Assert.fail();
        }

        Boolean isCorrectEntityType = true;
        String wrongEntityTypeName = StringUtils.EMPTY;
        for (int i = 0; i < value.size(); i++)
        {
            String name = ((JSONObject)value.get(i)).get("EntityTypeName").toString();
            if (!name.equals(escapeName(entityTypeName)))
            {
                isCorrectEntityType = false;
                wrongEntityTypeName = name;
            }
        }

        if (isCorrectEntityType.equals(false))
        {
            reportInstance.logFail(String.format("STEP - Verify entity type name: Wrong entity type name, expected %s", escapeName(entityTypeName)), String.format("actual %s", wrongEntityTypeName));
            System.out.println(String.format("Wrong entity type name, expected %s, actual %s", escapeName(entityTypeName), wrongEntityTypeName));
            Assert.fail();
        }
        else
        {
            reportInstance.logPass(String.format("STEP - Verify entity type name: Correct entity type name, expected %s", escapeName(entityTypeName)), String.format("actual %s", wrongEntityTypeName));
            System.out.println(String.format("Correct entity type name, expected %s, actual %s", escapeName(entityTypeName), escapeName(entityTypeName)));
        }
    }

    /**
     * TODO: Method description
     *
     * @param numberOfEmployees
     * @param globalUserId
     * @param email
     * @param fullName
     * @throws Exception
     */
    @Then("Verify {int} employee created under database with global user id {string}, email {string}, and full name {string}")
    public void verifyEmployeeCreatedUnderDatabaseWithGlobalUserIdEmailAndFullName(int numberOfEmployees, String globalUserId, String email, String fullName) throws Exception
    {
        Integer results = Integer
                          .parseInt(ExecuteQueryToGetExpectedColumn(DbQueries.IS_EMPLOYEE_EXISTENT
                          .replace("{globalUserIdAnchor}", globalUserId)
                          .replace("{emailAnchor}", email)
                          .replace("{fullNameAnchor}", fullName),
                                  "number_employee"));
        if (results != numberOfEmployees)
        {
            reportInstance.logFail(String.format("STEP - Verify number of employees: %s employee(s) in the database,", results.toString()), String.format("expected %d", numberOfEmployees));
            System.out.println(String.format("%s employee(s) in the database, expected %d", results.toString(), numberOfEmployees));
            Assert.fail();
        }
        else
        {
            reportInstance.logPass(String.format("STEP - Verify number of employees: %s employee(s) in the database,", results.toString()), String.format("expected %d", numberOfEmployees));
            System.out.println(String.format("%s employee(s) in the database, expected %d", results.toString(), numberOfEmployees));
        }
    }

    /**
     * TODO: Method description
     *
     * @param statusCode
     *
     * @throws IOException
     */
    @Then("Verify status code is {int}")
    public void verifyStatusCodeIs(int statusCode) throws Exception
    {
        ValidateExceptedResponseCode(sharedAttributes.connection.getResponseCode(), statusCode);
    }

    /**
     * TODO: Method description
     *
     * @throws IOException
     */
    @Then("Verify the response contains correct error message for user with invalid credential")
    public void verifyTheResponseContainsCorrectErrorMessageForUserWithInvalidCredential() throws IOException
    {
        if (sharedAttributes.customAttributes.get("responseBody").toString().equals(INVALID_CREDENTIAL_ERROR_MESSAGE))
        {
            System.out.println(String.format("Actual error message: %s matches with expected error message: %s", sharedAttributes.customAttributes.get("responseBody").toString(), INVALID_CREDENTIAL_ERROR_MESSAGE));
            reportInstance.logPass(String.format("Actual error message: %s matches with ", sharedAttributes.customAttributes.get("responseBody").toString()), String.format("expected error message: %s", INVALID_CREDENTIAL_ERROR_MESSAGE));
        }
        else
        {
            System.out.println(String.format("Actual error message: %s does not match with expected error message: %s", sharedAttributes.customAttributes.get("responseBody").toString(), INVALID_CREDENTIAL_ERROR_MESSAGE));
            reportInstance.logFail(String.format("Actual error message: %s does not match with ", sharedAttributes.customAttributes.get("responseBody").toString()), String.format("expected error message: %s", INVALID_CREDENTIAL_ERROR_MESSAGE));
            Assert.fail();
        }
    }

    /**
     * TODO: Method description
     *
     * @param entityTypeName
     *
     * @throws Exception
     */
    @Then("Verify the response contains error message about no permission on entity type {string}")
    public void verifyTheResponseContainsErrorMessageAboutNoPermissionOnEntityType(String entityTypeName) throws Exception
    {
        try{
            JSONObject actualJson = (JSONObject)parseJson.parse(sharedAttributes.customAttributes.get("responseBody").toString());
            VerifyErrorMessageWithinDetails(actualJson,"3003", "Error reading entity", "6000", String.format("You do not have access to the following: /(%s)", entityTypeName));
            reportInstance.logPass("STEP - ", String.format("Verify the response contains correct error message: %s", actualJson.toString()));
        }
        catch (Exception ex){
            System.out.println(String.format("Failed due to exception %s", ex.getMessage()));
            reportInstance.logFail(String.format("STEP - Verify the response contains error message: Failed due to an exception %s", ex.getMessage()), "");
            Assert.fail();
        }
    }

    /**
     * TODO: Method description
     *
     * @param key
     * @param value
     *
     * @throws IOException
     */
    @Then("Verify key {string} with value {string} exists in response header")
    public void verifyKeyWithValueExistsInResponseHeader(String key, String value) throws IOException
    {
        Map<String, List<String>> headers = sharedAttributes.connection.getHeaderFields();
        if (!headers.containsKey(key))
        {
            System.out.println(String.format("No key %s in response header", key));
            reportInstance.logFail(String.format("STEP - Verify key %s with value %s exists in response header. ", key, value), String.format("But no %s in response header", key));
            Assert.fail();
        }
        else
        {
            if (!headers.get(key).toString().contains(value))
            {
                System.out.println(String.format("Actual value: %s does not match with expected: ", headers.get(key).toString(), value));
                reportInstance.logFail(String.format("STEP - Verify key %s with value %s exists in response header. ", key, value), String.format("But incorrect value %s", headers.get(key).toString()));
                Assert.fail();
            }
        }
        reportInstance.logPass(String.format("STEP - Verify key %s with value %s exists in response header ", key, value), String.format(". Correct as expected"));
    }
}

