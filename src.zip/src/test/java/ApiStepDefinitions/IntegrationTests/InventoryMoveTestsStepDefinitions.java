package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class InventoryMoveTestsStepDefinitions extends DBHelper
{
    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions";


    @Given("Login into ODATA for Inventory Move Tests")
    public void login_into_odata_for_inventory_move_tests() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN ","Login into ODATA for Inventory Move Tests");
        Readprerequest();
    }
    @When("Send POST request to create new Sample with empty body")
    public void send_post_request_to_create_new_sample_with_empty_body() throws Exception
    {
        reportInstance.logInfo("WHEN ","Send POST request to create new Sample with empty body");
        Response=postRequest("{}", ApiConstants.Route_ENTITY_MASTER.concat(ApiConstants.inventory_move), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the error message for the empty body on the inventory move")
    public void verify_the_error_message_for_the_empty_body() throws Exception
    {
        reportInstance.logInfo("THEN ","Verify the error message for the empty body");
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_UPDATING_ENTITY, ApiConstants.ERROR_MESSAGE_UPDATING_ENTITY, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL,"One and only one of the following parameters has to be present in the request: locationId, locationBarcode, locationName.");
    }
    @When("Send POST request to create new Sample by Location Id")
    public void send_post_request_to_create_new_sample_by_location_id() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/InventoryMoveTestById.json");
        reportInstance.logInfo("WHEN ","Send POST request to create new Sample by Location Id");
        Response=postRequest(Request.toString(), ApiConstants.Route_ENTITY_MASTER.concat(ApiConstants.inventory_move), HttpURLConnection.HTTP_OK);
    }
    @Then("Verify the entity created on inventory move")
    public void verify_the_entity_created_on_inventory_move() throws Exception
    {
        reportInstance.logInfo("THEN ","Verify the error message for the empty body");
        VerifyEntityData(Response,"EntityTypeName","EMPLOYEE_LIMITED");
    }
    @When("Send POST request to create new Sample by Location Barcode")
    public void send_post_request_to_create_new_sample_by_location_barcode() throws Exception
    {
        reportInstance.logInfo("WHEN ","Send POST request to create new Sample by Location Id");
        JSONObject Request=ReadJsonInput(ResourcePath+"/InventoryMoveTestByBarcode.json");
        Response=postRequest(Request.toString(), ApiConstants.Route_ENTITY_MASTER.concat(ApiConstants.inventory_move), HttpURLConnection.HTTP_OK);
    }
    @When("Send POST request to create new Sample by Location Name")
    public void send_post_request_to_create_new_sample_by_location_name() throws Exception
    {
        JSONObject Request=ReadJsonInput(ResourcePath+"/InventoryMoveTestByName.json");
        reportInstance.logInfo("WHEN ","Send POST request to create new Sample by Location Id");
        Response=postRequest(Request.toString(), ApiConstants.Route_ENTITY_MASTER.concat(ApiConstants.inventory_move), HttpURLConnection.HTTP_OK);
    }
}
