package ApiStepDefinitions.IntegrationTests;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class FilteringWithCustomFunctionsStepDefinitions extends DBHelper {


    private static final String barcode_prop = "LC11";
    private static final String entity_name_prop = "LOCATION_LIMITED";
    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();


    @Given("Login into ODATA to FilteringWithCustomFunctions")
    public void Login_into_ODATA_to_FilteringWithCustomFunctions() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA to FilteringWithCustomFunctions");
        Readprerequest();
    }

    @When("Create a GET request to Filter By Barcode And ExistsWithinLocation")
    public void Create_a_GET_request_to_Filter_By_Barcode_And_ExistsWithinLocation() throws Exception {
        String endpointurl = ApiConstants.Route_ENTITY_MASTER+ "?$filter=" + URLEncoderForRequests("Barcode eq 'LC11' and pfs.ExistsWithinLocation(locationBarcode='LC6')");
        reportInstance.logInfo("STEPS : ", "GET request to Filter By Barcode And ExistsWithinLocation");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify Filter By Barcode And ExistsWithinLocation")
    public void Verify_Filter_By_Barcode_And_ExistsWithinLocation() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify Filter By Barcode And ExistsWithinLocation");
        while (Response.size() > 0) {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            for (int i = 0; i < resp.size(); i++) {
                String firstresp = resp.get(i).toString();
                Response = StringToJSONObject(firstresp);
                VerifyEntityData(Response, "Barcode", barcode_prop);
                VerifyEntityData(Response, "EntityTypeName", entity_name_prop);
            }
            break;
        }
    }
}