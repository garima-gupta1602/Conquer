package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class BreweryFilteringStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();


    @Given("Login into ODATA to BreweryFiltering")
    public void Login_into_ODATA_to_BreweryFiltering() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA to BreweryFiltering");
        Readprerequest();
    }

    @When("Create a GET request to Filter by IndexOf with zero")
    public void Create_a_GET_request_to_Filter_by_IndexOf_with_zero() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter by IndexOf with zero");
        String endpointurl = ApiConstants.Route_NURSE + "?$filter=" + URLEncoderForRequests("indexof(Barcode,'NUR_') eq 0");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify Filter by IndexOf with zero")
    public void Verify_Filter_by_IndexOf_with_zero() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify Filter by IndexOf with zero");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String bar_entity = GetattributefromResponse(Response, "Barcode");
                if (bar_entity.startsWith("NUR_")) {
                    reportInstance.logPass(bar_entity, "- as expected");
                } else {
                    reportInstance.logFail(bar_entity, "- not as expected");
                }
            }
            break;
        }
    }

    @When("Create a GET request to Filter String attribute with eq null")
    public void Create_a_GET_request_to_Filter_String_attribute_with_eq_null() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter String attribute with eq null");
        String endpointurl = ApiConstants.Route_TEST_FILTER_NULL + "?$filter=" + URLEncoderForRequests("STRING_ATTRIBUTE eq null");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify Filter String attribute with eq null")
    public void Verify_Filter_String_attribute_with_eq_null() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify Filter String attribute with eq null");
        Object stratr = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    stratr = Response.get("STRING_ATTRIBUTE");
                    while (stratr == null) {
                        reportInstance.logPass((String) stratr, " - STRING_ATTRIBUTE null as expected");
                        break;
                    }
                }
            }

        } catch (Exception e) {
            this.reportInstance.logFail("STRING_ATTRIBUTE is empty", (String) stratr);
            throw e;
        }
    }

    @When("Create a GET request to Filter String attribute with not contains")
    public void Create_a_GET_request_to_Filter_String_attribute_with_not_contains() throws Exception {
        reportInstance.logInfo("STEPS : ", "Filter String attribute with not contains");
        String endpointurl = ApiConstants.Route_PROJECT + "?$filter=" + URLEncoderForRequests("not contains(Name,'End')");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify Filter String attribute with not contains")
    public void Verify_Filter_String_attribute_with_not_contains() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify Filter String attribute with not contains");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String name_entity = GetattributefromResponse(Response, "Name");
                if (name_entity.contains("End")) {
                    reportInstance.logFail(name_entity, "- not as expected");
                }
                reportInstance.logPass(name_entity, "- as expected");
            }

            break;
        }
    }
}


