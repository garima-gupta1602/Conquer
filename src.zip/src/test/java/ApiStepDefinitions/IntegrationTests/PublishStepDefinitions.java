package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class PublishStepDefinitions extends DBHelper
{
    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions";
    private String Publish_Experiment_PET1="('PET1')/pfs.Experiment.Publish";
    @Given("Login into ODATA to publish experiment super type")
    public void login_into_odata_to_publish_experiment_super_type() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to publish experiment super type");
        Readprerequest();

    }
    @When("Send POST request to publish new experiment with empty body")
    public void send_post_request_to_publish_new_experiment_with_empty_body() throws Exception
    {
        boolean check=StatusCheckOnPublish(ApiConstants.Route_EXPERIMENT.concat(ApiConstants.GET_Experiment_PET1));
        if(check)
        {
            Response = postRequest("{}", ApiConstants.Route_EXPERIMENT.concat(ApiConstants.UnPublish_Experiment_PET1), HttpURLConnection.HTTP_OK);
            VerifyEntityData(Response,"PUBLISHED","false");
        }

        reportInstance.logInfo("", "POST request to publish new experiment with empty body");
        Response = postRequest("{}", ApiConstants.Route_EXPERIMENT.concat(ApiConstants.Publish_Experiment_PET1), HttpURLConnection.HTTP_OK);

    }
    @Then("Verify the publish and unpublish the experiment")
    public void verify_the_entity_type_name_for_publish_experiment_test() throws Exception
    {
        reportInstance.logInfo("THEN","Verify the name for PUBLISH EXPERIMENT TEST");
        VerifyEntityData(Response, "EntityTypeName","PUBLISH_EXPERIMENT_TEST");
        VerifyEntityData(Response,"PUBLISHED","true");
        Response = postRequest("{}", ApiConstants.Route_EXPERIMENT.concat(ApiConstants.UnPublish_Experiment_PET1), HttpURLConnection.HTTP_OK);
        VerifyEntityData(Response,"PUBLISHED","false");
    }
    @When("Send POST request to publish new experiment with empty body for entity")
    public void send_post_request_to_publish_new_experiment_with_empty_body_for_entity() throws Exception
    {
        boolean check=StatusCheckOnPublish(ApiConstants.Route_PUBLISH_EXPERIMENT_TEST.concat(ApiConstants.GET_Experiment_Test_PET3));
        if(check)
        {
            Response = postRequest("{}", ApiConstants.Route_PUBLISH_EXPERIMENT_TEST.concat(ApiConstants.Unpublish_Experiment_Test_PET3), HttpURLConnection.HTTP_OK);
            VerifyEntityData(Response,"PUBLISHED","false");
        }

        reportInstance.logInfo("","POST request to publish new experiment with empty body");
        Response = postRequest("{}", ApiConstants.Route_PUBLISH_EXPERIMENT_TEST.concat(ApiConstants.Publish_Experiment_Test_PET3), HttpURLConnection.HTTP_OK);
    }
    @Then("verify the publish and unpublish experiment test for entity")
    public void verify_the_publish_and_unpublish_experiment_test_for_entity() throws Exception
    {
        reportInstance.logInfo("THEN","Verify the name for PUBLISH EXPERIMENT TEST for entity");
        VerifyEntityData(Response, "EntityTypeName","PUBLISH_EXPERIMENT_TEST");
        VerifyEntityData(Response,"PUBLISHED","true");
        Response = postRequest("{}", ApiConstants.Route_PUBLISH_EXPERIMENT_TEST.concat(ApiConstants.Unpublish_Experiment_Test_PET3), HttpURLConnection.HTTP_OK);
        VerifyEntityData(Response,"PUBLISHED","false");
    }
    @When("Send POST request to already published experiment")
    public void send_post_request_to_already_published_experiment() throws Exception
    {
        reportInstance.logInfo("","POST request to already published experiment");
        boolean check=StatusCheckOnPublish(ApiConstants.Route_EXPERIMENT.concat(ApiConstants.GET_Experiment_AlreadyScenario_PET4));
        if(check)
        {
            Response = postRequest("{}", ApiConstants.Route_Publish_Experiment_AlreadyScenario_PET4, HttpURLConnection.HTTP_BAD_REQUEST);
        }else
        {
            Response = postRequest("{}", ApiConstants.Route_Publish_Experiment_AlreadyScenario_PET4, HttpURLConnection.HTTP_OK);
            VerifyEntityData(Response,"PUBLISHED","true");
            Response = postRequest("{}", ApiConstants.Route_Publish_Experiment_AlreadyScenario_PET4, HttpURLConnection.HTTP_BAD_REQUEST);
        }
    }
    @Then("Verify the error message for the already published experiment")
    public void verify_the_error_message_for_the_already_published_experiment() throws Exception
    {
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_UPDATING_ENTITY, ApiConstants.ERROR_MESSAGE_UPDATING_ENTITY, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL,"The experiment specified is already published.");

    }
    @When("Send POST request to publish and unpublish new experiment with empty body")
    public void send_post_request_to_publish_and_unpubish_new_experiment_with_empty_body() throws Exception
    {
        reportInstance.logInfo("","POST request to publish new experiment with empty body");
        Response = postRequest("{}", ApiConstants.Route_Publish_Experiment_AlreadyScenario_PET4, HttpURLConnection.HTTP_OK);
        Response = postRequest("{}", ApiConstants.Route_Publish_Experiment_AlreadyScenario_PET4, HttpURLConnection.HTTP_OK);
    }
    /*@When("Send POST request to Unpublish experiment")
    public void send_post_request_Unpublish_experiment() throws Exception
    {
        reportInstance.logInfo("","POST request to unpublish experiment");
        Response = postRequest("{}", ApiConstants.Route_UnPublish_Experiment, HttpURLConnection.HTTP_OK);
    }
    @When("Send POST request to unpublished experiment for enity")
    public void send_post_request_to_unpublished_experiment_for_entity() throws Exception
    {
        reportInstance.logInfo("","POST request to unpublish experiment for entity");
        Response = postRequest("{}", ApiConstants.Route_UnPublish_Experiment_Test, HttpURLConnection.HTTP_OK);
    }

    @Then("Verify the entity type name for UNPUBLISH EXPERIMENT TEST")
    public void verify_the_entity_type_name_for_unpublish_experiment_test() throws Exception
    {
        reportInstance.logInfo("THEN","Verify the name for PUBLISH EXPERIMENT TEST");
        VerifyEntityData(Response, "EntityTypeName","PUBLISH_EXPERIMENT_TEST");
    }*/
    @When("Send POST request for not published experiment")
    public void send_post_request_for_not_published_experiment() throws Exception
    {
        reportInstance.logInfo("","POST request for not published experiment");
        Response = postRequest("{}", ApiConstants.Route_Publish_Experiment_Test_NotPublished_PET6, HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for the not published experiment")
    public void verify_the_error_message_for_the_not_published_experiment() throws Exception
    {
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_UPDATING_ENTITY, ApiConstants.ERROR_MESSAGE_UPDATING_ENTITY, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL,"The experiment specified is not published.");

    }

    public boolean StatusCheckOnPublish(String Route) throws Exception
    {
        boolean status=false;
        HttpURLConnection conn=SendRequest(Route,"{}",DefaultRequestHeader(),"GET");
        Response=ResponseOutput(conn, HttpStatus.SC_OK,false,new HashMap());
        String Statusofpublish=GetattributefromResponse(Response,"PUBLISHED");
        if(Statusofpublish.equalsIgnoreCase("true"))
        {
            status=true;
        }
        return status;
    }

}
