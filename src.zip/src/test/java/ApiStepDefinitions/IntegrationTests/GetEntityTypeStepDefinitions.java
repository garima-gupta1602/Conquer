package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class GetEntityTypeStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();
    private static final String EXPERIMENT_PROTOCOL_NAV_PROP_NAME = "EXPERIMENT_PROTOCOL";
    private static final String EXPERIMENT_ASSAY_NAV_PROP_NAME = "EXPERIMENT_ASSAY";

    @Given("Login into ODATA for Get entity type")
    public void Login_into_ODATA_for_Get_entity_type() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA for Get entity type");
        Readprerequest();
    }

    @When("Create a GET request for EXPERIMENT entity type with expanding TYPE_ASSOCIATIONS")
    public void Create_a_GET_request_for_EXPERIMENT_entity_type_with_expanding_TYPE_ASSOCIATIONS() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request for EXPERIMENT entity type with expanding TYPE_ASSOCIATIONS");
        stringResponse = GetRequest(ApiConstants.Route_Entity_Type+ApiConstants.Route_GetExperimentEntity, "TYPE_ASSOCIATIONS", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Entity Type Name for EXPERIMENT entity type with expanding TYPE_ASSOCIATIONS")
    public void Verify_the_Entity_Type_Name_for_EXPERIMENT_entity_type_with_expanding_TYPE_ASSOCIATIONS() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the Entity Type Name for EXPERIMENT entity type with expanding TYPE_ASSOCIATIONS");
        JSONArray typeAssociations = JSONObjectToJsonArray(Response, "TYPE_ASSOCIATIONS");
        for (int i = 0; i < typeAssociations.size(); i++) {
            JSONObject experimentProtocolTypeAssociation = null;
            JSONObject experimentAssayTypeAssociation = null;
            JSONObject typeAssociation = (JSONObject) typeAssociations.get(i);
            String context = (String) typeAssociation.get("Context");
            if (context.equals(EXPERIMENT_PROTOCOL_NAV_PROP_NAME)) {
                experimentProtocolTypeAssociation = typeAssociation;
            } else if (context.equals(EXPERIMENT_ASSAY_NAV_PROP_NAME)) {
                experimentAssayTypeAssociation = typeAssociation;
            }
            if (experimentProtocolTypeAssociation != null) {
                String exptprotocol = (String) experimentProtocolTypeAssociation.get("EscapedName");
                if (EXPERIMENT_PROTOCOL_NAV_PROP_NAME.equals(exptprotocol))
                    reportInstance.logPass("STEPS :", "EXPERIMENT_PROTOCOL verified");
            } else if (experimentAssayTypeAssociation != null) {
                String exptassy = (String) experimentAssayTypeAssociation.get("EscapedName");
                if (EXPERIMENT_ASSAY_NAV_PROP_NAME.equals(exptassy))
                    reportInstance.logPass("STEPS :", "EXPERIMENT_ASSAY verified");
            }
        }
    }

    @When("Create a GET request to Filter ENTITY_TYPE using Base Type Name")
    public void Create_a_GET_request_to_Filter_ENTITY_TYPE_using_Base_Type_Name() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter ENTITY_TYPE using Base Type Name");
        stringResponse = GetRequest(ApiConstants.Route_ENTITY_TYPE + "?$filter=", "Name eq 'EXPERIMENT_SAMPLE'", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Filter ENTITY_TYPE using Base Type Name")
    public void Verify_the_Filter_ENTITY_TYPE_using_Base_Type_Name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the Filter ENTITY_TYPE using Base Type Name");
        VerifyEntityData(Response, "value", "[]");
    }

    @When("Create a GET request to Filter ENTITY_TYPE by SuperTypeName not equal PFS side name")
    public void Create_a_GET_request_to_Filter_ENTITY_TYPE_by_SuperTypeName_not_equal_PFS_side_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter ENTITY_TYPE by SuperTypeName not equal PFS side name");
        stringResponse = GetRequest(ApiConstants.Route_ENTITY_TYPE + "?$filter=", "SuperTypeName ne 'DATA TYPE'", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Filter ENTITY_TYPE by SuperTypeName not equal PFS side name")
    public void Verify_the_Filter_ENTITY_TYPE_by_SuperTypeName_not_equal_PFS_side_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the Filter ENTITY_TYPE by SuperTypeName not equal PFS side name");
        reportInstance.logInfo("STEPS", "Verify the JsonArray for any attributes");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        reportInstance.logInfo("", value.toString());
        for (int i = 0; i < value.size(); i++) {
            Boolean present = false;
            JSONObject innerValueResponse = (JSONObject) value.get(i);
            JSONObject JSONResponse = innerValueResponse;
            String StrEntity = "UnescapedName";
            String StrExpectedValue = "DATA TYPE";
            String StrentityValue = JSONResponse.get(StrEntity).toString();
            if (StrentityValue.equals(StrExpectedValue)) {
                present = true;
                reportInstance.logInfo("STEPS", innerValueResponse.toString());
                if (present.equals(true)) {
                    this.reportInstance.logPass(StrentityValue, " is found as expected", ExtentColor.GREEN);
                    break;
                }
            }
        }
    }

    @When("Create a GET request to Filter ENTITY_TYPE by SuperTypeName not equal EDM side name")
    public void Create_a_GET_request_to_Filter_ENTITY_TYPE_by_SuperTypeName_not_equal_EDM_side_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter ENTITY_TYPE by SuperTypeName not equal EDM side name");
        stringResponse = GetRequest(ApiConstants.Route_ENTITY_TYPE + "?$filter=", "SuperTypeName ne 'DATA_TYPE'", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Filter ENTITY_TYPE by SuperTypeName not equal EDM side name")
    public void Verify_the_Filter_ENTITY_TYPE_by_SuperTypeName_not_equal_EDM_side_name() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the Filter ENTITY_TYPE by SuperTypeName not equal EDM side name");
        reportInstance.logInfo("STEPS", "Verify the JsonArray for any attributes");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        reportInstance.logInfo("", value.toString());
        String StrEntity = "UnescapedName";
        String StrExpectedValue = "DATA_TYPE";
        for (int i = 0; i < value.size(); i++) {
            Boolean present = false;
            JSONObject innerValueResponse = (JSONObject) value.get(i);
            JSONObject JSONResponse = innerValueResponse;
            String StrentityValue = JSONResponse.get(StrEntity).toString();
            if (StrentityValue.equals(StrExpectedValue)) {
                reportInstance.logFail("STEPS: ", "not as expected");
            }
        }
        reportInstance.logPass(StrExpectedValue, " Not Found as expected");
    }

    @When("Create a GET request to Filter SUPER_TYPE by Name using Surrogate Limited")
    public void Create_a_GET_request_to_Filter_SUPER_TYPE_by_Name_using_Surrogate_Limited() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter SUPER_TYPE by Name using Surrogate Limited");
        stringResponse = GetRequest(ApiConstants.Route_SUPER_TYPE+"?$filter=", "Name eq 'EXPERIMENT_SAMPLE_LIMITED'", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Filter SUPER_TYPE by Name using Surrogate Limited")
    public void Verify_the_Filter_SUPER_TYPE_by_Name_using_Surrogate_Limited() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the Filter SUPER_TYPE by Name using Surrogate Limited");
        VerifyEntityData(Response, "value", "[]");
    }
}