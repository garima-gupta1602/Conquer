package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.common.Utils;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.bcel.verifier.exc.AssertionViolatedException;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.time.DateTimeException;
import java.util.HashMap;

public class AccessLevelNullFilterTestsStepDefinitions extends DBHelper
{
    JSONObject Response;
    HttpURLConnection conn;
    String pattern1 = "yyyy-MM-dd'T'HH:mm:ss.ssZ";
    String pattern2 ="YYYY-MM-dd'T'HH:mm:ss.SSSXXX";
    String pattern3 ="YYYY-MM-dd'T'HH:mm:ss";
    String ResourcePath="/IntegrationTests/Filters";
    @Given("Add Auth for the filter integration tests on access level")
    public void on_access_level() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN ","Login into ODATA to filter");
        Readprerequest();
    }
    @When("Send GET request for the filter with data time attributes {string}")
    public void send_get_request_for_the_filter_with_date_time_less_than_null(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET request to filter with date time");
        String Get=GetRequest(ApiConstants.Route_SAMPLE_FOR_DATETIME_FILTERING + "?$filter=",Filter, HttpURLConnection.HTTP_BAD_REQUEST);
        Response=(JSONObject)parser.parse(Get);
        reportInstance.logInfo("GET",Response.toString());
    }

    @Then("verify the error on Date Time attribute in filter for reading entity with details as {string} and message {string}")
    public void verify_the_error(String DetailedErrorCode,String Message) throws Exception
    {

        reportInstance.logInfo("THEN ","Verify the response against the expected error message");
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_READING_ENTITY, ApiConstants.ERROR_MESSAGE_READING_ENTITY,DetailedErrorCode,Message);
    }
    @Then("verify the error on Date Time attribute in filter for {string} and message {string}")
    public void verify_the_error_on_invalid(String ErrorCode,String Message) throws Exception
    {

        reportInstance.logInfo("THEN ","Verify the response against the expand location query");
        VerifyErrorMessage(Response,ErrorCode,Message);
    }
    @When("Send GET request for the valid filter with data time attributes {string}")
    public void send_get_request_for_the_valid_filter_with_date_time_less_than_null(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET request to filter with date time");
        String Route= ApiConstants.Route_SAMPLE_FOR_DATETIME_FILTERING + "?$filter=" + URLEncoderForRequests(Filter);
        conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
       // Response=(JSONObject)parser.parse(Get);
        //reportInstance.logInfo("GET",Response.toString());
    }
    @Then("Verify the DATETIME_FILTER_ATTRIBUTE in the response as {string}")
    public void verify_the_DATETIME_FILTER_ATTRIBUTE_in_the_response(String ValdiationType) throws Exception{
        // Write code here that turns the phrase above into concrete actions
      try
      {
          Response = ResponseOutput(conn, HttpStatus.SC_OK, false, new HashMap());
          JSONArray arrayvalue = JSONObjectToJsonArray(Response, "value");
          int sizeofArray=arrayvalue.size();
          if(ValdiationType.equalsIgnoreCase("Not Equal Null"))
          {
              if(sizeofArray==0)
              {
                  reportInstance.logPass("Not Equal Null", " response array should be of 0");
              }
              else
              {
                  reportInstance.logFail("Not Equal Null", " Is not 0 response where " + String.valueOf(sizeofArray));
                  throw new AssertionViolatedException("Response is not 0 as expected where "+String.valueOf(sizeofArray));
              }
          }
          for (int i = 0; i < arrayvalue.size(); i++)
          {
              String currentResponse = arrayvalue.get(i).toString();
             switch (ValdiationType)
             {
                 case "null":
                 {
                     Object value = StringToJSONObject(currentResponse).get("DATETIME_FILTER_ATTRIBUTE");
                     if (value == null)
                     {
                         reportInstance.logPass("DATETIME_FILTER_ATTRIBUTE", " is null as expected");
                     }
                     else
                     {
                         reportInstance.logFail("DATETIME_FILTER_ATTRIBUTE", " Is not null where " + value.toString());
                         throw new NullPointerException("Object is not null as expected where "+value.toString());
                     }
                     break;
                 }
                 case "Valid format":
                 {
                    String value= StringToJSONObject(currentResponse).get("DATETIME_FILTER_ATTRIBUTE").toString();
                    fnValidateDateonDateTimeAttribute(value);
                    break;
                 }
                 case "Null Equal Null":
                 {
                     Object value = StringToJSONObject(currentResponse).get("DATETIME_FILTER_ATTRIBUTE");
                     if (value == null)
                     {
                         reportInstance.logPass("DATETIME_FILTER_ATTRIBUTE", " is null as expected");
                     }
                     else
                     {
                         fnValidateDateonDateTimeAttribute(value.toString());
                     }
                     break;
                 }

             }
              //VerifyEntityData(StringToJSONObject(currentResponse),"DATETIME_FILTER_ATTRIBUTE","null");
          }
      }catch(Exception e)
      {
          reportInstance.logFail("Exception on verify_the_DATETIME_FILTER_ATTRIBUTE_in_the_response ",e.getMessage());
          throw e;
      }
    }

    public void fnValidateDateonDateTimeAttribute(String value) throws Exception
    {
        boolean patternvalidation=false;
        if(Utils.getInstance().isThisDateValid(value,pattern1))
        {
            patternvalidation=true;
        }else if (Utils.getInstance().isThisDateValid(value, pattern2))
        {
            patternvalidation = true;
        }else if(Utils.getInstance().isThisDateValid(value, pattern3))
        {
            patternvalidation = true;
        }
        if(patternvalidation)
        {
            reportInstance.logPass("DATETIME_FILTER_ATTRIBUTE", " is in a valid format as expected");
        }else
        {

            reportInstance.logFail("DATETIME_FILTER_ATTRIBUTE", " is not in a valid format");
            throw new DateTimeException("Not in the expected format of date");
        }
    }


}
