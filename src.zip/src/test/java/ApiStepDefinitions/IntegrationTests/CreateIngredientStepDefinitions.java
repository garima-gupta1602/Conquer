package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.sl.Ter;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateIngredientStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateIngredient";

    @Given("Login into ODATA to create Ingredient")

    public void login_into_ODATA_to_create_ingredient() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create Ingredient");
        Readprerequest();
    }

    @When("Post the request to create Malt With Unique Attribute")

    public void post_the_request_to_create_Malt_With_Unique_Attribute() throws Exception {
        reportInstance.logInfo("","Post the request to create Malt With Unique Attribute");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateMaltWithUniqueAttribute.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity type name of Malt created with Unique Attribute")

    public void verify_the_Entity_type_name_of_Malt_created_with_Unique_Attribute() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Malt created with Unique Attribute");
        VerifyEntityData(Response,"EntityTypeName","INGREDIENT_FOR_TEST_DEFAULT_VALUE");

    }

    @When("Post the request to create Malt With The Same Unique Attribute Should Fail")

    public void post_the_request_to_create_Malt_With_The_Same_Unique_Attribute_Should_Fail() throws Exception {
        reportInstance.logInfo("","Post the request to create Malt With The Same Unique Attribute Should Fail");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateMaltWithTheSameUniqueAttributeShouldFail.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Malt created With The Same Unique Attribute Should Fail")

    public void verify_the_error_message_for_Malt_created_With_The_Same_Unique_Attribute_Should_Fail() throws Exception {
        reportInstance.logInfo("","Verify the error message for Malt created With The Same Unique Attribute Should Fail");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","Unique constraint over set of attributes or associations is violated. Colliding entities are as follows: ITDV1");


    }

    @When("Post the request to create Malt That Missing Value On Rule Bound Attribute Is Saved By Defaults")

    public void post_the_request_to_create_Malt_That_Missing_Value_On_Rule_Bound_Attribute_Is_Saved_By_Defaults() throws Exception {
        reportInstance.logInfo("","Post the request to create Malt That Missing Value On Rule Bound Attribute Is Saved By Defaults");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateMaltWithTheSameUniqueAttributeShouldFail.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity type name of malt created That Missing Value On Rule Bound Attribute Is Saved By Defaults")

    public void Verify_the_Entity_type_name_of_malt_created_That_Missing_Value_On_Rule_Bound_Attribute_Is_Saved_By_Defaults() throws Exception {
        reportInstance.logInfo("","Verify the Entity type name of malt created That Missing Value On Rule Bound Attribute Is Saved By Defaults");
        VerifyEntityData(Response,"EntityTypeName","INGREDIENT_FOR_TEST_DEFAULT_VALUE");

    }

    @When("Post the request to create Ingredient That Value On Rule Attribute Is Out Of Bound")

    public void post_the_request_to_create_ingredient_That_Value_On_Rule_attribute_is_Out_Of_Bound() throws Exception {
        reportInstance.logInfo("","Post the request to create Malt That Missing Value On Rule Bound Attribute Is Saved By Defaults");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIngredientThatValueOnRuleAttributeIsOutOfBound.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Ingredient created That Value On Rule Attribute Is Out Of Bound")

    public void verify_the_error_message_for_ingredient_created_That_Value_On_Rule_Attribute_Is_Out_Of_Bound() throws Exception {
        reportInstance.logInfo("","Verify the error message for Ingredient created That Value On Rule Attribute Is Out Of Bound");
        VerifyErrorMessage(Response,"3000","Error creating entity");

    }

    @When("Post the request to create Ingredient That Value On Rule Attribute Is Null")

    public void Post_the_request_to_create_Ingredient_That_Value_On_Rule_Attribute_Is_Null() throws Exception {
        reportInstance.logInfo("","Post the request to create Ingredient That Value On Rule Attribute Is Null");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIngredientThatValueOnRuleAttributeIsNull.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Ingredient created That Value On Rule Attribute Is Null")

    public void Verify_the_error_message_for_Ingredient_created_That_Value_On_Rule_attribute_is_Null() throws Exception {
        reportInstance.logInfo("","Verify the error message for Ingredient created That Value On Rule Attribute Is Null");
        VerifyErrorMessage(Response,"3000","Error creating entity");

    }

    @When("Post the request to create Ingredient That Value On Rule Attribute Is In Different Type")

    public void post_the_request_to_create_Ingredient_That_Value_On_Rule_Attribute_Is_In_Different_Type() throws Exception {
        reportInstance.logInfo("","Post the request to create Ingredient That Value On Rule Attribute Is In Different Type");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIngredientThatValueOnRuleAttributeIsInDifferentType.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Ingredient created That Value On Rule Attribute Is In Different Type")

    public void verify_the_error_message_for_Ingredient_created_That_Value_On_Rule_Attribute_is_in_different_type() throws Exception {
        reportInstance.logInfo("","Verify the error message for Ingredient created That Value On Rule Attribute Is In Different Type");
        VerifyErrorMessage(Response,"2002","Invalid value for property 'CI_DEFAULT_VALUE'.");

    }

    @When("Post the request to create Ingredient With Signature Required Should Fail")

    public void post_the_request_to_create_Ingredient_with_signature_required_should_fail() throws Exception {
        reportInstance.logInfo("","Post the request to create Ingredient With Signature Required Should Fail");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIngredientWithSignatureRequiredShouldFail.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TEST_FOR_ESIGNATURE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Ingredient created With Signature Required Should Fail")

    public void verify_the_error_message_for_Ingredient_created_With_Signature_Required_Should_Fail() throws Exception {
        reportInstance.logInfo("","Verify the error message for Ingredient created With Signature Required Should Fail");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","ESignature required to create or update this entity type");

    }


}
