package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import com.mongodb.DB;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateIntermediateExperimentSampleStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String ResourcePath="/IntegrationTests/Actions/CreateIntermediateExperimentSample";

    @Given("Login into ODATA to create Intermediate Experiment Sample")

    public void login_into_ODATA_to_create_intermediate_Experiment_sample() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create Intermediate Experiment Sample");
        Readprerequest();
    }

    @When("Post the request to create Intermediate Experiment Sample")

    public void post_the_request_to_create_Intermediate_Experiment_Sample() throws Exception {
        reportInstance.logInfo("","Post the request to create Intermediate Experiment Sample");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIntermediateExperimentSample.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity Type Name of Intermediate Experiment Sample created")

    public void verify_the_Entity_Type_Name_of_Intermediate_Experiment_Sample_created() throws IOException {
        reportInstance.logInfo("","Verify the Entity Type Name of Intermediate Experiment Sample created");
        VerifyEntityData(Response,"EntityTypeName","BITTERNESS_EXPERIMENT_SAMPLE");

    }

    @When("Post the request to create intermediate experiment sample invalid experiment barcode")

    public void Post_the_request_to_create_intermediate_experiment_sample_invalid_experiment_barcode() throws Exception {
        reportInstance.logInfo("","Post the request to create intermediate experiment sample invalid experiment barcode");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIntermediateExperimentSampleInvalidExperimentBarcode.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message of intermediate experiment sample created with invalid experiment barcode")
    public void verify_the_error_message_of_intermediate_experiment_sample_created_with_invalid_experiment_barcode() throws Exception {
        reportInstance.logInfo("","Verify the error message of intermediate experiment sample created with invalid experiment barcode");
        VerifyErrorMessage(Response,"2005","Could not find entity represented by barcode:SOME_INVALID_THING");

    }

    @When("Post the request to create intermediate experiment sample invalid experiment type")

    public void post_the_request_to_create_intermediate_experiment_sample_invalid_experiment_type() throws Exception {
        reportInstance.logInfo("","Post the request to create intermediate experiment sample invalid experiment type");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIntermediateExperimentSampleInvalidExperimentType.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }
    @Then("Verify the error message of intermediate experiment sample created invalid experiment type")
    public void Verify_the_error_message_of_intermediate_experiment_sample_created_invalid_experiment_type() throws Exception {
        reportInstance.logInfo("","Verify the error message of intermediate experiment sample created invalid experiment type");
        VerifyErrorMessage(Response,"2005","Entity TBXP1 is not of type EXPERIMENT");

    }

    @When("Post the request to create intermediate experiment sample invalid sample lot barcode")

    public void post_the_request_to_create_intermediate_experiment_sample_invalid_sample_lot_barcode() throws Exception {
        reportInstance.logInfo("","Post the request to create intermediate experiment sample invalid sample lot barcode");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIntermediateExperimentSampleInvalidSampleLotBarcode.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message of intermediate experiment sample invalid sample lot barcode")

    public void verify_the_error_message_of_intermediate_experiment_sample_invalid_sample_lot_barcode() throws Exception {
        reportInstance.logInfo("","Verify the error message of intermediate experiment sample invalid sample lot barcode");
        VerifyErrorMessage(Response,"2005","Could not find entity represented by barcode:SOME_INVALID_THING");

    }

    @When("Post the request to create intermediate experiment sample invalid experiment")

    public void post_the_request_to_create_intermediate_experiment_sample_invalid_experiment() throws Exception {
        reportInstance.logInfo("","Post the request to create intermediate experiment sample invalid experiment");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIntermediateExperimentSampleInvalidExperiment.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message of intermediate experiment sample invalid experiment")
    public void Verify_the_error_message_of_intermediate_experiment_sample_invalid_experiment() throws Exception {
        reportInstance.logInfo("","Verify the error message of intermediate experiment sample invalid experiment");
        VerifyErrorMessage(Response,"2005","Entity BTES3 is not of type EXPERIMENT_SAMPLE");

    }

    @When("Send a GET request to get derived_from navigation of experiment sample")

    public void send_a_GET_request_to_get_derived_from_navigation_of_experiment_sample() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to get derived_from navigation of experiment sample");
        stringResponse = GetRequest(ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE+"('BTES3')/DERIVED_FROM","");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the response for derived_from navigation of experiment sample")

    public void verify_the_response_for_derived_from_navigation_of_experiment_sample() throws Exception {
        JSONArray resp=JSONObjectToJsonArray(Response,"value");
        for(int i=0; i<resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            VerifyEntityData(Response, "EntityTypeName", "BITTERNESS_EXPERIMENT_SAMPLE");
        }
    }

    @When("Send a GET request to get intermediate assay data through intermediate experiment sample")

    public void send_a_GET_request_to_get_intermediate_assay_data_through_intermediate_experiment_sample() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send a GET request to get intermediate assay data through intermediate experiment sample");
        stringResponse = GetRequest(ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE+ApiConstants.Route_IntermediateExperimentSampleAssayData,"");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the assay data value of intermediate experiment sample")

    public void verify_the_assay_data_value_of_intermediate_experiment_sample() throws IOException {
        reportInstance.logInfo("","Verify the assay data value of intermediate experiment sample");
        VerifyEntityData(Response,"CI_BITTERNESS_IBU_INTERMEDIATE","6.4");
    }

    @When("Post the request to create intermediate experiment sample invalid derives")

    public void post_the_request_to_create_intermediate_experiment_sample_invalid_derives() throws Exception {
        reportInstance.logInfo("","Post the request to create intermediate experiment sample invalid derives");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateIntermediateExperimentSampleInvalidDerives.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message of intermediate experiment sample invalid derives")

    public void verify_the_error_message_of_intermediate_experiment_sample_invalid_derives() throws Exception {
        reportInstance.logInfo("","Verify the error message of intermediate experiment sample invalid derives");
        VerifyErrorMessage(Response,"2005","Could not find entity represented by barcode:SOME_INVALID_THING");

    }


}
