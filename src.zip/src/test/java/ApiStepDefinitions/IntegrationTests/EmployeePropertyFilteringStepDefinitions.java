package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class EmployeePropertyFilteringStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();
    private static final String EntityTypeName_PROP_NAME = "SDK_USER";


    @Given("Login into ODATA to EmployeePropertyFiltering")
    public void Login_into_ODATA_to_EmployeePropertyFiltering() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA to EmployeePropertyFiltering");
        Readprerequest();
    }

    @When("Create a GET request to Filter Employees By Entity Type Name Unescaped")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Unescaped() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter Employees By Entity Type Name Unescaped");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter=" + URLEncoderForRequests("EntityTypeName eq 'SDK_USER'");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Entity Type Name to Filter Employees By Entity Type Name Unescaped")
    public void Verify_the_Entity_Type_Name_to_Filter_Employees_By_Entity_Type_Name_Unescaped() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the Entity Type Name to Filter Employees By Entity Type Name Unescaped");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                VerifyEntityData(Response, "EntityTypeName", EntityTypeName_PROP_NAME);
            }
            break;
        }
    }

    @When("Create a GET request to Filter Employees By Entity Type Name Unescaped No Matches")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Unescaped_No_Matches() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter Employees By Entity Type Name Unescaped No Matches");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter="+ URLEncoderForRequests("EntityTypeName eq 'SDK USER'");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify no entities returned to Filter Employees By Entity Type Name Unescaped No Matches")
    public void Verify_no_entities_returned_to_Filter_Employees_By_Entity_Type_Name_Unescaped_No_Matches() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify no entities returned to Filter Employees By Entity Type Name Unescaped No Matches");
        VerifyEntityData(Response, "value", "[]");
    }

    @When("Create a GET request to Filter Employees By Entity Type Name Not Equals A Non Existent")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Not_Equals_A_Non_Existent() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter Employees By Entity Type Name Not Equals A Non Existent");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter=" + URLEncoderForRequests("EntityTypeName ne 'asdf1234gh'");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify EntityTypeName to Filter Employees By Entity Type Name Not Equals A Non Existent")
    public void Verify_EntityTypeName_to_Filter_Employees_By_Entity_Type_Name_Not_Equals_A_Non_Existent() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify EntityTypeName to Filter Employees By Entity Type Name Not Equals A Non Existent");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String atrr = GetattributefromResponse(Response, "EntityTypeName");
                if (atrr != "asdf1234gh") {
                    reportInstance.logPass(atrr, " -not equals as expected");
                } else {
                    reportInstance.logPass(atrr, " -equals");
                }
            }
            break;
        }

    }

    @When("Create a GET request to Filter Employees By Entity Type Name Equal To Null")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Equal_To_Null() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter Employees By Entity Type Name Equal To Null");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter=" + URLEncoderForRequests("EntityTypeName eq null");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify EntityTypeName to Filter Employees By Entity Type Name Equal To Null")
    public void Verify_EntityTypeName_to_Filter_Employees_By_Entity_Type_Name_Equal_To_Null() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify EntityTypeName to Filter Employees By Entity Type Name Equal To Null");
        VerifyEntityData(Response, "value", "[]");
    }

    @When("Create a GET request to Filter Employees By Entity Type Name Not Equal To Null")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Not_Equal_To_Null() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter Employees By Entity Type Name Not Equal To Null");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter="+ URLEncoderForRequests("EntityTypeName ne null");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify EntityTypeName to Filter Employees By Entity Type Name Not Equal To Null")
    public void Verify_EntityTypeName_to_Filter_Employees_By_Entity_Type_Name_Not_Equal_To_Null() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify EntityTypeName to Filter Employees By Entity Type Name Not Equal To Null");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String atrr = GetattributefromResponse(Response, "EntityTypeName");
                if (atrr != null) {
                    reportInstance.logPass(atrr, " -not null as expected");
                } else {
                    reportInstance.logPass(atrr, " -equals");
                }
            }
            break;
        }

    }

    @When("Create a GET request to Filter Employees By Entity Type Name Equal To Empty String")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Equal_To_Empty_String() throws Exception {
        reportInstance.logInfo("STEPS : ", "Create a GET request to Filter Employees By Entity Type Name Equal To Empty String");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter=" + URLEncoderForRequests("EntityTypeName eq ''");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify EntityTypeName to Filter Employees By Entity Type Name Equal To Empty String")
    public void Verify_EntityTypeName_to_Filter_Employees_By_Entity_Type_Name_Equal_To_Empty_String() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify EntityTypeName to Filter Employees By Entity Type Name Equal To Empty String");
        VerifyEntityData(Response, "value", "[]");
    }

    @When("Create a GET request to Filter Employees By Entity Type Name Not Equal To Empty String")
    public void Create_a_GET_request_to_Filter_Employees_By_Entity_Type_Name_Not_Equal_To_Empty_String() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter Employees By Entity Type Name Not Equal To Empty String");
        String endpointurl = ApiConstants.Route_EMPLOYEE+ "?$filter=" + URLEncoderForRequests("EntityTypeName ne ''");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify EntityTypeName to Filter Employees By Entity Type Name Not Equal To Empty String")
    public void Verify_EntityTypeName_to_Filter_Employees_By_Entity_Type_Name_Not_Equal_To_Empty_String() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify EntityTypeName to Filter Employees By Entity Type Name Not Equal To Empty String");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                String atrr = GetattributefromResponse(Response, "EntityTypeName");
                if (atrr != "") {
                    reportInstance.logPass(atrr, " -not empty as expected");
                } else {
                    reportInstance.logPass(atrr, " -equals");
                }
            }
            break;
        }

    }
}
