package ApiStepDefinitions.IntegrationTests;
import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class FilteringWithEnumsStepDefinitions extends DBHelper {


    private static final String priority_prop = "Medium";
    private static final String entityname_prop = "PRIORITIZATION_QUEUE_MEMBER";
    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();


    @Given("Login into ODATA to FilteringWithEnums")
    public void Login_into_ODATA_to_FilteringWithEnums() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA to FilteringWithEnums");
        Readprerequest();
    }

    @When("Create a GET request to Filter By Queue Priority Enum")
    public void Create_a_GET_request_to_Filter_By_Queue_Priority_Enum() throws Exception {
        String endpointurl = ApiConstants.Route_PRIORITIZATION_QUEUE_MEMBER+ "?$filter=" + URLEncoderForRequests("PRIORITY eq pfs.QUEUE_PRIORITY'Medium'");
        reportInstance.logInfo("STEPS : ", "GET request to Filter By Queue Priority Enum");
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify Filter By Queue Priority Enum")
    public void Verify_Filter_By_Queue_Priority_Enum() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify Filter By Queue Priority Enum");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                VerifyEntityData(Response, "PRIORITY", priority_prop);
                VerifyEntityData(Response, "EntityTypeName", entityname_prop);
            }
            break;
        }
    }
}
