package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class QueueFulfillMemberTestsStepDefinitions extends DBHelper
{
    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions";
    @Given("Login into ODATA to queue fulfill members")
    public void login_into_odata_to_queue_fulfill_members() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to queue fulfill members");
        Readprerequest();
    }
    @When("Create a POST request With Queue Member Belonging To Another Queue")
    public void create_a_post_request_with_queue_member_belonging_to_another_queue() throws Exception
    {
        reportInstance.logInfo("","POST request With Queue Member Belonging To Another Queue");
        JSONObject Request=ReadJsonInput(ResourcePath+"/QueueMemberBelongingToAnotherQueue.json");
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.fulfillQueuemembers), HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for Queue Member Belonging To Another Queue")
    public void verify_the_error_message_with_queue_member_belonging_to_another_queue() throws Exception
    {
        reportInstance.logInfo("","Verify the error message for Queue Member Belonging To Another Queue");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL,"Queue Member with barcode 'XZA10' exists but does not belong to queue: 'PQ2'");
    }
    @When("Create a POST request With Invalid Fulfiller Override")
    public void create_a_post_request_with_invalid_fulfiller_override() throws Exception
    {
        reportInstance.logInfo("","POST request With Invalid Fulfiller Override");
        JSONObject Request=ReadJsonInput(ResourcePath+"/InvalidFulfillerOverride.json");
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.fulfillQueuemembers), HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for Invalid Fulfiller Override")
    public void verify_the_error_message_for_invalid_fulfiller_override() throws Exception
    {
        reportInstance.logInfo("","Verify the error message for invalid_fulfiller_override");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL,"Property 'FulfillerOverride' is set to an invalid value, 'AFM2' does not point to an entity with type 'EMPLOYEE'");
    }
    @When("Create a POST request with valid fulfiller override")
    public void create_a_post_request_with_valid_fulfiller_override() throws Exception
    {
        reportInstance.logInfo("WHEN","POST request With valid Fulfiller Override");
        JSONObject Request=ReadJsonInput(ResourcePath+"/QueueFulFillmemberTests.json");
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.fulfillQueuemembers1), HttpURLConnection.HTTP_OK);
    }
    @Then("Verify the entity data for valid fulfiller override")
    public void verify_the_entity_data_for_valid_fulfiller_override() throws Exception
    {
        reportInstance.logInfo("THEN","Verify the entity data for valid fulfiller override");
        Object obj=Response.get("EntityTypeName");
        if(obj==null)
        {
            JSONArray arrayvalue = JSONObjectToJsonArray(Response, "value");
            for (int i = 0; i < arrayvalue.size(); i++)
            {
                reportInstance.logInfo("THEN ","fulfiller override on JSON array of "+String.valueOf(i));
                JSONObject currentResponse = (JSONObject) arrayvalue.get(i);
                reportInstance.logInfo("THEN ","PRIORITIZATION_QUEUE_MEMBER");
                VerifyEntityData(currentResponse,"EntityTypeName","PRIORITIZATION_QUEUE_MEMBER");
            }
        }else
        {
            VerifyEntityData(Response, "EntityTypeName","PRIORITIZATION_QUEUE_MEMBER");
        }

    }

}
