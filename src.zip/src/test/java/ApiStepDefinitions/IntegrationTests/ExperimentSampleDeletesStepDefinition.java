package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.common.Utils;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpStatus;

import java.net.HttpURLConnection;

public class ExperimentSampleDeletesStepDefinition extends DBHelper
{
    HttpURLConnection conn;
    @Given("Preparation for Delete experiment Sample")
    public void preparation_for_Delete_experiment_Sample() throws Exception
    {
        // Write code here that turns the phrase above into concrete actions
        reportInstance= SharedClassApi.getReportInstance();
        Readprerequest();
    }
    @When("Send Delete request to delete the experiment sample")
    public void send_Delete_request_to_delete_the_experiment_sample() throws Exception {
        // Write code here that turns the phrase above into concrete actions
       // Utils.getInstance().loadDataFromPropertyFile("Dependencies/Input/Header.properties","Tests");
       // Utils.getInstance().loadDataFromPropertyFile();

        String abcd= Utils.getInstance().getDataFromPropertyFile("Tests","ReadInput");
        //String prop=Utils.getInstance().getDataFromPropertyFile("Tests","data");
        conn=SendRequest(ApiConstants.Route_BITTERNESS_EXPERIMENT_SAMPLE+ApiConstants.Route_Delete_Small_Molecule,"",DefaultRequestHeader(),"DELETE");
    }

    @Then("Verify the delete of the experiment")
    public void verify_the_delete_of_the_experiment() throws Exception {
        // Write code here that turns the phrase above into concrete actions
       int deleteresponse=conn.getResponseCode();
       if(deleteresponse==HttpStatus.SC_NO_CONTENT)
        {
            reportInstance.logPass("","Delete was successful");
        }else
            {
                reportInstance.logFail("","Delete was not successful where response code is "+String.valueOf(deleteresponse));
        }
    }

}
