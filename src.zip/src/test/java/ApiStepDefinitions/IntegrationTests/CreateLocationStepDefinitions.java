package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateLocationStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateLocation";
    String RequestUnescapedName;


   @Given("Login into ODATA to create location")

   public void login_into_ODATA_to_create_location() throws Exception {
       reportInstance= SharedClassApi.getReportInstance();
       reportInstance.logInfo("","Login into ODATA to create location");
       Readprerequest();
   }

   @When("Post the request to create Simple Site")

    public void post_the_request_to_create_simple_Site() throws Exception {
       reportInstance.logInfo("","Post the request to create Simple Site");
       RequestUnescapedName="Simple site"+RandomAlphanumericGenerate(4);
       reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the sample");
       JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSimpleSite.json");
       Request.put("Name",RequestUnescapedName);
       Response =postRequest(Request.toString(), ApiConstants.Route_SITE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

   }

   @Then("Verify the Entity type name of Simple Site created")

    public void verify_the_entity_type_name_of_Simple_Site_created() throws IOException {
       reportInstance.logInfo("","Verify the Entity type name of Simple Site created");
       VerifyEntityData(Response,"EntityTypeName","SITE");

   }

   @When("Post the request to create Simple Location")
    public void Post_the_request_to_create_Simple_Location() throws Exception {
       reportInstance.logInfo("","Post the request to create Simple Location");
       RequestUnescapedName="Simple LOCATION"+RandomAlphanumericGenerate(4);
       reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the sample");
       JSONObject Request=ReadJsonInput(ResourcePath+"/CreateLocation.json");
       Request.put("Name",RequestUnescapedName);
       Response =postRequest(Request.toString(), ApiConstants.Route_LOCATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

   }

   @Then("Verify the Entity type name of Simple Location created")

    public void verify_the_entity_type_name_of_Simple_Location_created() throws IOException {
       reportInstance.logInfo("","Verify the Entity type name of Simple Location created");
       VerifyEntityData(Response,"EntityTypeName","LOCATION_LIMITED");

   }
}
