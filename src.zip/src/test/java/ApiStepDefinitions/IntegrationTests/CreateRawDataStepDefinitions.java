package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateRawDataStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateRawData";

    @Given("Login into ODATA to create Raw Data")

    public void login_into_odata_to_create_raw_data() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create Raw Data");
        Readprerequest();
    }

    @When("POST the request to create raw data")

    public void POST_the_request_to_create_raw_data() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawData.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity type name of raw data created")

    public void verify_the_entity_type_name_of_raw_data_created() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of raw data created");
        VerifyEntityData(Response,"SAMPLE_TYPE","9bb3a26d-307");

    }

    @When("POST the request to create raw data without file")

    public void post_the_request_to_create_raw_data_without_file() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data without file");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawDataWithoutFile.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for raw data created without file")

    public void verify_the_error_message_for_raw_data_created_without_file() throws Exception {
        reportInstance.logInfo("","Verify the error message for raw data created without file");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3007","Missing associations");

    }

    @When("POST the request to create raw data with unfound file")

    public void POST_the_request_to_create_raw_data_with_unfound_file() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data with unfound file");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawDataWithUnfoundFile.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for raw data created with unfound file")

    public void verify_the_error_message_for_raw_data_created_with_unfound_file() throws Exception {
        reportInstance.logInfo("","Verify the error message for raw data created with unfound file");
        VerifyErrorMessage(Response,"2005","Could not find entity represented by barcode:142a111d-73f");

    }

    @When("POST the request to create raw data without experiment")

    public void POST_the_request_to_create_raw_data_without_experiment() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data without experiment");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawDataWithoutExperiment.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for raw data created without experiment")

    public void verify_the_error_message_for_raw_data_created_without_experiment() throws Exception {
        reportInstance.logInfo("","Verify the error message for raw data created without experiment");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3007","Missing associations");

    }


    @When("POST the request to create raw data with unfound experiment")

    public void POST_the_request_to_create_raw_data_with_unfound_experiment() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data with unfound experiment");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawDataWithUnfoundExperiment.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for raw data created with unfound experiment")

    public void verify_the_error_message_for_raw_data_created_with_unfound_experiment() throws Exception {
        reportInstance.logInfo("","Verify the error message for raw data created without unfound experiment");
        VerifyErrorMessage(Response,"2005","Could not find entity represented by barcode:9f065723-2bb");


    }

    @When("POST the request to create raw data without sample type")

    public void POST_the_request_to_create_raw_data_without_sample_type() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data without sample type");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawDataWithoutSampleType.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for raw data created without sample type")

    public void Verify_the_error_message_for_raw_data_created_without_sample_type() throws Exception {
        reportInstance.logInfo("","Verify the error message for raw data created without sample type");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","Raw data records must include a sample type");


    }

    @When("POST the request to create raw data with value nullable")

    public void POST_the_request_to_create_raw_data_with_value_nullable() throws Exception {
        reportInstance.logInfo("","POST the request to create raw data with value nullable");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateRawDataWithValueNullable.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_RAW_DATA,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the data value for raw data created with value nullable")

    public void Verify_the_data_value_for_raw_data_created_with_value_nullable() throws IOException {
        reportInstance.logInfo("","Verify the data value for raw data created with value nullable");
        VerifyEntityData(Response,"DATA_VALUE",null);

    }


}
