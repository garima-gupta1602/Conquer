package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateTimestampStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateTimestamp";

    @Given("Login into ODATA to create chemical producer entity with DateTimeOffset Attribute")

    public void login_into_ODATA_to_create_chemical_producer_entity_with_DateTimeOffset_Attribute() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create chemical producer entity with DateTimeOffset Attribute");
        Readprerequest();
    }

    @When("POST the request to create Chemical_Producer Entity With DateTimeOffset Attribute")

    public void post_the_request_to_create_chemical_producer_entity_with_DateTimeOffset_attribute() throws Exception {
        reportInstance.logInfo("","POST the request to create Chemical_Producer Entity With DateTimeOffset Attribute");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateTimestampwithDataTimeOffset.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_CHEMICAL_PRODUCER,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the entity type name for Chemical_Producer Entity created With DateTimeOffset Attribute")

    public void verify_the_entity_type_name_for_Chemical_Producer_entity_created_with_DateTimeOffset_attribute() throws IOException {
        reportInstance.logInfo("","Verify the Entity Type name for experiment sample with POCO Attributes ");
        VerifyEntityData(Response,"EntityTypeName","CHEMICAL_PRODUCER");

    }
}
