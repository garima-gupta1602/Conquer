package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateContainerStepDefinitions extends DBHelper {

    JSONObject Response;
    String RequestUnescapedName;
    String ResourcePath="/IntegrationTests/Actions/CreateContainer";

    @Given("Login into ODATA to create container")
    public void login_with_odata_to_create_container() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create container");
        Readprerequest();
    }

    @When("POST the request for a container VIAL")
    public void post_the_request_for_a_container_vial() throws Exception {
        reportInstance.logInfo("","POST the request for a container VIAL");
        RequestUnescapedName="Simple Vial"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the sample");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateContainerVial.json");
        Request.put("Name",RequestUnescapedName);
        Response =postRequest(Request.toString(), ApiConstants.Route_VIAL,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the entity type name for vial created")
    public void verify_the_entity_type_name_for_vial_created() throws IOException {
        reportInstance.logInfo("","Verify the entity type name for vial created ");
        VerifyEntityData(Response,"EntityTypeName","VIAL");
    }

    @When("Post the request for a container _96_WELL_PLATE")
    public void post_the_request_for_a_container_96_WELL_PLATE() throws Exception {
        reportInstance.logInfo("","Post the request for a container _96_WELL_PLATE");
        RequestUnescapedName="96 Well Plate"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the sample");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateContainer96WellPlate.json");
        Request.put("Name",RequestUnescapedName);
        Response =postRequest(Request.toString(), ApiConstants.Route__96_WELL_PLATE,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the entity type name for 96 Well Plate created")
    public void verify_the_entity_type_name_for_96_Well_Plate_created() throws IOException {
        reportInstance.logInfo("","Verify the entity type name for 96 Well Plate created");
        VerifyEntityData(Response,"EntityTypeName","_96_WELL_PLATE");

    }
}
