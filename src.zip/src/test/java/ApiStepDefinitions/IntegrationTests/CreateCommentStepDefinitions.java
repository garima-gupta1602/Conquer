package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;

public class CreateCommentStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateComment";

    @Given("Login into ODATA to create comment")
    public void login_into_ODATA_to_create_comment() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create comment");
        Readprerequest();
    }

    @When("POST the request to create comment without text")
    public void  post_the_request_to_create_comment_without_text() throws Exception {
        reportInstance.logInfo("","POST the request to create comment without text");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateCommentWithoutText.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_COMMENT,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for comment without text")
    public void verify_the_error_message_for_comment_without_text() throws Exception {
        reportInstance.logInfo("","Verify the error message for comment without text");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3006","Required attribute COMMENT_TEXT is missing in the request");

    }

    @When("POST the request to create comment without entity")
    public void post_the_request_to_create_comment_without_entity() throws Exception {
        reportInstance.logInfo("","POST the request to create comment without entity");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateCommentWithoutEntity.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_COMMENT,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Comment Without Entity")
    public void verify_the_error_message_for_comment_without_entity() throws Exception {
        reportInstance.logInfo("","Verify the error message for Comment Without Entity");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3007","Required association ENTITY is missing in the request");

    }
}
