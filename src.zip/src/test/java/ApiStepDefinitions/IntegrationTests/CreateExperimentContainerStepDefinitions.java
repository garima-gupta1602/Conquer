package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;
import org.junit.Test;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateExperimentContainerStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateExperimentContainer";

    @Given("Login into ODATA to create Experiment Container")
    public void login_into_ODATA_to_create_experiment_Container() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create Experiment Container");
        Readprerequest();
    }

    @When("POST the request to create Single Well Experiment Container Without Intermediate Data")
    public void POST_the_request_to_create_Single_Well_Experiment_Container_without_Intermediate_Data() throws Exception {
        reportInstance.logInfo("","POST the request to create Single Well Experiment Container Without Intermediate Data");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateSingleWellExperimentContainerWithoutIntermediateData.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TURBIDITY_EXPERIMENT_CONTAINER,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the Entity type name of Single well experiment container created without Intermediate Data")
    public void verify_the_Entity_type_name_of_single_well_experiment_container_created_without_intermediate_data() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Single well experiment container created without Intermediate Data");
        VerifyEntityData(Response,"EntityTypeName","TURBIDITY_EXPERIMENT_CONTAINER");
    }

    @When("POST the request to create Multi Well Experiment Container Without Intermediate Data")
    public void post_the_request_to_create_multi_Well_Experiment_Container_Without_Intermediate_Data() throws Exception {
        reportInstance.logInfo("","POST the request to create Multi Well Experiment Container Without Intermediate Data");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateMultiWellExperimentContainerWithoutIntermediateData.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TURBIDITY_EXPERIMENT_CONTAINER,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the Entity type name of Multi Well Experiment Container Without Intermediate Data")
    public void verify_the_Entity_type_name_of_Multi_Well_Experiment_Container_without_intermediate_data() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Multi Well Experiment Container Without Intermediate Data");
        VerifyEntityData(Response,"EntityTypeName","TURBIDITY_EXPERIMENT_CONTAINER");
    }

    @When("POST the request to create Single Well Experiment Container With Intermediate Data")
    public void post_the_request_to_create_Single_Well_Experiment_Container_With_Intermediate_Data() throws Exception {
        reportInstance.logInfo("","POST the request to create Single Well Experiment Container With Intermediate Data");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateMultiWellExperimentContainerWithoutIntermediateData.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_BITTERNESS_EXPERIMENT_CONTAINER,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the Entity type name of Single Well Experiment Container With Intermediate Data")
    public void verify_the_Entity_type_name_of_single_well_experiment_container_with_intermediate_data() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Single well experiment container created wit Intermediate Data");
        VerifyEntityData(Response,"EntityTypeName","BITTERNESS_EXPERIMENT_CONTAINER");
    }

    @When("POST the request to create Experiment Container For Published Experiment")
    public void post_the_request_to_create_Experiment_Container_For_Published_Experiment() throws Exception {
        reportInstance.logInfo("","POST the request to create Experiment Container For Published Experiment");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperimentContainerForPublishedExperiment.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TURBIDITY_EXPERIMENT_CONTAINER,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the error message of Experiment Container For Published Experiment")
    public void verify_the_error_message_of_experiment_Container_For_Published_Experiment() throws Exception {
        reportInstance.logInfo("","Verify the error message for Comment Without Entity");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","Cannot add an experiment container to an experiment that is published.");
    }
}
