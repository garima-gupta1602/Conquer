package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class BreweryLambdaFilteringStepDefinitions extends DBHelper
{
    JSONObject Response;
    HttpURLConnection Conn;
    String Path="/IntegrationTests/Actions";
    @Given("Add Auth for the lambda integration tests on nested type cast")
    public void on_access_level() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN ","Add Auth for the lambda integration tests on nested type cast");
        Readprerequest();
    }
    @When("Send GET request for the filter with lambda test on {string}")
    public void lambdagetrequestforfilter(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Get=GetRequest(ApiConstants.Route_STABILITY_SAMPLE +"?$filter=",Filter, HttpURLConnection.HTTP_BAD_REQUEST);
        Response=(JSONObject)parser.parse(Get);
        reportInstance.logInfo("GET",Response.toString());
    }
    @Then("verify the error on lambda filter as {string} and message {string}")
    public void verify_the_error(String DetailedErrorCode,String Message) throws Exception
    {

        reportInstance.logInfo("THEN ","Verify the response against the expected error message");
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_READING_ENTITY, ApiConstants.ERROR_MESSAGE_READING_ENTITY,DetailedErrorCode,Message);
    }
    @When("Send a valid GET request for the filter with lambda test on {string}")
    public void lambdagetvalidrequestforfilter(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route_SAMPLE_FOR_REFERENCE_NAVIGATION_PROPERTY + "?$filter=" +URLEncoderForRequests(Filter);
        Conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }
    @Then("verify the Lambda test with association as {string}")
    public void verify_the_Lambda_test_with_association_as(String Value) throws Exception {
        Response=ResponseOutput(Conn, HttpStatus.SC_OK,false,new HashMap());
        JSONArray arrayvalue = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < arrayvalue.size(); i++)
        {
            reportInstance.logInfo("THEN ","SAMPLE_FOR_REFERENCE_NAVIGATION_PROPERTY on JSON array of "+String.valueOf(i));
            JSONObject currentResponse = (JSONObject) arrayvalue.get(i);
            VerifyEntityData(currentResponse,"EntityTypeName",Value);
        }

    }
    @When("Send a valid GET request for the filter with lambda test on employee with {string}")
    public void lambdagetvalidrequestforfilteronEmployee(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route_EMPLOYEE + "?$filter=" +URLEncoderForRequests(Filter);
        Conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

    @When("Send a valid GET request for the filter with lambda test on sample with {string}")
    public void lambdagetvalidrequestforfilteronsample(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route_STABILITY_SAMPLE +"?$filter="+URLEncoderForRequests(Filter);
        Conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

    @Then("verify the Lambda test with association as employee {string}")
    public void verify_the_Lambda_test_with_association_as_employee(String value) throws Exception {
        Response=ResponseOutput(Conn, HttpStatus.SC_OK,false,new HashMap());
        JSONArray arrayvalue = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < arrayvalue.size(); i++)
        {
            reportInstance.logInfo("THEN ","Employee on JSON array of "+String.valueOf(i));
            JSONObject currentResponse = (JSONObject) arrayvalue.get(i);
            VerifyEntityData(currentResponse,"EntityTypeName",value);
            reportInstance.logInfo("THEN ","ENFORCE_PROJECT_SECURITY");
            VerifyEntityData(currentResponse,"ENFORCE_PROJECT_SECURITY","Yes");
        }
    }
    @When("Send a valid GET request for the filter with lambda test on sample with reverse {string}")
    public void lambdaforfilteronsampleonreverseAssociation(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route_SUPPLIER_LIMITED + "?$filter=" +URLEncoderForRequests(Filter);
        Conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }
    @When("Send a valid GET request for the filter with lambda test on the Bitterness {string}")
    public void lambdaforfilteronsampleonBitterness(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route_BITTERNESS_EXPERIMENT +"?$filter=" +URLEncoderForRequests(Filter);
        Conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }
    @When("Send a valid GET request for the filter with lambda test on the well plate")
    public void lambdaforfilteronsampleonWellPlate() throws Exception
    {
       reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route__96_WELL_PLATE +"?$filter=" +URLEncoderForRequests("CELLS/any(x:x/Quantity gt 3 and x/Quantity lt 4)")+"&$top="+URLEncoderForRequests("20");
        reportInstance.logInfo("ROUTE ",Route);
        Conn=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }

}
