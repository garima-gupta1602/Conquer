package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateExperimentStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateExperiment";

    @Given("Login into ODATA to create Experiment")
    public void login_into_ODATA_to_create_Experiment() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create Experiment");
        Readprerequest();
    }

    @When("POST the request to create experiment")
    public void POST_the_request_to_create_experiment() throws Exception {
        reportInstance.logInfo("","POST the request to create experiment");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperiment.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_KI_DETERMINATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);
    }

    @Then("Verify the Entity type name of Experiemnt created")
    public void verify_the_Entity_type_name_of_experiemnt_created() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Experiemnt created");
        VerifyEntityData(Response,"EntityTypeName","KI_DETERMINATION");
    }

    @When("POST the request to create experiment with published true")
    public void POST_the_request_to_create_experiment_with_published_true() throws Exception {
        reportInstance.logInfo("","POST the request to create experiment with published true");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperimentWithPublishedTrue.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_KI_DETERMINATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the Error message of experiemnt created with published true")
    public void verify_the_Error_message_of_experiemnt_created_with_published_true() throws Exception {
        reportInstance.logInfo("","Verify the Error message of experiemnt created with published true");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3000","PUBLISHED cannot be set to true on create.");
    }

    @When("POST the request to create experiment with Daemoneval True")
    public void post_the_request_to_create_experiment_with_daemoneval_true() throws Exception {
        reportInstance.logInfo("","POST the request to create experiment with Daemoneval True");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperimentWithDaemonevalTrue.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_KI_DETERMINATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the Error message of experiemnt created with Daemoneval True")
    public void verify_the_Error_message_of_experiemnt_created_with_Daemoneval_True() throws Exception {
        reportInstance.logInfo("","Verify the Error message of experiemnt created with published true");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3000","DAEMONEVAL cannot be set to true on create.");
    }

    @When("POST the request to create experiment Without Mandatory Associations")
    public void POST_the_request_to_create_experiment_without_mandatory_associations() throws Exception {
        reportInstance.logInfo("","POST the request to create experiment Without Mandatory Associations");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperimentWithoutMandatoryAssociations.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_KI_DETERMINATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the Error message of experiemnt created Without Mandatory Associations")
    public void verify_the_error_message_of_experiemnt_created_Without_Mandatory_Associations() throws Exception {
        reportInstance.logInfo("","Verify the Error message of experiemnt created Without Mandatory Associations");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","EXPERIMENT_PROTOCOL is mandatory but has no associations,EXPERIMENT_ASSAY is mandatory but has no associations");
    }

    @When("POST the request to create experiment Without Mandatory Attributes")
    public void POST_the_request_to_create_experiment_without_Mandatory_Attributes() throws Exception {
        reportInstance.logInfo("","POST the request to create experiment Without Mandatory Attributes");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperimentWithoutMandatoryAttributes.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_KI_DETERMINATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the Error message of experiemnt created Without Mandatory Attributes")
    public void verify_the_Error_message_of_experiemnt_created_without_mandatory_attributes() throws Exception {
        reportInstance.logInfo("","Verify the Error message of experiemnt created Without Mandatory Attributes");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","Substrate_Conc is mandatory but has no data,Km is mandatory but has no data");
    }

    @When("POST the request to create experiment Without Body")
    public void POST_the_request_to_create_experiment_without_body() throws Exception {
        reportInstance.logInfo("","POST the request to create experiment Without Body");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateExperimentWithoutBody.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_KI_DETERMINATION,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_BAD_REQUEST);
    }

    @Then("Verify the Error message of experiemnt created Without Body")
    public void verify_the_Error_message_of_experiemnt_created_Without_Body() throws Exception {
        reportInstance.logInfo("","Verify the Error message of experiemnt created Without Body");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","Substrate_Conc is mandatory but has no data,Km is mandatory but has no data,EXPERIMENT_PROTOCOL is mandatory but has no associations,EXPERIMENT_ASSAY is mandatory but has no associations");
    }
}
