package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashMap;

public class BreweryTextFilteringUnsupportedStepDefinitions extends DBHelper
{
    JSONObject Response;
    HttpURLConnection Get;
    String Path="/IntegrationTests/Actions";
    @Given("Add Auth for the Brewery Text Filtering not supported tests")
    public void on_access_level() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN ","Add Auth for the Brewery Text Filtering not supported tests");
        Readprerequest();
    }
    @When("Send GET request on Brewery Text Filtering not supported test on {string}")
    public void brewerygetrequestforfilter(String Filter) throws Exception
    {
        reportInstance.logInfo("WHEN ","Send GET Request for the lambda");
        String Route= ApiConstants.Route_SMALL_MOLECULE + "?$filter=" +URLEncoderForRequests(Filter);
        Get=SendRequest(Route,"",DefaultRequestHeader(),"GET");
    }
    @Then("verify the Brewery Text Filtering supported")
    public void verify_the_text_filter() throws Exception
    {
        ResponseOutput(Get, HttpStatus.SC_OK,false,new HashMap());
    }
}
