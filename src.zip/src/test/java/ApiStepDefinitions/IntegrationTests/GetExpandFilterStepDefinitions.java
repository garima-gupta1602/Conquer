package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class GetExpandFilterStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();
    private static String filter_value = "True";

    @Given("Login into ODATA to Expand")
    public void Login_into_ODATA_to_Expand() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA to Expand");
        Readprerequest();
    }

    @When("Create a GET request to Expand Location Filter By Active")
    public void Create_a_GET_request_to_Expand_Location_Filter_By_Active() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Expand Location Filter By Active");
        stringResponse = GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST + "?$expand=", "LOCATION($filter=Active eq true)", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Location Filter By Active")
    public void Verify_the_Location_Filter_By_Active() throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String location = GetattributefromResponse(Response, "LOCATION");
            reportInstance.logInfo("STEPS", location);
            Response = StringToJSONObject(location);
            VerifyEntityData(Response, "Active", filter_value);
        }
    }

    @When("Create a GET request to Expand Employee Filter By Active")
    public void Create_a_GET_request_to_Expand_Employee_Filter_By_Active() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Expand Employee Filter By Active");
        stringResponse = GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST + "?$expand=", "CREATED_BY($filter=Active eq true)", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Employee Filter By Active")
    public void Verify_the_Employee_Filter_By_Active() throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String created = GetattributefromResponse(Response, "CREATED_BY");
            reportInstance.logInfo("STEPS", created);
            Response = StringToJSONObject(created);
            VerifyEntityData(Response, "Active", filter_value);
        }
    }

    @When("Create a GET request to Expand Reverse Navigation Filter By Active")
    public void Create_a_GET_request_to_Expand_Reverse_Navigation_Filter_By_Active() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the metadata");
        stringResponse = GetRequest(ApiConstants.Route_ANIMAL_SUBJECT_ACCESS_TEST + "?$expand=", "REV_COMBINE_FILTER_CONDITIONS_NAVIGATION($filter=Active eq true)", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the Reverse Navigation Filter By Active")
    public void Verify_the_Reverse_Navigation_Filter_By_Active() throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            JSONArray revnav = JSONObjectToJsonArray(Response, "REV_COMBINE_FILTER_CONDITIONS_NAVIGATION");
            reportInstance.logInfo("STEPS", revnav.toString());
            String StrEntity = "Active";
            for (int j = 0; j < revnav.size(); j++) {
                Boolean present = false;
                JSONObject innerValueResponse = (JSONObject) revnav.get(j);
                JSONObject JSONResponse = innerValueResponse;
                String StrentityValue = JSONResponse.get(StrEntity).toString();
                if (StrentityValue.equalsIgnoreCase(filter_value)) {
                    present = true;
                    reportInstance.logInfo("STEPS", innerValueResponse.toString());
                    if (present.equals(true)) {
                        this.reportInstance.logPass(StrentityValue, " is as expected", ExtentColor.GREEN);
                    }
                }
            }
        }
    }
}



