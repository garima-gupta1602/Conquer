package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;

public class SetCellContentsTestsStepDefinitions extends DBHelper
{
    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions";
    @Given("Login into ODATA to set cell contents")
    public void login_into_odata_to_publish_experiment_super_type() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to publish experiment super type");
        Readprerequest();
    }
    @When("Send POST request to set cell contents for container")
    public void send_post_request_to_set_cell_contents_for_container() throws Exception
    {
        reportInstance.logInfo("","Send POST request to set cell contents for container");
        JSONObject Request=ReadJsonInput(ResourcePath+"/SetCellContents.json");
        reportInstance.logInfo("WHEN",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_CONTAINER.concat(ApiConstants.setCellContents), HttpURLConnection.HTTP_INTERNAL_ERROR);
    }
    @Then("Verify the error message for container associated")
    public void verify_the_error_message_for_container_associated() throws Exception
    {
        reportInstance.logInfo("THEN","Verify the entity type name for container associated");
        VerifyErrorMessageWithinDetails(Response, ApiConstants.ERROR_CODE_UPDATING_ENTITY, ApiConstants.ERROR_MESSAGE_UPDATING_ENTITY, ApiConstants.ERROR_CODE_CANNOT_CHANGE,"You cannot change the contents of a container-cell whose parent container has been associated to an experiment...");
    }
    @When("Send POST request to set cell for 2 well plate")
    public void send_post_request_to_set_cell_for_2_well_plate() throws Exception
    {
        reportInstance.logInfo("","Send POST request to set cell for 2 well plate");
        JSONObject Request=ReadJsonInput(ResourcePath+"/Setcontents2wellplate.json");
        reportInstance.logInfo("WHEN",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route__2WellPlate.concat(ApiConstants.SetCellContent_2WellPlate), HttpURLConnection.HTTP_OK);
    }
    @Then("Verify the entity type name for 2 WELL PLATE")
    public void verify_the_entity_type_name_for_2_well_plate() throws Exception
    {
        reportInstance.logInfo("THEN","Verify the error message for 2 well plate");
        VerifyEntityData(Response, "EntityTypeName","_2_WELL_PLATE");
    }
}
