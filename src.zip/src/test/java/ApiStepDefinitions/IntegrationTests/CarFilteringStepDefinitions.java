package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CarFilteringStepDefinitions extends DBHelper {
    private static final int USAR_REQ_AGE_MIN_prop = 1;
    private static int minuend = 10;
    private static int difference = 9;
    private static String SPECIES = "RAT";
    private static int USAR_REQ_AGE_MAX_prop = 1;
    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();


    @Given("Login into ODATA for CarFiltering")
    public void Login_into_ODATA_for_CarFiltering() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        Readprerequest();
    }

    @When("Create a GET request to Filter Associated Integer Attribute and Expand {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_to_Filter_Associated_Integer_Attribute_and_Expand(String route, String filterparam1, String filterparam2, String filterparam3 ) throws Exception {
        String endpointurl = ApiConstants.Route_master+route + URLEncoderForRequests(filterparam1) + filterparam2 + URLEncoderForRequests(filterparam3);
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the USAR_REQ_AGE_MIN for Associated Integer Attribute and Expand")
    public void Verify_the_USAR_REQ_AGE_MIN_for_Associated_Integer_Attribute_and_Expand() throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String uanimalreq = GetattributefromResponse(Response, "USANIMALREG_REQUEST");
            Response = StringToJSONObject(uanimalreq);
            VerifyEntityData(Response, "USAR_REQ_AGE_MIN", String.valueOf(USAR_REQ_AGE_MIN_prop));
        }
    }

    @When("Create a GET request to Filter Floor Of Float Attribute and Added Value {string} and {string}")
    public void Create_a_GET_request_to_Filter_Floor_Of_Float_Attribute_and_Added_Value(String route, String filterparam) throws Exception {
        stringResponse = GetRequest(ApiConstants.Route_master+route , filterparam, HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the ANIM_DELIV_BW")
    public void Verify_the_ANIM_DELIV_BW() throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String response = resp.get(i).toString();
            reportInstance.logInfo("STEPS", response);
            Response = StringToJSONObject(response);
            String ANIM_DELIV_BW = GetattributefromResponse(Response, "ANIM_DELIV_BW");
            Double d_ANIM_DELIV_BW = Double.parseDouble(ANIM_DELIV_BW);
            //float sum_ANIM_DELIV_BW = (float) (Math.floor(Double.parseDouble(ANIM_DELIV_BW)) + addend);
            if (d_ANIM_DELIV_BW > 6.0 && d_ANIM_DELIV_BW < 6.9) {
                reportInstance.logPass("STEPS: ", d_ANIM_DELIV_BW + " verified as expected");
            } else {
                reportInstance.logFail("STEPS: ", "Not as expected");
            }
        }
    }

    @When("Create a GET request to Filter Associated Integer Attribute Subtraction and Expand {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_to_Filter_Associated_Integer_Attribute_Subtraction_and_Expand(String route, String filterparam1, String filterparam2, String filterparam3) throws Exception {
        String endpointurl = ApiConstants.Route_master+route+ URLEncoderForRequests(filterparam1) + filterparam2 + URLEncoderForRequests(filterparam3);
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the USAR_REQ_AGE_MIN for Associated Integer Attribute Subtraction and Expand")
    public void Verify_the_USAR_REQ_AGE_MIN_for_Associated_Integer_Attribute_Subtraction_and_Expand() throws Exception {
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String uanimalreq = GetattributefromResponse(Response, "USANIMALREG_REQUEST");
            reportInstance.logInfo("STEPS", uanimalreq);
            Response = StringToJSONObject(uanimalreq);
            String USAR_REQ_AGE_MIN = GetattributefromResponse(Response, "USAR_REQ_AGE_MIN");
            //int diff_USAR_REQ_AGE_MIN = minuend - Integer.parseInt(USAR_REQ_AGE_MIN);
            int diff = minuend - difference;
            if (diff == Integer.parseInt(USAR_REQ_AGE_MIN)) {
                reportInstance.logPass("STEPS: ", USAR_REQ_AGE_MIN + " verified as expected");
            } else {
                reportInstance.logFail("STEPS: ", "Not as expected");
            }
        }

    }

    @When("Create a GET request to Filter And Expand Integer And String Attribute {string} and {string} and {string} and {string}")
    public void Create_a_GET_request_to_Filter_And_Expand_Integer_And_String_Attribute(String route, String filterparam1, String filterparam2, String filterparam3) throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter And Expand Integer And String Attribute");
        String endpointurl = ApiConstants.Route_master+route+ URLEncoderForRequests(filterparam1) + filterparam2 + URLEncoderForRequests(filterparam3);
        stringResponse = GetRequest(endpointurl, "");
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the USAR_REQ_AGE_MIN greater than one")
    public void Verify_the_USAR_REQ_AGE_MIN_greater_than_one() throws Exception {
        reportInstance.logInfo("STEPS : ", "Verify the USAR_REQ_AGE_MIN greater than one");
        JSONArray resp = JSONObjectToJsonArray(Response, "value");
        for (int i = 0; i < resp.size(); i++) {
            String firstresp = resp.get(i).toString();
            Response = StringToJSONObject(firstresp);
            String uanimalreq = GetattributefromResponse(Response, "USANIMALREG_REQUEST");
            reportInstance.logInfo("STEPS", uanimalreq);
            Response = StringToJSONObject(uanimalreq);
            VerifyEntityData(Response, "SPECIES", SPECIES);
            String USAR_REQ_AGE_MAX = GetattributefromResponse(Response, "USAR_REQ_AGE_MAX");
            if (Integer.parseInt(USAR_REQ_AGE_MAX) > USAR_REQ_AGE_MAX_prop) {
                reportInstance.logPass("STEPS: ", USAR_REQ_AGE_MAX + " verified as expected");
            } else {
                reportInstance.logFail("STEPS: ", USAR_REQ_AGE_MAX + "Not as expected");
            }
        }
    }
}


