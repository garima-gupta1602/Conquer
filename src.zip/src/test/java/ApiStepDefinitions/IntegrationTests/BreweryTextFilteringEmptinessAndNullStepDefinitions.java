package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class BreweryTextFilteringEmptinessAndNullStepDefinitions extends DBHelper {


    JSONObject Response;
    String stringResponse;
    JSONParser parser = new JSONParser();
    private static String expcomment = "comment test";


    @Given("Login into ODATA for BreweryTextFilteringEmptinessAndNull")
    public void Login_into_ODATA_for_BreweryTextFilteringEmptinessAndNull() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("GIVEN : ", "Login into ODATA for BreweryTextFilteringEmptinessAndNull");
        Readprerequest();
    }

    @When("Create a GET request to Filter text attribute by ne operator and empty value")
    public void Create_a_GET_request_to_Filter_text_attribute_by_ne_operator_and_empty_value() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter text attribute by ne operator and empty value");
        stringResponse = GetRequest(ApiConstants.Route_ACCESS_LEVEL_LIMITED + "?$filter=", "COMMENTS ne ''", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the comments are not empty")
    public void Verify_the_comments_are_not_empty() throws Exception {
        Object comments = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    comments = Response.get("COMMENTS");
                    if (comments != "") {
                        reportInstance.logPass((String) comments, " - comments Not empty as expected");
                    }
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("comments is empty", (String) comments);
            throw e;
        }
    }


    @When("Create a GET request to Filter text attribute by ne operator and null value")
    public void Create_a_GET_request_to_Filter_text_attribute_by_ne_operator_and_null_value() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter text attribute by ne operator and null value");
        stringResponse = GetRequest(ApiConstants.Route_ACCESS_LEVEL_LIMITED + "?$filter=", "COMMENTS ne null", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the comments are not Null")
    public void Verify_the_comments_are_not_Null() throws Exception {
        String comments = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    comments = GetattributefromResponse(Response, "COMMENTS");
                    if (comments != null) {
                        reportInstance.logPass(comments, " - comments Not null as expected");
                    }
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("comments is empty", comments);
            throw e;
        }
    }

    @When("Create a GET request to Filter text attribute by length function and null value")
    public void Create_a_GET_request_to_Filter_text_attribute_by_length_function_and_null_value() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter text attribute by length function and null value");
        stringResponse = GetRequest(ApiConstants.Route_ACCESS_LEVEL_LIMITED + "?$filter=", "length(COMMENTS) eq null", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the comments are Null and length")
    public void Verify_the_comments_are_Null_and_length() throws Exception {
        Object comments = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    comments = Response.get("COMMENTS");
                    while (comments != "") {
                        if (comments == null) {
                            reportInstance.logPass((String) comments, " - comments null as expected");
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("comments is empty", (String) comments);
            throw e;
        }
    }

    @When("Create a GET request to Filter text attribute by length function and zero")
    public void Create_a_GET_request_to_Filter_text_attribute_by_length_function_and_zero() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter text attribute by length function and zero");
        stringResponse = GetRequest(ApiConstants.Route_ACCESS_LEVEL_LIMITED + "?$filter=", "length(COMMENTS) eq 0", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the comments lenght is zero")
    public void Verify_the_comments_lenght_is_zero() throws Exception {
        Object comments = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    comments = Response.get("COMMENTS");
                    while (comments.equals("")) {
                        reportInstance.logPass((String) comments, " - zero as expected");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("comments is empty", (String) comments);
            throw e;
        }
    }

    @When("Create a GET request to Filter by concatenate text attribute name with null")
    public void Create_a_GET_request_to_Filter_by_concatenate_text_attribute_name_with_null() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter by concatenate text attribute name with null");
        stringResponse = GetRequest(ApiConstants.Route_ACCESS_LEVEL_LIMITED + "?$filter=", "concat(COMMENTS, null) eq 'comment test'", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the comments concatenate with null")
    public void Verify_the_comments_concatenate_with_null() throws Exception {
        Object comments = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    comments = Response.get("COMMENTS");
                    if (comments.equals(expcomment)) {
                        reportInstance.logPass((String) comments, " - comments as expected");
                    }
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("comments is empty", (String) comments);
            throw e;
        }
    }

    @When("Create a GET request to Filter by concatenate text attribute name with empty")
    public void Create_a_GET_request_to_Filter_by_concatenate_text_attribute_name_with_empty() throws Exception {
        reportInstance.logInfo("STEPS : ", "GET request to Filter by concatenate text attribute name with empty");
        stringResponse = GetRequest(ApiConstants.Route_ACCESS_LEVEL_LIMITED + "?$filter=", "concat(COMMENTS, '') eq 'comment test'", HttpURLConnection.HTTP_OK);
        Response = StringToJSONObject(stringResponse);
    }

    @Then("Verify the comments concatenate with empty")
    public void Verify_the_comments_concatenate_with_empty() throws Exception {
        Object comments = "";
        try {
            JSONArray resp = JSONObjectToJsonArray(Response, "value");
            if (resp.size() > 0) {
                for (int i = 0; i < resp.size(); i++) {
                    String firstresp = resp.get(i).toString();
                    Response = StringToJSONObject(firstresp);
                    comments = Response.get("COMMENTS");
                    if (comments.equals(expcomment)) {
                        reportInstance.logPass((String) comments, " - comments as expected");
                    }
                }
            }
        } catch (Exception e) {
            this.reportInstance.logFail("comments is empty", (String) comments);
            throw e;
        }
    }
}
