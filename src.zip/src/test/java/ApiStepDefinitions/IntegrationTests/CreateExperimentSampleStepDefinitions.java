package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.api.APIHelper;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.runner.Request;

import java.net.HttpURLConnection;

public class CreateExperimentSampleStepDefinitions extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateExperimentSample";

    @Given("Login with valid username and password")

    public void login_with_valid_username_and_password() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login with valid username and password");
        Readprerequest();
    }

    @When("POST the request to Create new Sample with POCO Attributes")
    public void post_the_request_to_create_new_sample_with_poco_attributes() throws Exception
    {
        reportInstance.logInfo("","Create a POST request to create new Sample with POCO Attributes");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateSample.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TEST_EXPERIMENT_SAMPLE_CREATE_SAMPLE,UpdateRequestHeader("Accept","application/json"),HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity Type name for experiment sample with POCO Attributes")

    public void verify_the_entity_type_name_for_experiment_sample_with_poco_attributes() throws Exception
    {
        reportInstance.logInfo("","Verify the Entity Type name for experiment sample with POCO Attributes ");
//        JSONArray value=JSONObjectToJsonArray(Response,"value");
//        reportInstance.logInfo("",value.toString());
//        JSONObject innerValueReponse= (JSONObject) value.get(0);
//        reportInstance.logInfo("",innerValueReponse.toString());
        VerifyEntityData(Response,"EntityTypeName","TEST_EXPERIMENT_SAMPLE_CREATE_SAMPLE");


    }

    @When("POST the request to Create new Sample with binding missed")
    public void post_the_request_to_create_new_sample_with_binding_missed() throws Exception
    {
        reportInstance.logInfo("","Create a POST the request to Create new Sample with binding missed");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateSampleBindingMissed.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TEST_EXPERIMENT_SAMPLE_CREATE_SAMPLE,UpdateRequestHeader("Accept","application/json"),HttpURLConnection.HTTP_SERVER_ERROR);

    }

    @Then("Verify the error message with sample entity association not provided for sample with binding missed")
    public void verify_the_error_message_with_sample_entity_association_not_provided_for_sample_with_binding_missed() throws Exception
    {
        reportInstance.logInfo("","Verify the error message with sample entity association not provided");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","5000","Sample Entity Association is not provided. ");

        //VerifyErrorMessage(Response, ApiConstants.Route_ExperimentSampleCreate,"Property 'QueueProjectBarcode' is set to an invalid value, 'AFM1' does not point to an entity with type 'PROJECT'");
    }

    @When("POST the request to Create new Sample With Bad Binding")
    public void post_the_request_to_create_new_sample_with_bad_binding() throws Exception
    {
        reportInstance.logInfo("","Create a POST request to Create new Sample With Bad Binding");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateSampleBindingMissed.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_TEST_EXPERIMENT_SAMPLE_CREATE_SAMPLE,UpdateRequestHeader("Accept","application/json"),HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Bad Binding")
    public void verify_the_error_message_for_bad_binding() throws Exception
    {
        reportInstance.logInfo("","Verify the error message for Bad Binding");
        VerifyErrorMessage(Response,"1001","Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name 'UNEXIST_EXPERIMENT'.");

    }

}

