package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateSampleStepDefinitions extends DBHelper {

    JSONObject Response;
    String stringResponse;
    String RequestUnescapedName;
    String ResourcePath = "/IntegrationTests/Actions/CreateSample";

    @Given("Login into ODATA to create Sample")

    public void login_into_ODATA_to_create_sample() throws Exception {
        reportInstance = SharedClassApi.getReportInstance();
        reportInstance.logInfo("", "Login into ODATA to create Sample");
        Readprerequest();
    }

    @When("POST the request to Create Stability Sample")

    public void post_the_request_to_create_stability_sample() throws Exception {
        reportInstance.logInfo("", "POST the request to Create Stability Sample");
        RequestUnescapedName="StabilityEntity_"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the sample");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateStabilitySample.json");
        Request.put("Name",RequestUnescapedName);
        Response = postRequest(Request.toString(), ApiConstants.Route_STABILITY_SAMPLE, UpdateRequestHeader("Accept", "application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity type name of Stability Sample created")

    public void verify_the_entity_type_name_of_stability_sample_created() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Stability Sample created");

        VerifyEntityData(Response,"EntityTypeName","STABILITY_SAMPLE");
    }

    @When("POST the request to create Stability Sample Lot")

    public void post_the_request_to_create_stability_sample_lot() throws Exception {
        reportInstance.logInfo("", "POST the request to create Stability Sample Lot");
        RequestUnescapedName="StabilitySampleLot_"+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("STEPS",RequestUnescapedName+" will be sending in the request to create the sample");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateStabilitySampleLot.json");
        Request.put("Name",RequestUnescapedName);
        Response = postRequest(Request.toString(), ApiConstants.Route_STABILITY_SAMPLE_LOT, UpdateRequestHeader("Accept", "application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity type name of Stability Sample Lot created")

    public void verify_the_entity_type_name_of_stability_sample_lot_created() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Stability Sample Lot created");

        VerifyEntityData(Response,"EntityTypeName","STABILITY_SAMPLE_LOT");
    }

    @When("POST the request to create Bad Stability Sample Lot")

    public void post_the_request_to_create_bad_stability_sample_lot() throws Exception {
        reportInstance.logInfo("", "POST the request to create Bad Stability Sample Lot");
        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateBadStabilitySample.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_STABILITY_SAMPLE_LOT, UpdateRequestHeader("Accept", "application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Bad Stability Sample Lot")

    public void verify_the_error_message_for_bad_stability_sample_lot() throws Exception {
        reportInstance.logInfo("","Verify the error message for Bad Stability Sample Lot");
        VerifyErrorMessage(Response,"2002","Can`t find navigation property with name: 'NOT_IMPLEMENT_SAMPLE'.");

    }

    @When("Send GET request to get sample with blank attribute and navigation non mandatory")

    public void send_GET_request_to_get_sample_with_blank_attribute_and_navigation_non_mandatory() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send GET request to get sample with blank attribute and navigation non mandatory");
        stringResponse = GetRequest(ApiConstants.Route_TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE,"");
        Response = StringToJSONObject(stringResponse);

    }

    @Then("Verify the Entity type name of Sample with blank attribute and navigation non mandatory")

    public void verify_the_entity_type_name_of_sample_with_blank_attribute_and_navigation_non_mandatory() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Sample with blank attribute and navigation non mandatory");

        VerifyEntityData(Response,"EntityTypeName","TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE");

    }

    @When("POST the request to create Sample with blank attribute and navigation mandatory")

    public void post_the_request_to_create_sample_with_blank_attribute_and_navigation_mandatory() throws Exception {
        reportInstance.logInfo("", "POST the request to create Sample with blank attribute and navigation mandatory");
        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateSampleWithBlankAttributeAndNavigationMandatory.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE, UpdateRequestHeader("Accept", "application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Sample with blank attribute and navigation mandatory")

    public void verify_the_error_message_for_sample_with_blank_attribute_and_navigation_mandatory() throws Exception {
        reportInstance.logInfo("","Verify the error message for Sample with blank attribute and navigation mandatory");
        VerifyErrorMessageWithinDetails(Response,"3000","Error creating entity","3008","Mandatory Attribute is mandatory but has no data,MANDATORY ASSOCIATION SAMPLE is mandatory but has no associations");

    }

    @When("Send GET request to get sample with location and project default")

    public void send_GET_request_to_get_sample_with_location_and_project_default() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send GET request to get sample with location and project default");
        stringResponse = GetRequest(ApiConstants.Route_TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE,"");
        Response = StringToJSONObject(stringResponse);

    }

    @Then("Verify the Entity type name of Sample with location and project default")

    public void verify_the_entity_type_name_of_sample_with_location_and_project_default() throws IOException {
        reportInstance.logInfo("","Verify the Entity type name of Sample with location and project default");

        VerifyEntityData(Response,"EntityTypeName","TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE");

    }

    @When("POST the request to create Sample with reject on rule break with message")

    public void post_the_request_to_create_sample_with_reject_on_rule_break_with_message() throws Exception {
        reportInstance.logInfo("", "POST the request to create Sample with reject on rule break with message");
        JSONObject Request = ReadJsonInput(ResourcePath + "/CreateSampleWithRejectOnRuleBreakWithMessage.json");
        Response = postRequest(Request.toString(), ApiConstants.Route_TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE, UpdateRequestHeader("Accept", "application/json"), HttpURLConnection.HTTP_BAD_REQUEST);

    }

    @Then("Verify the error message for Sample with reject on rule break with message")

    public void verify_the_error_message_for_sample_with_reject_on_rule_break_with_message() throws Exception {
        reportInstance.logInfo("","Verify the error message for Sample with reject on rule break with message");
        VerifyErrorMessage(Response,"3000","Error creating entity");

    }

    @When("Send GET request to get Sample with empty body")

    public void send_GET_request_to_get_sample_with_empty_body() throws Exception {
        reportInstance.logInfo("STEPS : ", "Send GET request to get Sample with empty body");
        stringResponse = GetRequest(ApiConstants.Route_SAMPLE_TO_CREATE_WITH_BLANK_BODY,"");
        Response = StringToJSONObject(stringResponse);
    }
    @Then("Verify the Entity type name of Sample with empty body")

    public void verify_the_entity_type_name_of_sample_with_empty_body() throws Exception {
        reportInstance.logInfo("","Verify the Entity type name of Sample with empty body");
        JSONArray value = JSONObjectToJsonArray(Response, "value");
        while (value.size() > 0) {
            for (int i = 0; i < value.size(); i++) {
                String resp = value.get(i).toString();
                Response = StringToJSONObject(resp);
                VerifyEntityData(Response,"EntityTypeName","SAMPLE_TO_CREATE_WITH_BLANK_BODY");
            }
            break;
        }
    }
}
