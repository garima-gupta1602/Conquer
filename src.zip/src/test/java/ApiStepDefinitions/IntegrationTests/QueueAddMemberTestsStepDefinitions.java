package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class QueueAddMemberTestsStepDefinitions extends DBHelper
{
    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions";
    @Given("Login into ODATA to queue add members")
    public void login_into_odata_to_queue_add_members() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to queue add members");
        Readprerequest();
    }
    @When("Create a POST request to add queue member with metadata in minimal mode")
    public void create_a_post_request_to_add_queue_member_with_metadata_in_minimal_mode() throws Exception
    {
        reportInstance.logInfo("","Create a POST request to add queue member");
        JSONObject Request=ReadJsonInput(ResourcePath+"/AddMemberWithMetadata.json");
        reportInstance.logInfo("",Request.toString());

        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.addmembers), UpdateRequestHeader("Accept","application/json;odata.metadata=minimal"),HttpURLConnection.HTTP_OK);

    }
    @Then("Verify the Entity Type Name is PRIORITIZATION QUEUE")
    public void verify_the_entity_type_name_is_prioritization_queue() throws Exception
    {
        reportInstance.logInfo("","Verify the Entity Type Name is PRIORITIZATION QUEUE");
        JSONArray value=JSONObjectToJsonArray(Response,"value");
        reportInstance.logInfo("",value.toString());
        JSONObject innerValueReponse= (JSONObject) value.get(0);
        reportInstance.logInfo("",innerValueReponse.toString());
        VerifyEntityData(innerValueReponse,"EntityTypeName","PRIORITIZATION_QUEUE_MEMBER");
    }
    @When("Create a POST request to add queue member with metadata in none mode")
    public void create_a_post_request_to_add_queue_member_with_metadata_in_none_mode() throws Exception
    {
        reportInstance.logInfo("","Create a POST request to add queue member");
        JSONObject Request=ReadJsonInput(ResourcePath+"/AddMemberWithMetadata.json");
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.addmembers), UpdateRequestHeader("Accept","application/json;odata.metadata=none"),HttpURLConnection.HTTP_OK);
    }

    @When("Create a POST request with out of range priority")
    public void create_a_post_request_to_add_queue_member_with_out_of_range_priority() throws Exception
    {
        reportInstance.logInfo("","POST request with out of range priority");
        JSONObject Request=ReadJsonInput(ResourcePath+"/AddMemberwithOutofRangePriority.json");
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.addmembers),HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message for the out of range priority")
    public void verify_the_error_message_for_the_out_of_range_priority() throws Exception
    {
        reportInstance.logInfo("","Verify the error message for the out of range priority");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE,"Invalid value for property 'Priority'.");
    }

    @When("Create a POST request with invalid queue project")
    public void create_a_post_request_to_add_with_invalid_queue_project() throws Exception
    {
        reportInstance.logInfo("","POST request with invalid queue project");
        JSONObject Request=ReadJsonInput(ResourcePath+"/AddMemberwithInvalidQueueProject.json");
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_PRIORITIZATION_QUEUE.concat(ApiConstants.addmembers),HttpURLConnection.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message with invalid queue project")
    public void verify_the_error_message_with_invalid_queue_project() throws Exception
    {
        reportInstance.logInfo("","Verify the error message with invalid queue project");
        VerifyErrorMessage(Response, ApiConstants.ERROR_CODE_CREATING_ENTITY_DETAIL,"Property 'QueueProjectBarcode' is set to an invalid value, 'AFM1' does not point to an entity with type 'PROJECT'");
    }

}
