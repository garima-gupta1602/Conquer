package ApiStepDefinitions.IntegrationTests;

import ApiStepDefinitions.SharedClassApi;
import YETI.ApiConstants;
import com.db.DBHelper;
import com.mongodb.DB;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class CreateSampleLotStepDefinition extends DBHelper {

    JSONObject Response;
    String ResourcePath="/IntegrationTests/Actions/CreateSampleLot";

    @Given("Login into ODATA to create Sample lot")

    public void login_into_ODATA_to_create_sample_lot() throws Exception {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to create Sample lot");
        Readprerequest();
    }

    @When("POST the request to create Sample lot with increment Attribute")

    public void post_the_request_to_create_Sample_lot_with_increment_attribute() throws Exception {
        reportInstance.logInfo("","POST the request to create Sample lot with increment Attribute");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateSampleLotWithIncrementAttributeTriggerShouldWork.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity Type Name of Sample Lot With Increment Attribute")

    public void verify_the_entity_type_name_of_sample_lot_with_increment_attribute() throws IOException {
        reportInstance.logInfo("","Verify the Entity Type Name of Sample Lot With Increment Attribute");
        VerifyEntityData(Response,"EntityTypeName","SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT");
    }

    @When("POST the request to Create Sample Lot With Increment Attribute Trigger Should Not Work")

    public void post_the_request_to_Create_Sample_Lot_With_Increment_Attribute_Trigger_Should_Not_Work() throws Exception {
        reportInstance.logInfo("","POST the request to Create Sample Lot With Increment Attribute Trigger Should Not Work");
        JSONObject Request= ReadJsonInput(ResourcePath+"/CreateSampleLotWithIncrementAttributeTriggerShouldNotWork.json");
        Response =postRequest(Request.toString(), ApiConstants.Route_SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT,UpdateRequestHeader("Accept","application/json"), HttpURLConnection.HTTP_CREATED);

    }

    @Then("Verify the Entity Type Name of Sample Lot With Increment Attribute Trigger Should Not Work")

    public void verify_the_entity_type_name_of_sample_lot_with_increment_attribute_Trigger_Should_Not_work() throws IOException {
        reportInstance.logInfo("","Verify the Entity Type Name of Sample Lot With Increment Attribute Trigger Should Not Work");
        VerifyEntityData(Response,"EntityTypeName","SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT");
    }



}
