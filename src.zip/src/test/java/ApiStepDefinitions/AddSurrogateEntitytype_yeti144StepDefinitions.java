package ApiStepDefinitions;

import YETI.ApiConstants;
import YETI.DbQueries;
import com.db.DBHelper;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.HashMap;

public class AddSurrogateEntitytype_yeti144StepDefinitions extends DBHelper
{
    JSONParser parser = new JSONParser();
    Scenario scenario;
    JSONObject Response;
    String RequestUnescapedName;
    String ResourcePath="/SurrogateEntityType";
    String SuperTypeName;
    //DBHelper db=new DBHelper();

    @Given("Login into ODATA to Surrogate Entity Type")
    public void login_into_odata_to_surrogate_entity_type() throws Exception
    {
        reportInstance= SharedClassApi.getReportInstance();
        reportInstance.logInfo("","Login into ODATA to Surrogate Entity Type");
        Readprerequest();
    }
    @When("Post the request for Super Type")
    public void post_the_request_for_super_type() throws Exception
    {
        reportInstance.logInfo("","Post the request to Create Super Type");
        RequestUnescapedName="Test Name "+RandomAlphanumericGenerate(4);
        reportInstance.logInfo("",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperType.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response,"UnescapedName",RequestUnescapedName);
        SuperTypeName=GetattributefromResponse(Response,"Name");
    }
    @Then("Verify the DB for the super type only")
    public void verify_the_db_for_the_super_type_only() throws Exception
    {
        HashMap results=ExecuteQuery(DbQueries.SelectSuperTypeName+querySearchFormat(RequestUnescapedName));
        int DbValue=results.size();
        if(DbValue==1)
        {
            reportInstance.logPass(RequestUnescapedName," is created in the db");
        }else
        {
            reportInstance.logFail(RequestUnescapedName, " is not created in the db");
        }
        results=ExecuteQuery(DbQueries.SelectSuperTypeName+querySearchFormat(RequestUnescapedName+"_LIMITED"));
        DbValue=results.size();
        if(DbValue==0)
        {
            reportInstance.logPass(RequestUnescapedName,"_LIMITED is not created in the db as expected");
        }else
        {
            reportInstance.logFail(RequestUnescapedName,"_LIMITED is created in the db which is not expected");
        }
    }
    @Then("Verify the metadata for Limited")
    public void verify_the_metadata_for_limited() throws Exception
    {
        reportInstance.logInfo("","verified");
        String XMLResponse=GetRequest(ApiConstants.Route_MetaDataOnReload,"Metadata request");

        VerifyMetaDataEntity(XMLResponse,SuperTypeName);
    }

    @And("Verify the entity type DB for the Prefix size")
    public void verify_the_entity_type_db_for_the_prefix_size() throws Exception
    {
        String StrPrefixvalue=ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeforSuperTypeName+querySearchFormat(RequestUnescapedName),"prefix");
        reportInstance.logInfo("","Prefix value generated in the DB "+StrPrefixvalue);
        if(StrPrefixvalue.length()>=2&&StrPrefixvalue.length()<=9)
        {
            reportInstance.logPass(StrPrefixvalue," Prefix value is within the expected length");
        }else
        {
            reportInstance.logFail(StrPrefixvalue,"Prefix value is not within the expected length");
            throw new StringIndexOutOfBoundsException("String length is more than expected for prefix");
        }
    }
    @And("Verify the Sequence in DB")
    public void verify_the_sequnce_in_DB() throws Exception
    {
        String entity_type_id=ExecuteQueryToGetExpectedColumn(DbQueries.SelectEntityTypeforSuperTypeName+querySearchFormat(RequestUnescapedName),"entity_type_id");
        String sequnceName="et_"+entity_type_id+"_seq";
        HashMap results=ExecuteQuery(DbQueries.SelectSequenceFromPgClass+querySearchFormat(sequnceName));
        int DbValue=results.size();
        if(DbValue==1)
        {
            reportInstance.logPass(sequnceName," is created in the db");
        }else
        {
            reportInstance.logFail(sequnceName, " is not created in the db");
        }
    }
    @When("Post the request for Super Type with special characters")
    public void post_the_request_for_super_type_with_special_characters() throws Exception
    {
        reportInstance.logInfo("","Post the request to Create Super Type");
        RequestUnescapedName="&#!*&# "+RandomAlphanumericGenerate(2)+" Test";
        reportInstance.logInfo("",RequestUnescapedName+" will be sending in the request to create the super type");
        JSONObject Request=ReadJsonInput(ResourcePath+"/CreateSuperType.json");
        Request.put("UnescapedName",RequestUnescapedName);
        reportInstance.logInfo("",Request.toString());
        Response = postRequest(Request.toString(), ApiConstants.Route_SuperType, HttpURLConnection.HTTP_CREATED);
        VerifyEntityData(Response,"UnescapedName",RequestUnescapedName);
        SuperTypeName=GetattributefromResponse(Response,"Name");
    }
}
