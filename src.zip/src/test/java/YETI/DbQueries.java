package YETI;

public class DbQueries {
    public static final String SelectSuperTypeName = "select * from super_type where super_type_name=";
    public static final String SelectEntityTypeforSuperTypeName = "select * from entity_type where entity_type_name=";
    public static final String SelectSequenceFromPgClass = "select * from pg_class c where c.relkind = 'S'and c.relname = ";
    public static final String SelectAttributeName = "select * from attribute a2, entity_type_attribute eta where a2.attribute_id=eta.attribute_id and attribute_name=";
    public static final String RETRIEVE_SUPER_TYPE_ATTRIBUTES = "select a.attribute_name, st.super_type_name from super_type_attribute sta\n" + "inner join attribute a on sta.attribute_id = a.attribute_id\n"
            + "inner join super_type st on sta.super_type_id = st.super_type_id\n" + "where st.super_type_name = '{superTypeNameAnchor}' and a.attribute_name = '{attributeNameAnchor}';";
    public static final String IS_EMPLOYEE_EXISTENT = "select count(*) as number_employee from employee_entity ee \n" +
            "\twhere ci_global_user_id = '{globalUserIdAnchor}'\n" +
            "\tand ci_full_name = '{fullNameAnchor}'\n" +
            "\tand ci_email_address = '{emailAnchor}';";
    public static final String SelectListCreation = "select * from entity_list where entity_list_id='BARCODE' and entity_type = 'ENTITY TYPE' order by entity_list_id desc;";
    //Conquer
    public static final String sequenceQuery = "SELECT setval('lims_seq', 2147483648, true);";
    public static final String SelectEntityType = "select * from entity_type where entity_type_name=";
    public static final String SelectEntityTypeAttribute = "select * from entity_type_attribute where column_header =";
    public static final String SelectAttribute = "select * from attribute where attribute_name =";
    public static final String SelectSuperTypeAttribute = "select * from Super_type_attribute where attribute_id =";
    public static final String RetrieveEntityID = "select * from entity where entity_name=";
    public static final String SelectEntityAssociation = "select * from entity_association where entity_id_1=";
    public static final String RetrieveEntityAssociationID = "select * from entity_association where entity_association_id=";
    public static final String SelectTypeAssociationID = "select * from type_association where type_association_id=";
    public static final String RetriveEAIDOfLongDataTypeBeerBatch = "select * from entity where barcode like 'BB%' order by created_on desc LIMIT 1;";
    public static final String SelectEntityIDFromEntity = "select * from entity where entity_id = ";
    public static final String selectEventIdFromEntityEvent = "select * from entity_event where entity_id =";
    public static final String selectEventIdFromEvent = "select * from entity_event where event_id =";
    public static final String RetriveEntityIDOfEvent = "select * from entity where barcode like 'EV%' order by created_on desc LIMIT 1;";
    public static final String SelectRecordIDOnEntityType = "select * from access_level_control where entity_type =";
    public static final String SelectRecordIDOnRawData = "select * from raw_data where record_id =";
    public static final String RetriveRecordIDOfRawData = "select * from raw_data order by created_on desc LIMIT 1;";
    public static final String SelectExperimentSampleIdOnExperimentSample = "Select * from experiment_sample where experiment_sample_id =";
    public static final String RetriveExperimentSampleIdOnExperimentSample = "Select * from experiment_sample order by created_on desc LIMIT 1;";
    public static final String RetriveEntityIdFromEntityForBeer = "select * from entity where barcode like 'BEE%'  order by created_on desc LIMIT 1;";
    public static final String SelectExperimentContainerId = "Select * from experiment_container where experiment_container_id =";
    public static final String RetriveExperimentContainerId = "Select * from experiment_container order by created_on desc LIMIT 1;";
    public static final String SelectFromFileBinary = "select * from file_binary where file_id =";
    public static final String RetrieveBarcode = "select * from entity where barcode = ";
    public static final String RetrieveEntityComment = "select * from entity_comment where entity_comment_id =";
    public static final String RetreiveListMemberId = "select * from list_member where list_member_id =";
    public static final String RetrieveCellID = "select * from cell where cell_id=";
    public static final String RetrieveContainerId = "select * from cell where container_id=";
    public static final String RETRIEVE_TYPE_ASSOCIATION = "select * from (select (select entity_type_name " +
            "from entity_type et2 where et2.entity_type_id = ta.entity_type_id_1 ) as entity_type_1_name, \n" +
            "(select entity_type_name from entity_type et2 where et2.entity_type_id = ta.entity_type_id_2  ) as entity_type_2_name, " +
            "ta.* from type_association ta) as taa " +
            " where taa.Entity_Type_1_Name = '{sourceEntityType}' and taa.Entity_Type_2_Name = '{targetEntityType}' and taa.predicate = '{context}'";
    public static final String SelectLotId = "Select * from lot where lot_id =";
    public static final String RetrieveSampleLotBarCode = "select * from entity where barcode like 'BS2%' order by created_on desc LIMIT 1;";
    public static final String RetrieveBarCodeFromEntityTbl = "select * from entity where barcode like";
    public static final String SelectExperimentDataId = "Select * from experiment_data where experiment_sample_id =";
    public static final String SelectAuditLogId = "Select * from audit_log where entity_id =";
    public static final String alterSequenceQuery = "alter sequence lims_seq restart with 2147483648;";
    public static final String SelectValueId = "Select * from value where entity_id =";
    public static final String SelectValueViewId = "Select * from value_view where entity_id =";
    public static final String selectExperimentDataVersionId = "select * from experiment_data_version order by created_on desc LIMIT 1";
    public static final String selectEntityTypePrefix = "select * from entity_type where entity_type_id = ";
    public static final String selectLocationId = "select * from location where location_id  = ";
    public static final String SelectEntityIDWithEntityTypeId = "select * from entity where entity_type_id = ";
    public static final String RetrieveEntityIDWithOrderBy = "select * from entity order by created_on desc limit 1";
    public static final String RetrieveAttributeData = "Select * from value where string_data =";
    public static final String RetrieveEntityLockedId= "select * from entity where locked  = 1 and Barcode like 'PQ%' limit 1";
    public static final String RetrieveEntityTypeEsignReq= "select * from entity_type where require_signature  = 1 limit 1";
    public static final String SelectAssociatedEntityID =  "select * from entity_association where entity_id_2 in(entityId2) and entity_id_1 = entityId1";
}