package YETI;

import java.security.PublicKey;

public class ApiConstants
{
    //API Layers
    public static final String Route_SuperType="entity-service/odata/SUPER_TYPE";
    public static final String Route_TypeAttribute="entity-service/odata/TYPE_ATTRIBUTE";
    public static final String Route_MetaDataOnReload="entity-service/odata/$metadata?reload=true";
    public static final String Route_MetaData="entity-service/odata/$metadata";
    public static final String Route_PrioritizationQueue="entity-service/odata/PRIORITIZATION_QUEUE('PQ1')/pfs.AddMembers";
    public static final String Route_PrioritizationQueueFill_PQ1="entity-service/odata/PRIORITIZATION_QUEUE('PQ1')/pfs.FulfillQueueMembers";
    public static final String Route_master="entity-service/odata";
    //public static final String Route_Publish_Experiment="entity-service/odata/EXPERIMENT('PET1')/pfs.Experiment.Publish";

    public static final String Route_ExpandLocationByActive="entity-service/odata/ANIMAL_SUBJECT_ACCESS_TEST?$expand=LOCATION($filter=Active eq true)";
    public static final String Route_EmployeeFilterByActive="entity-service/odata/ANIMAL_SUBJECT_ACCESS_TEST?$expand=CREATED_BY($filter=Active eq true)";
    public static final String Route_ReverseNavigationFilterByActive="entity-service/odata/ANIMAL_SUBJECT_ACCESS_TEST?$expand=REV_COMBINE_FILTER_CONDITIONS_NAVIGATION($filter=Active eq true)";

    //Already Scenario
    public static final String Route_Publish_Experiment_AlreadyScenario_PET4="entity-service/odata/EXPERIMENT('PET4')/pfs.Experiment.Publish";
    public static final String Route_Publish_Experiment_Test_NotPublished_PET6="entity-service/odata/PUBLISH_EXPERIMENT_TEST('PET6')/pfs.Experiment.Unpublish";

    //Header Values
    public static final String Header_Cache_Control="no-cache";
    public static final String Header_Content_Type="application/json";
    public static final String Header_Connection="keep-alive";
    public static final String Header_User_Agent="Mozilla/5.0";
    public static final String Header_Accept="*/*";
    public static final String Header_Accept_Encoding="gzip, deflate, br";

    //Error Codes

    /** Error code of reading entity */
    public static final String ERROR_CODE_CANNOT_CHANGE="5000";
    public static final String ERROR_CODE_CREATING_CONTENT_ENTITY = "3010";
    public static final String ERROR_CODE_CREATING_DUPLICATE_KEY_CONSTRAINT_VIOLATED = "5002";
    /** Error code of reading entity */
    public static final String ERROR_CODE_NO_PERMISSION = "6000";
    /** Error code of reading entity */
    public static final String ERROR_CODE_READING_ENTITY = "3003";

    /** Error message of reading entity */
    public static final String ERROR_MESSAGE_READING_ENTITY = "Error reading entity";

    /** Error code of creating entity */
    public static final String ERROR_CODE_CREATING_ENTITY = "3000";

    /** Error code of creating entity with invalid parameter */
    public static final String ERROR_CODE_WITH_INVALID_PARAMETER_CREATING_ENTITY = "2005";

    /** Error message of creating entity */
    public static final String ERROR_MESSAGE_CREATING_ENTITY = "Error creating entity";

    /** Error code of updating entity */
    public static final String ERROR_CODE_UPDATING_ENTITY = "3001";

    /** Error message of updating entity */
    public static final String ERROR_MESSAGE_UPDATING_ENTITY = "Error updating entity";

    /** Error code of entity not found entity */
    public static final String ENTITY_NOT_FOUND_ERROR_CODE = "3004";

    /** Error message of entity not found entity */
    public static final String ENTITY_NOT_FOUND_ERROR_MESSAGE = "Entity not found";

    /** Blank Request Body */
    public static final String BLANK_REQUEST_BODY = "{ }";

    /** URL parameter added to support encoding space to plus in query option */
    public static final String ODATA_ACCEPT_FORM_ENCODING_URL_PARAMETER = "&odata-accept-forms-encoding=true";

    /** Error code of creating entity */
    public static final String ERROR_CODE_CREATING_ENTITY_DETAIL = "3008";

    /** Error code of mandatory attribute missing */
    public static final String ERROR_CODE_MANDATORY_ATTRIBUTE_MISSING_DETAIL = "3008";

    /** Error code of getting non-existing entity type */
    public static final String ERROR_CODE_GET_NON_EXISTING_ENTITY_TYPE = "1001";

    /** Error message of getting non-existing entity type */
    public static final String ERROR_MESSAGE_GET_NON_EXISTING_ENTITY_TYPE = "Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name ";

    /** Detailed Error message of creating entity with enforce project security enabled */
    public static final String ERROR_MESSAGE_CREATING_ENTITY_ENFORCE_PROJECT_SECURITY_ENABLED_DETAIL = "Project Level control denied for user";

    /** Error code of Not Found entity */
    public static final String ERROR_CODE_ENTITY_NOT_FOUND = "1001";

    /** Error message of Not Found entity */
    public static final String ERROR_MESSAGE_ENTITY_NOT_FOUND = "Cannot find EntitySet, Singleton, ActionImport or FunctionImport with name";

    /** Error message of missing non nullale properties which do not have default values */
    public static final String ERROR_MESSAGE_MISSING_NON_NULLABLE_PROPERTIES =
        "Non nullable properties without default values are required to be included in the payload for PUT requests. Missing properties: .*";

    /** Error code of missing non nullale properties which do not have default values */
    public static final String ERROR_CODE_MISSING_NON_NULLABLE_PROPERTIES = "2005";

    /** Error code of setting non nullale properties which do not have default values to null */
    public static final String ERROR_CODE_SETTING_NON_NULLABLE_PROPERTIES_NULL = "2002";

    /** Error message of updating attribute with invalid value */
    public static final String ERROR_CODE_UPDATE_ATTRIBUTE_WITH_INVALID_VALUE = "2002";

    /** Error message of setting non nullale properties which do not have default values to null */
    public static final String ERROR_MESSAGE_SETTING_NON_NULLABLE_PROPERTIES_NULL = "The property .* must not be null.";

    /** Error code of creating Entity Type Attribute */
    public static final String ERROR_CODE_CREATING_ATTRIBUTE = "3011";

    /** Charset support for Localization */
    public static final String CHARSET = "charset=UTF-8";

    //User Defined Exceptions
    public static final String SqlConnectionException="Not connected to the Postgresql";
    //Route for Attirbute
    // GET Roure - INTEGRATION Test
    public static final String Route_Type_Attribute = "entity-service/odata/TYPE_ATTRIBUTE";
    public static final String Route_Type_Association= "entity-service/odata/TYPE_ASSOCIATION";
    public static final String Route_Update_Type_Association= "entity-service/odata/TYPE_ASSOCIATION(17364485)";
    //Filter Routes:
    public static final String Route_Update_Type_Attribute="entity-service/odata/TYPE_ATTRIBUTE(17294150)";

//Integration Tests - Delete
    public static final String Route_Delete_Small_Molecule="('BTES6583')";
    public static final String Str_ASSOCIATION_ACCESS_TEST="ASSOCIATION_ACCESS_TEST";
    public static final String str_US_ANIMAL_REQUEST_ACCESS_TEST="US_ANIMAL_REQUEST_ACCESS_TEST";

    //GET Request on LIST - Regression
    public static final String Route_LIST_GET_Animal_Subject="entity-service/odata/ANIMAL_SUBJECT?$filter=";
    public static final String Route_LIST_GET_Animal_Subject_Access_Test_Expand="entity-service/odata/ANIMAL_SUBJECT_ACCESS_TEST?$expand=";
    public static final String Route_LIST_GET_General_Expand="entity-service/odata/GENERAL_LIST?$expand=";
    public static final String Route_LIST_GET_General_List_Expand="entity-service/odata/GENERAL_LIST('GENLST1')?$expand=";
    public static final String Route_LIST_GET_ReportFormat="entity-service/odata/LIST/pfs.REPORT_FORMAT";
    //POST Request on LIST - Regression
    public static final String Route_LIST_General="entity-service/odata/GENERAL_LIST";
    public static final String Route_LIST_General_AddMembers="entity-service/odata/GENERAL_LIST('GENLST45')/pfs.AddMembers";
    public static final String Route_LIST_General_Invalid="entity-service/odata/GENERAL_LIST('GENLST45-Invalid')/pfs.AddMembers";
    public static final String Route_LIST_General_AddMembers_Expand="entity-service/odata/GENERAL_LIST('GENLST5')?$expand=LIST_MEMBERS($expand=MEMBER)";
    public static final String Route_LIST_General_RemoveMembers="entity-service/odata/GENERAL_LIST('GENLST5')/pfs.RemoveMembers";

//Integration Tests - Get
    public static final String Route_GetExperimentEntity="('EXPERIMENT')?$expand=";
    public static final String Route_InvalidPrioritizationQueue="entity-service/odata/PRIORITIZATION_QUEUE('PQ6')/pfs.AddMembers";
    //Route for new entity type
    public static final String Route_Entity_Type="entity-service/odata/ENTITY_TYPE";

    //Route for Preference Return
    public static final String Route_Preference = "entity-service/odata/SAMPLE_TO_CREATE_WITH_BLANK_BODY";

    //Route for Unsupported
    public static final String Route_unsupported ="entity-service/odata/ANIMAL_SUBJECT_ACCESS_TEST?$filter=";

    //Route for Entity
    public static final String Route_Entity = "entity-service/odata/ENTITY?$filter=";

    //Route for Entity
    public static final String Route_People = "entity-service/odata/PEOPLE";

    //public static final String Route_IntermediateExperimentSampleAssayData="entity-service/odata/INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE('BTES1')/INTERMEDIATE_ASSAY_DATA/pfs.INTERMEDIATE_BITTERNES";

//Generic Routes

    public static final String Route_ANIMAL_SUBJECT_ACCESS_TEST = "entity-service/odata/ANIMAL_SUBJECT_ACCESS_TEST";
    public static final String Route_CRITTER = "entity-service/odata/CRITTER";
    public static final String Route_DEFAULT_ATTRIBUTE ="entity-service/odata/DEFAULT_ATTRIBUTE";
    public static final String Route_ENTITY_MASTER = "entity-service/odata/ENTITY";
    public static final String Route_EXPERIMENT = "entity-service/odata/EXPERIMENT";
    public static final String Route_PUBLISH_EXPERIMENT_TEST = "entity-service/odata/PUBLISH_EXPERIMENT_TEST";
    public static final String Route_PRIORITIZATION_QUEUE = "entity-service/odata/PRIORITIZATION_QUEUE";
    public static final String Route_CONTAINER = "entity-service/odata/CONTAINER";
    public static final String Route__2WellPlate = "entity-service/odata/_2_WELL_PLATE";
    public static final String Route_NURSE = "entity-service/odata/NURSE";
    public static final String Route_TEST_FILTER_NULL="entity-service/odata/TEST_FILTER_NULL";
    public static final String Route_PROJECT = "entity-service/odata/PROJECT";
    public static final String Route_ACCESS_LEVEL_LIMITED = "entity-service/odata/ACCESS_LEVEL_LIMITED";
    public static final String Route_US_ANIMAL_REGISTRATION ="entity-service/odata/US_ANIMAL_REGISTRATION";
    public static final String Route_COMMENT = "entity-service/odata/COMMENT";
    public static final String Route_CHEMICAL_PRODUCER= "entity-service/odata/CHEMICAL_PRODUCER";
    public static final String Route_VIAL = "entity-service/odata/VIAL";
    public static final String Route__96_WELL_PLATE = "entity-service/odata/_96_WELL_PLATE";
    public static final String Route_KI_DETERMINATION = "entity-service/odata/KI_DETERMINATION";
    public static final String Route_TURBIDITY_EXPERIMENT_CONTAINER = "entity-service/odata/TURBIDITY_EXPERIMENT_CONTAINER";
    public static final String Route_BITTERNESS_EXPERIMENT_CONTAINER = "entity-service/odata/BITTERNESS_EXPERIMENT_CONTAINER";
    public static final String Route_TEST_EXPERIMENT_SAMPLE_CREATE_SAMPLE = "entity-service/odata/TEST_EXPERIMENT_SAMPLE_CREATE_SAMPLE";
    public static final String Route_INGREDIENT_FOR_TEST_DEFAULT_VALUE = "entity-service/odata/INGREDIENT_FOR_TEST_DEFAULT_VALUE";
    public static final String Route_TEST_FOR_ESIGNATURE = "entity-service/odata/TEST_FOR_ESIGNATURE";
    public static final String Route_INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE = "entity-service/odata/INTERMEDIATE_BITTERNESS_EXPERIMENT_SAMPLE";
    public static final String Route_SITE = "entity-service/odata/SITE";
    public static final String Route_LOCATION = "entity-service/odata/LOCATION";
    public static final String Route_RAW_DATA = "entity-service/odata/RAW_DATA";
    public static final String Route_STABILITY_SAMPLE = "entity-service/odata/STABILITY_SAMPLE";
    public static final String Route_STABILITY_SAMPLE_LOT = "entity-service/odata/STABILITY_SAMPLE_LOT";
    public static final String Route_TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE = "entity-service/odata/TEST_INTEGRATION_FOR_CREATE_NEW_SAMPLE";
    public static final String Route_SAMPLE_TO_CREATE_WITH_BLANK_BODY = "entity-service/odata/SAMPLE_TO_CREATE_WITH_BLANK_BODY";
    public static final String Route_SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT = "entity-service/odata/SAMPLE_FOR_CHECK_INCREMENT_TRIGGER_LOT";
    public static final String Route_QUEUE = "entity-service/odata/QUEUE";
    public static final String Route_ANIMAL_SUBJECT = "entity-service/odata/ANIMAL_SUBJECT";
    public static final String Route_BITTERNESS_EXPERIMENT_SAMPLE = "entity-service/odata/BITTERNESS_EXPERIMENT_SAMPLE";
    public static final String Route_EMPLOYEE = "entity-service/odata/EMPLOYEE";
    public static final String Route_SAMPLE_FOR_DATETIME_FILTERING = "entity-service/odata/SAMPLE_FOR_DATETIME_FILTERING";
    public static final String Route_SMALL_MOLECULE = "entity-service/odata/SMALL_MOLECULE";
    public static final String Route_SAMPLE_FOR_REFERENCE_NAVIGATION_PROPERTY ="entity-service/odata/SAMPLE_FOR_REFERENCE_NAVIGATION_PROPERTY";
    public static final String Route_SUPPLIER_LIMITED = "entity-service/odata/SUPPLIER_LIMITED";
    public static final String Route_BITTERNESS_EXPERIMENT = "entity-service/odata/BITTERNESS_EXPERIMENT";
    public static final String Route_PRIORITIZATION_QUEUE_MEMBER = "entity-service/odata/PRIORITIZATION_QUEUE_MEMBER";
    public static final String Route_ENTITY_TYPE = "entity-service/odata/ENTITY_TYPE";
    public static final String Route_SUPER_TYPE = "entity-service/odata/SUPER_TYPE";
    public static final String Route_IMAGE = "entity-service/odata/IMAGE";
    public static final String Route_IMAGE_MANIPULATOR= "entity-service/odata/IMAGE_MANIPULATOR";
    public static final String Route_CELL= "entity-service/odata/CELL";
    public static final String Route_US_BODY_WEIGHT_EXPERIMENT = "entity-service/odata/US_BODY_WEIGHT_EXPERIMENT";
    public static final String Route_SMALL_MOLECULE_LOT = "entity-service/odata/SMALL_MOLECULE_LOT";
    public static final String Route_96_WELL_MICRO_TITER = "entity-service/odata/_96_WELL_MICRO_TITER";
    public static final String Route_ANIMAL_LIMITED = "entity-service/odata/ANIMAL_LIMITED";
    public static final String Route_EMPLOYEE_LIMITED = "entity-service/odata/EMPLOYEE_LIMITED";

    public static final String Route_GetAssociatedApplications="entity-service/odata/GetAssociatedApplications()";
    public static final String Route_GetAssociatedEntityTypes="entity-service/odata/GetAssociatedEntityTypes";
    public static final String Route_GetAssociatedNavigations="entity-service/odata/GetAssociatedNavigations";
    public static final String Route_Associated_Sample="entity-service/odata/ASSOCIATED_SAMPLE";
    public static final String Route_Associated_Sample_lot="entity-service/odata/ASSOCIATED_SAMPLE_LOT";
    public static final String Route_UNPUBLISH_ASSOCIATED_SAMPLE="entity-service/odata/UNPUBLISH_ASSOCIATED_SAMPLE";
    public static final String Route_UNPUBLISH_ASSOCIATED_SAMPLE_LOT="entity-service/odata/UNPUBLISH_ASSOCIATED_SAMPLE_LOT";
    public static final String Route_BatchRequest = "entity-service/odata/$batch";



 //Regression Test-ErrorHandling
    public static final String cell_quantity="entity-service/odata/CELL_QUANTITY_TYPE";
    public static final String decimal_agg_fun="entity-service/odata/DECIMAL_AGG_FUNCTIONS";
    public static final String negative_gustatory_assay="entity-service/odata/NEGATIVE_GUSTATORY_ASSAY_ATTRIBUTES_AGGREGATION";
    public static final String container_transfer="entity-service/odata/CONTAINER_TRANSFER";
    public static final String sample="entity-service/odata/SAMPLE('URIS1')";
    public static final String intermediate_assay="entity-service/odata/INTERMEDIATE_ASSAY_DATA('BTES1105')";
    public static final String bitterness_intermediate_assay="entity-service/odata/INTERMEDIATE_BITTERNESS_ASSAY_DATA('BTES1105')";
    public static final String nurse="entity-service/odata/NURSE('NURR44444')";



//Integration Tests - Actions
    public static final String inventory_move = "('EM1')/pfs.Entity.InventoryMove";
    public static final String GET_Experiment_PET1="('PET1')";
    public static final String GET_Experiment_Test_PET3="('PET3')";
    public static final String GET_Experiment_AlreadyScenario_PET4="('PET4')";
    public static final String UnPublish_Experiment_PET1 = "('PET1')/pfs.Experiment.Unpublish";
    public static final String Publish_Experiment_PET1 = "('PET1')/pfs.Experiment.Publish";
    public static final String Publish_Experiment_Test_PET3 ="('PET3')/pfs.Experiment.Publish";
    public static final String Unpublish_Experiment_Test_PET3 ="('PET3')/pfs.Experiment.Unpublish";
    public static final String addmembers = "('PQ1')/pfs.AddMembers";
    public static final String fulfillQueuemembers = "('PQ2')/pfs.FulfillQueueMembers";
    public static final String fulfillQueuemembers1  = "('PQ1')/pfs.FulfillQueueMembers";
    public static final String setCellContents = "('2WP300')/pfs.Container.SetCellContents";
    public static final String SetCellContent_2WellPlate= "('2WP2195')/pfs.Container.SetCellContents";

//Integration Tests - Create
    public static final String Route_IntermediateExperimentSampleAssayData = "('BTES1')/INTERMEDIATE_ASSAY_DATA/pfs.INTERMEDIATE_BITTERNES";
    public static final String Route_QUEUE_MEMBER_REFS = "?$expand=QUEUE_MEMBER_REFS";

    //Error code of header not supported
    public static final String ERROR_CODE_HEADER_NOT_SUPPORTED = "2000";

    //Error code for Unauthorized
    public static final String ERROR_CODE_UNAUTHORIZED = "401";

    //Conquer
    public static final String Route_Event="entity-service/odata/EVENT";
    public static final String Route_TypeAssociation="entity-service/odata/TYPE_ASSOCIATION";
    public static final String Route_BeerBatch="entity-service/odata/BEER_BATCH";

    public static final String Route_ExperimentSample="entity-service/odata/EXPERIMENT_SAMPLE";
    public static final String Route_Beer="entity-service/odata/BEER";
    public static final String Route_ExperimentContainer="entity-service/odata/EXPERIMENT_CONTAINER";
    public static final String Route_BeerSampleLot = "entity-service/odata/BEER_SAMPLE_LOT";
    public static final String Route_BeerOrder = "entity-service/odata/BEER_ORDER";
    public static final String Route_AssayData = "entity-service/odata/TURBIDITY_EXPERIMENT";
    public static final String Route_ExperimentDataVersion = "entity-service/odata/TURBIDITY_EXPERIMENT";
    public static final String Route_CONCENTRATION = "entity-service/odata/CONCENTRATION";
    public static final String Route_BODY_WEIGHT_ON_STUDY = "entity-service/odata/BODY_WEIGHT_ON_STUDY";
    public static final String Route_EntityType_Name = "entity-service/odata/";
    public static final String Route_ANIMAL_INTEGRITYCHECK = "entity-service/odata/ANIMAL_INTEGRITY_CHECK";
    public static final String Route_WORKER = "entity-service/odata/WORKER";
}
