package com.thermofisher.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class Initialize {

    /**
     * This method is used to load property values intto system property
     * @param propertyFileName - property file name
     */
    public static void setEnvironmentVariables(String propertyFileName) {
        try {
            Properties systemProp = new Properties();
            File propertyFile = new File(propertyFileName);
            FileInputStream fileInput = new FileInputStream(propertyFile);
            systemProp.load(fileInput);

            fileInput.close();

            systemProp.forEach((key, value) -> System.setProperty(key.toString(),value.toString()));

        } catch (Exception var5) {
            System.out.println(var5);
        }

    }
}
